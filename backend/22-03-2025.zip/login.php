<?php
include 'config.php';
session_start();

$login_failed = false; // Flag for failed login

if (isset($_POST["submit"])) {
    $company = $_POST['company'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT
               us.*,
               rl.id as roles_id,
               rl.name as roles,
               c.id as company_id,
               c.name as company,
               c.region as region,
               c.city as city,
               c.country as country
            FROM user us
            INNER JOIN roles rl ON us.roles_id = rl.id
            INNER JOIN company c ON us.company_id = c.id
            WHERE us.name = ? AND us.passcode = ? AND c.name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $password, $company);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Set session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['company_id'] = $user['company_id'];
        $_SESSION['company'] = $user['company'];
        $_SESSION['region'] = $user['region'];
        $_SESSION['city'] = $user['city'];
        $_SESSION['country'] = $user['country'];
        $_SESSION['roles'] = $user['roles'];

        switch ($_SESSION['roles']) {
            case 'Admin':
                header("Location: application/dashboard/dashboard/index.php");
                exit();
            case 'Manager':
                header("Location: application/reservations/list/index.php");
                exit();
            case 'Staff':
                header("Location: application/reservations/guest/index.php");
                exit();
            default:
                break;
        }
    } else {
        $login_failed = true; // Set flag for failed login
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="assets/css/login.css">
    <style>
        .login-container .message {
    display: none;
    color: #d9534f; /* Red for error */
    font-size: 14px;
    margin-bottom: 10px;
    text-align: center;
}

.login-container .message.visible {
    display: block;
}
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <span class="message">Invalid User Details. Try Again...</span>
        <form action="" method="post">
            <div class="input-group">
                <label for="company">Company:</label>
                <input type="text" id="company" name="company" required>
            </div>
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <div class="password-wrapper">
                    <input type="password" id="password" name="password" required>
                    <button type="button" id="togglePassword">?</button>
                </div>
            </div>
            <button type="submit" class="login-btn" name="submit">Login</button>
        </form>
    </div>

    <script src="assets/js/login.js"></script>
    <script>
        <?php if ($login_failed): ?>
            document.querySelector('.login-container .message').classList.add('visible');
        <?php endif; ?>
    </script>
</body>
</html>