<div class="homespace">
    <div class="page-title">
        <?php echo $header; ?>
    </div>
    <div class="company">
        <button>
            <div class="icon">
                <i class="fa fa-building-o" aria-hidden="true"></i>
            </div>
            <div class="details">
                <span class="name"><?php echo $_SESSION['company']; ?></span>
                <span class="location"><?php echo $_SESSION['region']; ?>, <?php echo $_SESSION['city']; ?></span>
            </div>
            <div class="arrow">
                <i class="fa fa-chevron-down" aria-hidden="true"></i>
            </div>
        </button>
        <div class="company-down">
            <a href="../../dashboard/home/index.php">
                <i class="fa fa-info" aria-hidden="true"></i>
                <span>Details</span>
            </a>
            <a href="../../dashboard/settings/index.php">
                <i class="fa fa-cogs" aria-hidden="true"></i>
                <span>Settings</span>
            </a>
        </div>
    </div>
</div>
<div class="workspace">
    <div class="schedule">
        <div class="greetings">
            <span><!--greetings--></span>
            <span><?php echo $_SESSION['user_name']; ?></span>
        </div>
        <div class="time">
            <span><!--day--></span>
            <span><!--time--></span>
        </div>
    </div>
    <div class="operation">
        <div class="calendar">
            <a href="">
                <button>
                    <div class="icon">
                        <i class="fa fa-calendar-check-o" aria-hidden="true" title="Calendar"></i>
                    </div>
                    <span>Go To Calendar</span>
                </button>
            </a>
        </div>
        <div class="new">
            <a href="">
                <button>
                    <div class="icon">
                        <i class="fa fa-pencil" aria-hidden="true"></i>
                    </div>
                    <span>New Reservation</span>
                </button>
            </a>
        </div>
        <div class="logout">
            <button>
                <span>
                    <i class="fa fa-chevron-down" aria-hidden="true"></i>
                </span>
            </button>
            <div class="logout-down">
                <a href="../../dashboard/profile/index.php">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <span>Profile</span>
                </a>
                <a href="../../../login.php">
                    <i class="fa fa-sign-out" aria-hidden="true"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </div>
</div>