document.addEventListener('DOMContentLoaded', function() {
  // COMPANY
  const companyButtons = document.querySelectorAll('.homespace .company button');
  companyButtons.forEach(button => {
      button.addEventListener('click', function(e) {
          // Don't prevent default if click was on a link
          if (e.target.closest('.company-down a')) {
              return; // Let the link navigation happen naturally
          }
          
          e.preventDefault();
          const companyDown = this.closest('.company').querySelector('.company-down');
          if (companyDown) {
              companyDown.style.display = companyDown.style.display === 'flex' ? 'none' : 'flex';
          }
      });
  });

  // Remove all event handlers from the links in company dropdown
  const companyLinks = document.querySelectorAll('.homespace .company .company-down a');
  companyLinks.forEach(link => {
      // Clear previous event handlers
      link.onclick = null;
      // Force direct navigation on click
      link.addEventListener('click', function(e) {
          // Don't stop propagation or prevent default - let it navigate normally
          // Explicitly navigate to ensure it works
          setTimeout(function() {
              window.location.href = link.href;
          }, 0);
      });
  });

  // LOGOUT
  const logoutButtons = document.querySelectorAll('.workspace .logout button');
  logoutButtons.forEach(button => {
      button.addEventListener('click', function(e) {
          // Don't prevent default if click was on a link
          if (e.target.closest('.logout-down a')) {
              return; // Let the link navigation happen naturally
          }
          
          e.preventDefault();
          const logoutDown = this.closest('.logout').querySelector('.logout-down');
          if (logoutDown) {
              logoutDown.style.display = logoutDown.style.display === 'flex' ? 'none' : 'flex';
          }
      });
  });

  // Remove all event handlers from the links in logout dropdown
  const logoutLinks = document.querySelectorAll('.workspace .logout .logout-down a');
  logoutLinks.forEach(link => {
      // Clear previous event handlers
      link.onclick = null;
      // Force direct navigation on click
      link.addEventListener('click', function(e) {
          // Don't stop propagation or prevent default - let it navigate normally
          // Explicitly navigate to ensure it works
          setTimeout(function() {
              window.location.href = link.href;
          }, 0);
      });
  });

  // Close dropdowns when clicking outside
  document.addEventListener('click', function(e) {
      // Close company dropdown when clicking outside
      if (!e.target.closest('.homespace .company')) {
          const companyDropdowns = document.querySelectorAll('.homespace .company .company-down');
          companyDropdowns.forEach(dropdown => {
              dropdown.style.display = 'none';
          });
      }
      
      // Close logout dropdown when clicking outside
      if (!e.target.closest('.workspace .logout')) {
          const logoutDropdowns = document.querySelectorAll('.workspace .logout .logout-down');
          logoutDropdowns.forEach(dropdown => {
              dropdown.style.display = 'none';
          });
      }
  });

  // Your unrelated code (moved inside DOMContentLoaded)
  const menus = document.querySelectorAll('.nav-icon .menu');
  menus.forEach(menu => {
      menu.addEventListener('click', (e) => {
          e.preventDefault();
          const submenu = menu.closest('.nav-icon').querySelector('.submenu');
          if (submenu) {
              submenu.style.display = submenu.style.display === 'flex' ? 'none' : 'flex';
          }
      });
  });

  const moreOptions = document.querySelectorAll('.options-tab .more-options');
  moreOptions.forEach(mOptions => {
      mOptions.addEventListener('click', (e) => {
          e.preventDefault();
          const moreDrop = mOptions.closest('.options-tab').querySelector('.extra-options');
          if (moreDrop) {
              moreDrop.style.display = moreDrop.style.display === 'block' ? 'none' : 'block';
          }
      });
  });

  const addBtn = document.querySelectorAll('.options-tab .add-btn');
  addBtn.forEach(aBtn => {
      aBtn.addEventListener('click', (e) => {
          e.preventDefault();
          const addDrop = aBtn.closest('.options-tab').querySelector('.options-tab .register');
          if (addDrop) {
              addDrop.style.display = addDrop.style.display === 'block' ? 'none' : 'block';
          }
      });
  });

  const add1Btn = document.querySelectorAll('.options-tab .add1-btn');
  add1Btn.forEach(a1Btn => {
      a1Btn.addEventListener('click', (e) => {
          e.preventDefault();
          const add1Drop = a1Btn.closest('.options-tab').querySelector('.options-tab .register2');
          if (add1Drop) {
              add1Drop.style.display = add1Drop.style.display === 'block' ? 'none' : 'block';
          }
      });
  });

  const importBtn = document.querySelectorAll('.options-tab .import-btn');
  importBtn.forEach(iBtn => {
      iBtn.addEventListener('click', (e) => {
          e.preventDefault();
          const importDrop = iBtn.closest('.options-tab').querySelector('.options-tab .import');
          if (importDrop) {
              importDrop.style.display = importDrop.style.display === 'block' ? 'none' : 'block';
          }
      });
  });

  const exportBtn = document.querySelectorAll('.options-tab .export-btn');
  exportBtn.forEach(eBtn => {
      eBtn.addEventListener('click', (e) => {
          e.preventDefault();
          const exportDrop = eBtn.closest('.options-tab').querySelector('.options-tab .export');
          if (exportDrop) {
              exportDrop.style.display = exportDrop.style.display === 'block' ? 'none' : 'block';
          }
      });
  });

  // DROPDOWNS
  // Only target edit buttons, not the edit forms
  const editButtons = document.querySelectorAll('.action-btns .edit, .pcb-content .edit-drop');
  editButtons.forEach(editBtn => {
      editBtn.addEventListener('click', (e) => {
          e.preventDefault();
          const editDrop = editBtn.closest('.flex').nextElementSibling.querySelector('.sub-section .edit');
          if (editDrop) {
              editDrop.style.display = editDrop.style.display === 'block' ? 'none' : 'block';
          }
      });
  });

  // Only target delete buttons, not the delete forms
  const deleteButtons = document.querySelectorAll('.action-btns .delete, .pcb-content .delete-drop');
  deleteButtons.forEach(deleteBtn => {
      deleteBtn.addEventListener('click', (e) => {
          e.preventDefault();
          const deleteDrop = deleteBtn.closest('.flex').nextElementSibling.querySelector('.sub-section .delete');
          if (deleteDrop) {
              deleteDrop.style.display = deleteDrop.style.display === 'block' ? 'none' : 'block';
          }
      });
  });

  // Only target checkout buttons, not the checkout forms
  const checkoutButtons = document.querySelectorAll('.action-btns .checkout, .pcb-content .checkout-drop');
  checkoutButtons.forEach(checkoutBtn => {
    checkoutBtn.addEventListener('click', (e) => {
          e.preventDefault();
          const checkoutDrop = checkoutBtn.closest('.flex').nextElementSibling.querySelector('.sub-section .checkout');
          if (checkoutDrop) {
            checkoutDrop.style.display = checkoutDrop.style.display === 'block' ? 'none' : 'block';
          }
      });
  });

  // Only target view payment buttons, not the view payment forms
  const viewPaymentButtons = document.querySelectorAll('.option-drop .viewPayment a');
  console.log('Found viewPayment buttons:', viewPaymentButtons.length);
  viewPaymentButtons.forEach((viewPaymentBtn, index) => {
      viewPaymentBtn.addEventListener('click', (e) => {
          e.preventDefault();
          console.log(`View Payment button ${index} clicked`);
          const viewPayDrop = viewPaymentBtn.closest('.flex').nextElementSibling.querySelector('.sub-section .viewpay');
          if (viewPayDrop) {
              console.log(`Button ${index}: Current display: ${viewPayDrop.style.display || 'unset'}`);
              viewPayDrop.style.display = viewPayDrop.style.display === 'block' ? 'none' : 'block';
              console.log(`Button ${index}: New display: ${viewPayDrop.style.display}`);
          } else {
              console.error(`Button ${index}: View payment dropdown not found`);
          }
      });
  });



  // CANCEL BUTTONS

  const cancelEditButtons = document.querySelectorAll('.sub-section .edit form .submits button:first-child');
  cancelEditButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const editContainer = btn.closest('.edit');
          if (editContainer) {
              editContainer.style.display = 'none';
          }
      });
  });


  const cancelDeleteButtons = document.querySelectorAll('.sub-section .delete form .submits button:first-child');
  cancelDeleteButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const deleteContainer = btn.closest('.delete');
          if (deleteContainer) {
              deleteContainer.style.display = 'none';
          }
      });
  });


  const cancelCheckinButtons = document.querySelectorAll('.sub-section .checkin form .submits button:first-child');
  cancelCheckinButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const checkinContainer = btn.closest('.checkin');
          if (checkinContainer) {
              checkinContainer.style.display = 'none';
          }
      });
  });

  const cancelCheckoutButtons = document.querySelectorAll('.sub-section .checkout form .submits button:first-child');
  cancelCheckoutButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const checkoutContainer = btn.closest('.checkout');
          if (checkoutContainer) {
              checkoutContainer.style.display = 'none';
          }
      });
  });

  const cancelCancelButtons = document.querySelectorAll('.sub-section .cancel form .submits button:first-child');
  cancelCancelButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const cancelContainer = btn.closest('.cancel');
          if (cancelContainer) {
              cancelContainer.style.display = 'none';
          }
      });
  });

  const cancelSHKButtons = document.querySelectorAll('.sub-section .shk form .submits button:first-child');
  cancelSHKButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const shkContainer = btn.closest('.shk');
          if (shkContainer) {
              shkContainer.style.display = 'none';
          }
      });
  });

  const cancelMoreButtons = document.querySelectorAll('.sub-section .more form .submits button:first-child');
  cancelMoreButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const moreContainer = btn.closest('.more');
          if (moreContainer) {
              moreContainer.style.display = 'none';
          }
      });
  });

  const cancelAddPayButtons = document.querySelectorAll('.sub-section .addpay form .submits button:first-child');
  cancelAddPayButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const addPayContainer = btn.closest('.addpay');
          if (addPayContainer) {
              addPayContainer.style.display = 'none';
          }
      });
  });

  const cancelViewPayButtons = document.querySelectorAll('.sub-section .viewpay form .submits button:first-child');
  cancelViewPayButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const viewPayContainer = btn.closest('.viewpay');
          if (viewPayContainer) {
              viewPayContainer.style.display = 'none';
          }
      });
  });

  const cancelBalanceButtons = document.querySelectorAll('.sub-section .balance form .submits button:first-child');
  cancelBalanceButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const balanceContainer = btn.closest('.balance');
          if (balanceContainer) {
              balanceContainer.style.display = 'none';
          }
      });
  });

  const cancelAddRefButtons = document.querySelectorAll('.sub-section .addref form .submits button:first-child');
  cancelAddRefButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const addRefContainer = btn.closest('.addref');
          if (addRefContainer) {
              addRefContainer.style.display = 'none';
          }
      });
  });

  const cancelViewRefButtons = document.querySelectorAll('.sub-section .viewref form .submits button:first-child');
  cancelViewRefButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
          e.preventDefault();

          const viewRefContainer = btn.closest('.viewref');
          if (viewRefContainer) {
              viewRefContainer.style.display = 'none';
          }
      });
  });







  

  // Prevent clicks inside the form from closing it
  const subForms = document.querySelectorAll('.sub-section form');
  subForms.forEach(form => {
      form.addEventListener('click', (e) => {
          e.stopPropagation(); // Stop clicks inside the form from bubbling up
      });
  });
});