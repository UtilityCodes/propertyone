<?php

include '../../../config.php';


function generateCode(){
    $timestamp = time();

    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);

    $code = 'us' . '-'  . $timestamp . '-' . $randomNumber;

    return $code;
}

if (isset($_POST["submit"])){  
    $dates = $_POST['date'];
    $timee = $_POST['time'];
    $name = $_POST['name'];
    $roles = $_POST['roles'];
    $code = $_POST['code'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $passcode = $_POST['passcode'];
    $note = $_POST['note'];
    $company = $_SESSION['company_id'];

    date_default_timezone_set('Africa/Dar_es_Salaam');

    if($code == null){
        $code = generateCode();   
    }

    if($dates == null){
        $dates = date('Y-m-d');  
    }

    if($timee == null){
        $timee = date("H:i:s"); 
    }

    if($email == null){
        $email = 'No Email'; 
    }

    if($note == null){
        $note = 'No Note';   
    }

    $sql = "INSERT INTO user (code, name, phone, email, passcode, roles_id,  note, company_id, dates, timee) 
                         VALUES ('$code', '$name', '$phone', '$email', '$passcode', '$roles', '$note', '$company', '$dates', '$timee')";

    if ($conn->query($sql) === TRUE) {
        header("location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

}

$conn->close();
