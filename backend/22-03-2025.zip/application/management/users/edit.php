<?php
// edit.php
include '../../../config.php';

session_start();

date_default_timezone_set('Africa/Dar_es_Salaam');

$company = $_SESSION['company_id'];
$user_id = $_SESSION['user_id'];

if (isset($_POST["update"]) && isset($_POST["id"])) {
    $userId = $_POST["id"];
    $code = $_POST["code"];
    $name = $_POST["name"];
    $passcode = $_POST["passcode"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $note = $_POST["note"];

    // Prepare the update statement
    $updateSql = "UPDATE user 
                 SET code = ?, 
                     name = ?, 
                     passcode = ?, 
                     email = ?, 
                     phone = ?, 
                     note = ?
                 WHERE id = ? 
                 AND company_id = ?";

    $stmt = $conn->prepare($updateSql);
    $stmt->bind_param("ssssssis", 
        $code, 
        $name, 
        $passcode, 
        $email, 
        $phone, 
        $note, 
        $userId, 
        $company
    );

    if ($stmt->execute()) {
        // Success - redirect back to the main page
        header("Location: index.php?success=user_updated");
        exit();
    } else {
        // Error handling
        echo "Error updating user: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "Required fields are missing.";
}

$conn->close();