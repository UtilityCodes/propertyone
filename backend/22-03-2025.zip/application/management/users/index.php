<?php
include '../../../config.php';


session_start();

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];


// for roles
$role_query = "SELECT id, name FROM roles";
$role_result = $conn->query($role_query);
$roles = $role_result->fetch_all(MYSQLI_ASSOC);

// for user

$user_query = "SELECT 
                    us.*,
                    rl.name as roles
                FROM user us
                INNER JOIN roles rl on us.roles_id = rL.id";
$user_result = $conn->query($user_query);
$users = $user_result->fetch_all(MYSQLI_ASSOC);



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Users';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Management';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    All Users
                </a>
                <a href="#" data-page="1">
                    Admin
                </a>
                <a href="#" data-page="2">
                    Manager
                </a>
                <a href="#" data-page="3">
                    Staff
                </a>
            </div>
            <div class="inline-page-body">
                <!--All Users-->
                <div class="page active">

                    <div class="options-tab">
                        <div class="ot-flex">
                            <div class="more-options">
                                <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                    <title>More Options</title>
                                    <path d="M416,170.667H96A53.333,53.333,0,0,1,96,64H416a53.333,53.333,0,0,1,0,106.667Zm-320-64A10.667,10.667,0,1,0,96,128H416a10.667,10.667,0,1,0,0-21.333Z"></path>
                                    <path d="M416,309.333H96a53.333,53.333,0,1,1,0-106.667H416a53.333,53.333,0,0,1,0,106.667Zm-320-64a10.667,10.667,0,0,0,0,21.333H416a10.667,10.667,0,0,0,0-21.333Z"></path>
                                    <path d="M416,448H96a53.333,53.333,0,0,1,0-106.667H416A53.333,53.333,0,0,1,416,448ZM96,384a10.667,10.667,0,1,0,0,21.333H416A10.667,10.667,0,1,0,416,384Z"></path>
                                </svg>
                            </div>
                            <div class="operative-options">
                                <button class="add-btn">
                                    <div class="icon">
                                        <i class="fa fa-plus" aria-hidden="true"></i>
                                    </div>
                                    <span>Register New User</span>
                                </button>
                                <button class="import-btn">
                                    <div class="icon">
                                        <i class="fa fa-upload" aria-hidden="true"></i>
                                    </div>
                                    <span>Import</span>
                                </button>
                                <button class="export-btn">
                                    <div class="icon">
                                        <i class="fa fa-download" aria-hidden="true"></i>
                                    </div>
                                    <span>Export</span>
                                </button>
                            </div>
                        </div>

                        <div class="extra-tab">
                            <div class="extra-options">
                                <div class="eo-flex">
                                    <a href="">
                                        <button>
                                            <div class="icon">
                                                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;" xml:space="preserve">
                                                    <title>Reports</title>
                                                    <g id="Layer_1">
                                                        <path d="M26,3V1h-2v2H3H1v2h2v26H1v2h2h17.471L14,47.791V49h2v-0.791L22.654,33H24v16h2V33h1.346L34,48.209V49h2v-1.209L29.529,33
                                                            H47h2v-2h-2V5h2V3h-2H26z M45,31H5V5h40V31z"></path>
                                                        <path d="M16,28c4.411,0,8-3.589,8-8v-1h-7v-7h-1c-4.411,0-8,3.589-8,8S11.589,28,16,28z M15,14.083V21h6.917
                                                            c-0.478,2.834-2.949,5-5.917,5c-3.309,0-6-2.691-6-6C10,17.032,12.166,14.561,15,14.083z"></path>
                                                        <path d="M28,16c0-4.411-3.589-8-8-8h-1v9h9V16z M21,15v-4.917c2.509,0.422,4.494,2.408,4.917,4.917H21z"></path>
                                                        <rect x="31" y="10" width="10" height="2"></rect>
                                                        <rect x="31" y="15" width="10" height="2"></rect>
                                                        <rect x="31" y="20" width="10" height="2"></rect>
                                                    </g>
                                                    <g>
                                                    </g>
                                                </svg>
                                            </div>
                                            <span>Go To Reports</span>
                                        </button>
                                    </a>
                                    <a href="">
                                        <button>
                                            <div class="icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
                                                    <title>Room Types</title>
                                                    <g id="Fresh_Door" data-name="Fresh Door">
                                                        <path d="M45,42H44V7a3,3,0,0,0-3-3H7A3,3,0,0,0,4,7V42H3a1,1,0,0,0,0,2H45a1,1,0,0,0,0-2ZM10,42V10H23V42Zm15,0V10H38V42Zm15,0V9a1,1,0,0,0-1-1H9A1,1,0,0,0,8,9V42H6V7A1,1,0,0,1,7,6H41a1,1,0,0,1,1,1V42Z"></path>
                                                        <path d="M28,23.444a1,1,0,0,0-1,1v3.112a1,1,0,0,0,2,0V24.444A1,1,0,0,0,28,23.444Z"></path>
                                                        <path d="M20,23.444a1,1,0,0,0-1,1v3.112a1,1,0,0,0,2,0V24.444A1,1,0,0,0,20,23.444Z"></path>
                                                    </g>
                                                </svg>
                                            </div>
                                            <span>Go To Room Types</span>
                                        </button>
                                    </a>
                                </div>
                            </div>
                            <div class="register">
                                <div class="reg-flex">
                                    <div class="reg-heading">
                                        <h2> Register New User Details:</h2>
                                       
                                    </div>
                                    <form action="actionform.php" class="reg-form" method="post">
                                        <div class="form-section">
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Code:</label><br>
                                                    <input type="text" name="code">
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Name:<span>*</span></label><br>
                                                    <input type="text" name="name" required>
                                                </div>

                                                <div class="input-label">
                                                    <label for=""> Password:<span>*</span></label><br>
                                                    <input type="text" name="passcode" required>
                                                </div>
                                            </div>

                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Role:<span>*</span></label><br>
                                                    <select name="roles" required>
                                                        <option value="" selected disabled>--Select User Role--</option>
                                                        <?php
                                                            foreach ($roles as $role) {
                                                                echo "<option value='{$role['id']}'>{$role['name']}</option>";
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Phone: <span>*</span> </label><br>
                                                    <input type="text" name="phone" required>
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Email:</label><br>
                                                    <input type="text" name="email">
                                                </div>
                                            </div>
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Description:</label><br>
                                                    <textarea name="note"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-submit">
                                            <button class="cancel">
                                                <div class="icon">
                                                    <i class="fa fa-times" aria-hidden="true"></i>
                                                </div>
                                                <span>CANCEL</span>
                                            </button>
                                            <button class="confirm" name="submit">
                                                <div class="icon">
                                                    <i class="fa fa-check" aria-hidden="true"></i>
                                                </div>
                                                <span>CONFIRM</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="import">
                                <form class="i-flex">
                                    <div class="imp-heading">
                                        <h2>Upload Details Through CSV:</h2>
                                        <p>1. Get Template first, fill the data, then upload</p>
                                        <p>2. Click below or drag file to upload</p>
                                    </div>
                                    <div class="imp-area">
                                        <label for="" class="upload-icon">
                                            <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                <title>Upload CSV File</title>
                                                <path d="M20.57,9.43A8,8,0,0,0,5.26,10,5,5,0,1,0,5,20h5V18H5a3,3,0,0,1,0-6,3.1,3.1,0,0,1,.79.12l1.12.31.14-1.15a6,6,0,0,1,11.74-.82l.15.54.54.16A3.46,3.46,0,0,1,22,14.5,3.5,3.5,0,0,1,18.5,18H16v2h2.5A5.48,5.48,0,0,0,20.57,9.43Z"></path>
                                                <polygon points="16.71 15.29 13 11.59 9.29 15.29 10.71 16.71 12 15.41 12 20 14 20 14 15.41 15.29 16.71 16.71 15.29"></polygon>
                                            </svg>
                                        </label>
                                        <input type="file" class="file">
                                        <div class="message">
                                            <p>Drag your CSV data file here</p>
                                        </div>
                                        <div class="or">
                                            <p>OR</p>
                                        </div>
                                        <button>
                                            <div class="icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                    <path d="M8.71,7.71,11,5.41V15a1,1,0,0,0,2,0V5.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42l-4-4a1,1,0,0,0-.33-.21,1,1,0,0,0-.76,0,1,1,0,0,0-.33.21l-4,4A1,1,0,1,0,8.71,7.71ZM21,14a1,1,0,0,0-1,1v4a1,1,0,0,1-1,1H5a1,1,0,0,1-1-1V15a1,1,0,0,0-2,0v4a3,3,0,0,0,3,3H19a3,3,0,0,0,3-3V15A1,1,0,0,0,21,14Z"></path>
                                                </svg>
                                            </div>
                                            <span>Import</span>
                                        </button>

                                    </div>
                                    <div class="added-files">
                                        <div class="loading">
                                            <div class="file-icon">
                                                <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                                    <style type="text/css">
                                                        .st0{fill:#F4F4F3;}
                                                        .st1{fill:#EDECEB;}
                                                        .st2{fill:#7CC250;}
                                                    </style>
                                                    <g>
                                                        <g>
                                                            <path class="st0" d="M414.2,121.5v317.6c0,7.4-6,13.4-13.4,13.4H111.2c-7.4,0-13.4-6-13.4-13.4V72.9c0-7.4,6-13.4,13.4-13.4h237.6
                                                                L414.2,121.5z"></path>
                                                            <path class="st1" d="M414.2,121.5h-52.1c-7.4,0-13.4-6-13.4-13.4V59.5L414.2,121.5z"></path>
                                                        </g>
                                                        <rect x="97.8" y="307.9" class="st2" width="316.5" height="103.3"></rect>
                                                        <g>
                                                            <path class="st0" d="M219.1,372.7c0,2.3-0.6,4.7-1.7,7.4c-1.1,2.7-2.9,5.3-5.3,7.8c-2.4,2.6-5.5,4.6-9.2,6.2
                                                                c-3.7,1.6-8.1,2.4-13.1,2.4c-3.8,0-7.2-0.4-10.3-1.1c-3.1-0.7-5.9-1.8-8.4-3.3c-2.5-1.5-4.8-3.5-7-6c-1.9-2.2-3.5-4.8-4.8-7.5
                                                                c-1.3-2.8-2.3-5.8-3-8.9c-0.7-3.2-1-6.5-1-10.1c0-5.8,0.8-10.9,2.5-15.5c1.7-4.6,4.1-8.5,7.2-11.7c3.1-3.2,6.8-5.7,11-7.4
                                                                c4.2-1.7,8.7-2.5,13.4-2.5c5.8,0,11,1.2,15.5,3.5c4.5,2.3,8,5.2,10.4,8.6c2.4,3.4,3.6,6.6,3.6,9.6c0,1.7-0.6,3.1-1.8,4.4
                                                                s-2.6,1.9-4.2,1.9c-1.9,0-3.2-0.4-4.2-1.3s-2-2.4-3.1-4.5c-1.9-3.5-4.1-6.2-6.7-8c-2.6-1.8-5.7-2.6-9.4-2.6
                                                                c-6,0-10.7,2.3-14.2,6.8c-3.5,4.5-5.3,11-5.3,19.3c0,5.6,0.8,10.2,2.3,13.9c1.6,3.7,3.8,6.5,6.6,8.3c2.9,1.8,6.2,2.7,10.1,2.7
                                                                c4.2,0,7.7-1,10.6-3.1c2.9-2.1,5.1-5.1,6.5-9.1c0.6-1.9,1.4-3.4,2.3-4.6c0.9-1.2,2.4-1.8,4.4-1.8c1.7,0,3.2,0.6,4.4,1.8
                                                                C218.5,369.5,219.1,371,219.1,372.7z"></path>
                                                            <path class="st0" d="M286.5,373.9c0,4.3-1.1,8.2-3.3,11.7c-2.2,3.5-5.5,6.2-9.8,8.1s-9.4,2.9-15.3,2.9c-7.1,0-12.9-1.3-17.5-4
                                                                c-3.3-1.9-5.9-4.5-7.9-7.7c-2-3.2-3.1-6.3-3.1-9.4c0-1.8,0.6-3.3,1.8-4.5c1.2-1.3,2.8-1.9,4.7-1.9c1.5,0,2.8,0.5,3.9,1.5
                                                                c1.1,1,2,2.4,2.7,4.3c0.9,2.3,1.9,4.2,3,5.7c1.1,1.5,2.5,2.8,4.5,3.8c1.9,1,4.4,1.5,7.6,1.5c4.3,0,7.8-1,10.5-3s4-4.5,4-7.5
                                                                c0-2.4-0.7-4.3-2.2-5.8c-1.4-1.5-3.3-2.6-5.6-3.4s-5.4-1.6-9.2-2.5c-5.1-1.2-9.4-2.6-12.9-4.2s-6.2-3.8-8.3-6.6
                                                                c-2-2.8-3.1-6.2-3.1-10.4c0-3.9,1.1-7.4,3.2-10.5c2.1-3.1,5.3-5.4,9.3-7.1c4.1-1.6,8.9-2.5,14.4-2.5c4.4,0,8.2,0.5,11.4,1.6
                                                                c3.2,1.1,5.9,2.5,8,4.3c2.1,1.8,3.7,3.7,4.6,5.7c1,2,1.5,3.9,1.5,5.8c0,1.7-0.6,3.3-1.8,4.7c-1.2,1.4-2.7,2.1-4.6,2.1
                                                                c-1.7,0-2.9-0.4-3.8-1.2c-0.9-0.8-1.8-2.2-2.8-4.1c-1.3-2.7-2.9-4.8-4.7-6.3c-1.8-1.5-4.8-2.3-8.8-2.3c-3.7,0-6.8,0.8-9.1,2.5
                                                                c-2.3,1.6-3.4,3.6-3.4,5.9c0,1.4,0.4,2.7,1.2,3.7c0.8,1,1.9,1.9,3.2,2.7c1.4,0.7,2.8,1.3,4.2,1.8c1.4,0.4,3.7,1,6.9,1.9
                                                                c4,0.9,7.7,2,11,3.1c3.3,1.1,6.1,2.5,8.3,4.2c2.3,1.6,4.1,3.7,5.4,6.2C285.9,367.2,286.5,370.3,286.5,373.9z"></path>
                                                            <path class="st0" d="M309.4,332.1l16.2,48l16.3-48.3c0.8-2.5,1.5-4.3,1.9-5.3c0.4-1,1.1-1.9,2.1-2.7c1-0.8,2.3-1.2,4-1.2
                                                                c1.2,0,2.4,0.3,3.4,0.9c1.1,0.6,1.9,1.4,2.5,2.5c0.6,1,0.9,2.1,0.9,3.1c0,0.7-0.1,1.5-0.3,2.3s-0.4,1.6-0.7,2.4
                                                                c-0.3,0.8-0.6,1.6-0.9,2.5L337.5,383c-0.6,1.8-1.2,3.5-1.9,5.1c-0.6,1.6-1.3,3-2.1,4.2c-0.8,1.2-1.9,2.2-3.2,3
                                                                c-1.4,0.8-3,1.2-5,1.2s-3.6-0.4-5-1.1c-1.4-0.8-2.4-1.8-3.3-3c-0.8-1.3-1.6-2.7-2.2-4.3c-0.6-1.6-1.2-3.3-1.9-5.1l-17-46.4
                                                                c-0.3-0.8-0.6-1.7-0.9-2.5c-0.3-0.8-0.6-1.7-0.8-2.6c-0.2-0.9-0.3-1.7-0.3-2.4c0-1.7,0.7-3.2,2-4.5c1.3-1.4,3-2.1,5-2.1
                                                                c2.5,0,4.2,0.8,5.2,2.3S308.3,328.8,309.4,332.1z"></path>
                                                        </g>
                                                    </g>
                                                </svg>
                                            </div>
                                            <div class="file-sections">
                                                <div class="title-cancel">
                                                    <div class="title">
                                                        types.csv
                                                    </div>
                                                    <div class="cancel">
                                                        <i class="fa fa-times" aria-hidden="true"></i>
                                                    </div>
                                                </div>
                                                <div class="load-bar"></div>
                                                <div class="load-details">
                                                    uploading 1 of 1 files
                                                </div>
                                            </div>
                                        </div>
                                        <div class="the-files">
                                            <div class="file-icon">
                                                <svg viewBox="0 0 267 267" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2;"><g><path d="M50,154.167c56.944,9.876 113.889,9.544 170.833,-0l0,-79.167c0,-0.902 -0.292,-1.779 -0.833,-2.5l-37.5,-50c-0.787,-1.049 -2.022,-1.667 -3.333,-1.667l-116.667,0c-3.315,0 -6.495,1.317 -8.839,3.661c-2.344,2.345 -3.661,5.524 -3.661,8.839c-0,19.42 -0,66.505 -0,95.834c-0,6.188 -1.451,11.433 -1.451,15.614c0,5.78 1.451,9.386 1.451,9.386Z" style="fill:#d8dfe3;"></path><path d="M25,143.365c-0,0 0,68.863 0,89.968c-0,3.315 1.317,6.495 3.661,8.839c2.344,2.344 5.524,3.661 8.839,3.661c33.501,0 158.165,0 191.667,0c3.315,0 6.494,-1.317 8.839,-3.661c2.344,-2.344 3.661,-5.524 3.661,-8.839c-0,-15.966 -0,-50.7 -0,-66.666c-0,-3.315 -1.317,-6.495 -3.661,-8.839c-2.345,-2.344 -5.524,-3.661 -8.839,-3.661l-187.5,-0c-5.316,-0 -16.667,-10.802 -16.667,-10.802Z" style="fill:#1fb35b;"></path><path d="M37.5,154.167c-3.804,-0 -6.581,-1.543 -8.625,-3.443c-1.923,-1.788 -3.875,-4.939 -3.875,-9.057c-0,-2.643 1.317,-6.495 3.661,-8.839c2.344,-2.344 5.524,-3.661 8.839,-3.661c13.571,-0 12.5,-0 12.5,-0l-0,25c-0,-0 1.071,-0 -12.5,-0Z" style="fill:#198043;"></path><path d="M179.167,20.833l-0,41.667c-0,3.315 1.317,6.495 3.661,8.839c2.344,2.344 5.523,3.661 8.839,3.661l29.166,-0c0,-0.902 -0.292,-1.779 -0.833,-2.5l-37.5,-50c-0.787,-1.049 -2.022,-1.667 -3.333,-1.667Z" style="fill:#afbdc7;"></path><path d="M87.5,79.167l54.167,-0c2.299,-0 4.166,-1.867 4.166,-4.167c0,-2.3 -1.867,-4.167 -4.166,-4.167l-54.167,0c-2.3,0 -4.167,1.867 -4.167,4.167c0,2.3 1.867,4.167 4.167,4.167Z" style="fill:#1fb35b;"></path><path d="M87.5,104.167l95.833,-0c2.3,-0 4.167,-1.867 4.167,-4.167c0,-2.3 -1.867,-4.167 -4.167,-4.167l-95.833,0c-2.3,0 -4.167,1.867 -4.167,4.167c0,2.3 1.867,4.167 4.167,4.167Z" style="fill:#1fb35b;"></path><path d="M87.5,129.167l95.833,-0c2.3,-0 4.167,-1.867 4.167,-4.167c0,-2.3 -1.867,-4.167 -4.167,-4.167l-95.833,0c-2.3,0 -4.167,1.867 -4.167,4.167c0,2.3 1.867,4.167 4.167,4.167Z" style="fill:#1fb35b;"></path><path d="M156.548,180.714l16.667,41.667c0.632,1.582 2.165,2.619 3.868,2.619c1.704,0 3.236,-1.037 3.869,-2.619l16.667,-41.667c0.854,-2.135 -0.186,-4.562 -2.322,-5.416c-2.135,-0.854 -4.562,0.186 -5.416,2.321l-12.798,31.995c0,0 -12.798,-31.995 -12.798,-31.995c-0.854,-2.135 -3.281,-3.175 -5.416,-2.321c-2.135,0.854 -3.175,3.281 -2.321,5.416Z" style="fill:#d8dfe3;"></path><path d="M91.963,175l-2.381,0c-11.506,0 -20.833,9.327 -20.833,20.833c-0,2.745 -0,5.589 -0,8.334c-0,11.506 9.327,20.833 20.833,20.833l2.381,-0c7.433,0 14.183,-4.336 17.273,-11.096c0.431,-0.942 0.516,-1.12 0.793,-1.734c1.091,-2.422 -0.226,-4.633 -1.79,-5.419c-2.612,-1.313 -4.982,0.142 -5.789,1.954c-0.245,0.55 -0.793,1.735 -0.793,1.735c-1.735,3.793 -5.522,6.227 -9.694,6.227l-2.381,-0c-6.904,-0 -12.5,-5.597 -12.5,-12.5l0,-8.334c0,-6.903 5.596,-12.5 12.5,-12.5l2.381,0c4.172,0 7.959,2.434 9.694,6.227c-0,0 0.508,1.138 0.793,1.735c1.252,2.624 4.212,2.997 6.084,1.781c1.315,-0.856 2.557,-2.923 1.495,-5.246c-0.793,-1.734 -0.793,-1.734 -0.793,-1.734c-3.09,-6.76 -9.84,-11.096 -17.273,-11.096Z" style="fill:#d8dfe3;"></path>
                                                    <path d="M116.667,210.443l-0,-0.001l-0,2.066c-0,3.313 1.316,6.491 3.658,8.833c2.343,2.343 5.52,3.659 8.833,3.659c3.003,-0 6.39,-0 9.392,-0c3.313,0 6.49,-1.316 8.833,-3.659c2.343,-2.342 3.659,-5.52 3.659,-8.833c-0,-0.56 -0,-1.116 -0,-1.658c-0,-5.111 -3.112,-9.707 -7.858,-11.606l-15.151,-6.06c-1.832,-0.733 -3.033,-2.507 -3.033,-4.48l-0,-1.204c-0,-1.105 0.439,-2.165 1.22,-2.946c0.782,-0.782 1.841,-1.221 2.946,-1.221c0.001,0 9.376,0 9.376,0c1.105,0 2.165,0.439 2.946,1.221c0.781,0.781 1.22,1.841 1.22,2.946c0,0 0,1.372 0,2.058c0,1.176 0.52,2.24 1.043,2.78c0.813,0.923 1.981,1.412 3.124,1.412c2.028,0 4.167,-1.566 4.167,-4.192l-0,-2.058c-0,-3.315 -1.317,-6.495 -3.661,-8.839c-2.345,-2.344 -5.524,-3.661 -8.839,-3.661l-9.375,0c-3.316,0 -6.495,1.317 -8.839,3.661c-2.344,2.344 -3.661,5.524 -3.661,8.839c-0,0.405 -0,0.807 -0,1.204c-0,5.38 3.276,10.219 8.271,12.217l15.151,6.061c1.582,0.632 2.619,2.165 2.619,3.868l0,1.658c0,1.103 -0.438,2.161 -1.218,2.941c-0.779,0.78 -1.837,1.218 -2.94,1.218l-9.392,-0c-1.103,-0 -2.16,-0.438 -2.94,-1.218c-0.78,-0.78 -1.218,-1.838 -1.218,-2.94c-0,-0.001 -0,-0.001 -0,-2.067c-0,-2.748 -2.24,-4.194 -4.094,-4.194c-1.758,0 -4.239,1.363 -4.239,4.169c-0,0.026 0,0.026 0,0.026Z" style="fill:#d8dfe3;"></path></g></svg>
                                            </div>
                                            <div class="file-sections">
                                                <div class="title-cancel">
                                                    <div class="title">
                                                        types.csv
                                                    </div>
                                                    <div class="cancel">
                                                        <i class="fa fa-times" aria-hidden="true"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="imp-btn">
                                        <button>
                                            <div class="icon">
                                                <svg viewBox="0 0 32 32" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:sketch="http://www.bohemiancoding.com/sketch/ns">
                                                    <!-- Generator: Sketch 3.0.3 (7891) - http://www.bohemiancoding.com/sketch -->
                                                    <title>icon 57 document download</title>
                                                    <desc>Created with Sketch.</desc>
                                                    <defs></defs>
                                                    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" sketch:type="MSPage">
                                                        <g id="icon-57-document-download" sketch:type="MSArtboardGroup" fill="#000000">
                                                            <path d="M16,25.049999 L12.75,21.799999 L12,22.549999 L16.5,27.049999 L21,22.549999 L20.25,21.799999 L17,25.049999 L17,14 L16,14 L16,25.049999 L16,25.049999 Z M19.5,3 L9.00276013,3 C7.89666625,3 7,3.89833832 7,5.00732994 L7,27.9926701 C7,29.1012878 7.89092539,30 8.99742191,30 L24.0025781,30 C25.1057238,30 26,29.1017876 26,28.0092049 L26,10.5 L26,10 L20,3 L19.5,3 L19.5,3 L19.5,3 Z M19,4 L8.9955775,4 C8.44573523,4 8,4.45526288 8,4.99545703 L8,28.004543 C8,28.5543187 8.45470893,29 8.9999602,29 L24.0000398,29 C24.5523026,29 25,28.5550537 25,28.0066023 L25,11 L20.9979131,11 C19.8944962,11 19,10.1134452 19,8.99408095 L19,4 L19,4 Z M20,4.5 L20,8.99121523 C20,9.54835167 20.4506511,10 20.9967388,10 L24.6999512,10 L20,4.5 L20,4.5 Z" id="document-download" sketch:type="MSShapeGroup"></path>
                                                        </g>
                                                    </g>
                                                </svg>
                                            </div>
                                            <span>Get Template</span>
                                        </button>
                                        <button>
                                            
                                            <span>Finish Upload</span>
                                            <div class="icon">
                                                <svg enable-background="new 0 0 32 32" id="Слой_1" version="1.1" viewBox="0 0 32 32" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                                    <path clip-rule="evenodd" d="M31.705,15.284L31.705,15.284L31.705,15.284  l-9.97-9.991c-0.634-0.66-1.748-0.162-1.723,0.734v4.976C20.008,11.002,20.004,11,20,11H1c-0.55,0-1,0.45-1,1v8c0,0.55,0.45,1,1,1  h19c0.004,0,0.008-0.002,0.012-0.002v4.972c-0.024,0.892,1.082,1.376,1.715,0.742l9.977-9.999  C32.098,16.318,32.098,15.678,31.705,15.284z M22.017,23.564V19H22h-1h-0.988v0.002C20.008,19.002,20.004,19,20,19h-1H2v-6h17h1  c0.004,0,0.008-0.002,0.012-0.002V13H21h1h0.017V8.432l7.55,7.566L22.017,23.564z" fill="#121313" fill-rule="evenodd" id="Arrow_Right"></path>
                                                    <g></g><g></g><g></g><g></g><g></g><g></g>
                                                </svg>
                                            </div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <div class="export">
                                <form class="e-flex">
                                    <div class="exp-heading">
                                        <h2>Export Data To Your Computer:</h2>
                                    </div>
                                    <div class="exp-body">
                                        <div class="exp-btns">
                                            <button class="csv">
                                                <div class="icon">
                                                    <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 56 56" style="enable-background:new 0 0 56 56;" xml:space="preserve">
                                                        <g>
                                                            <path style="fill:#E9E9E0;" d="M36.985,0H7.963C7.155,0,6.5,0.655,6.5,1.926V55c0,0.345,0.655,1,1.463,1h40.074
                                                                c0.808,0,1.463-0.655,1.463-1V12.978c0-0.696-0.093-0.92-0.257-1.085L37.607,0.257C37.442,0.093,37.218,0,36.985,0z"></path>
                                                            <polygon style="fill:#D9D7CA;" points="37.5,0.151 37.5,12 49.349,12 	"></polygon>
                                                            <path style="fill:#F36FA0;" d="M48.037,56H7.963C7.155,56,6.5,55.345,6.5,54.537V39h43v15.537C49.5,55.345,48.845,56,48.037,56z"></path>
                                                            <g>
                                                                <path style="fill:#FFFFFF;" d="M21.58,51.975c-0.374,0.364-0.798,0.638-1.271,0.82c-0.474,0.183-0.984,0.273-1.531,0.273
                                                                    c-0.602,0-1.155-0.109-1.661-0.328s-0.948-0.542-1.326-0.971c-0.378-0.429-0.675-0.966-0.889-1.613
                                                                    c-0.214-0.647-0.321-1.395-0.321-2.242s0.107-1.593,0.321-2.235c0.214-0.643,0.51-1.178,0.889-1.606
                                                                    c0.378-0.429,0.822-0.754,1.333-0.978c0.51-0.224,1.062-0.335,1.654-0.335c0.547,0,1.057,0.091,1.531,0.273
                                                                    c0.474,0.183,0.897,0.456,1.271,0.82l-1.135,1.012c-0.228-0.265-0.481-0.456-0.759-0.574c-0.278-0.118-0.567-0.178-0.868-0.178
                                                                    c-0.337,0-0.659,0.063-0.964,0.191c-0.306,0.128-0.579,0.344-0.82,0.649c-0.242,0.306-0.431,0.699-0.567,1.183
                                                                    s-0.21,1.075-0.219,1.777c0.009,0.684,0.08,1.267,0.212,1.75c0.132,0.483,0.314,0.877,0.547,1.183s0.497,0.528,0.793,0.67
                                                                    c0.296,0.142,0.608,0.212,0.937,0.212s0.636-0.06,0.923-0.178s0.549-0.31,0.786-0.574L21.58,51.975z"></path>
                                                                <path style="fill:#FFFFFF;" d="M29.633,50.238c0,0.364-0.075,0.718-0.226,1.06s-0.362,0.643-0.636,0.902s-0.611,0.467-1.012,0.622
                                                                    c-0.401,0.155-0.857,0.232-1.367,0.232c-0.219,0-0.444-0.012-0.677-0.034s-0.467-0.062-0.704-0.116
                                                                    c-0.237-0.055-0.463-0.13-0.677-0.226c-0.214-0.096-0.399-0.212-0.554-0.349l0.287-1.176c0.127,0.073,0.289,0.144,0.485,0.212
                                                                    c0.196,0.068,0.398,0.132,0.608,0.191c0.209,0.06,0.419,0.107,0.629,0.144c0.209,0.036,0.405,0.055,0.588,0.055
                                                                    c0.556,0,0.982-0.13,1.278-0.39c0.296-0.26,0.444-0.645,0.444-1.155c0-0.31-0.105-0.574-0.314-0.793
                                                                    c-0.21-0.219-0.472-0.417-0.786-0.595s-0.654-0.355-1.019-0.533c-0.365-0.178-0.707-0.388-1.025-0.629
                                                                    c-0.319-0.241-0.583-0.526-0.793-0.854c-0.21-0.328-0.314-0.738-0.314-1.23c0-0.446,0.082-0.843,0.246-1.189
                                                                    s0.385-0.641,0.663-0.882c0.278-0.241,0.602-0.426,0.971-0.554s0.759-0.191,1.169-0.191c0.419,0,0.843,0.039,1.271,0.116
                                                                    c0.428,0.077,0.774,0.203,1.039,0.376c-0.055,0.118-0.119,0.248-0.191,0.39c-0.073,0.142-0.142,0.273-0.205,0.396
                                                                    c-0.064,0.123-0.119,0.226-0.164,0.308c-0.046,0.082-0.073,0.128-0.082,0.137c-0.055-0.027-0.116-0.063-0.185-0.109
                                                                    s-0.167-0.091-0.294-0.137c-0.128-0.046-0.296-0.077-0.506-0.096c-0.21-0.019-0.479-0.014-0.807,0.014
                                                                    c-0.183,0.019-0.355,0.07-0.52,0.157s-0.31,0.193-0.438,0.321c-0.128,0.128-0.228,0.271-0.301,0.431
                                                                    c-0.073,0.159-0.109,0.313-0.109,0.458c0,0.364,0.104,0.658,0.314,0.882c0.209,0.224,0.469,0.419,0.779,0.588
                                                                    c0.31,0.169,0.647,0.333,1.012,0.492c0.364,0.159,0.704,0.354,1.019,0.581s0.576,0.513,0.786,0.854
                                                                    C29.528,49.261,29.633,49.7,29.633,50.238z"></path>
                                                                <path style="fill:#FFFFFF;" d="M34.035,53.055l-3.131-10.131h1.873l2.338,8.695l2.475-8.695h1.859l-3.281,10.131H34.035z"></path>
                                                            </g>
                                                            <path style="fill:#C8BDB8;" d="M23.5,16v-4h-12v4v2v2v2v2v2v2v2v4h10h2h21v-4v-2v-2v-2v-2v-2v-4H23.5z M13.5,14h8v2h-8V14z
                                                                 M13.5,18h8v2h-8V18z M13.5,22h8v2h-8V22z M13.5,26h8v2h-8V26z M21.5,32h-8v-2h8V32z M42.5,32h-19v-2h19V32z M42.5,28h-19v-2h19V28
                                                                z M42.5,24h-19v-2h19V24z M23.5,20v-2h19v2H23.5z"></path>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                    </svg>
                                                </div>
                                                <span>Download CSV file</span>
                                            </button>
                                            <button class="excel">
                                                <div class="icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 48 64">
                                                        <g id="Excel_Paper_32" data-name="Excel Paper 32" transform="translate(0)">
                                                          <g id="paper_32" data-name="paper 32">
                                                            <path id="Rectangle_23" data-name="Rectangle 23" d="M0,0,16,16H0Z" transform="translate(32)" fill="#bdc3c7"></path>
                                                            <path id="Rectangle_21" data-name="Rectangle 21" d="M44,64H4a4,4,0,0,1-4-4V4A4,4,0,0,1,4,0H32V12a4,4,0,0,0,4,4H48V60A4,4,0,0,1,44,64Z" fill="#ecf0f1"></path>
                                                          </g>
                                                          <g id="Rectangle_38" data-name="Rectangle 38" transform="translate(8 24)" fill="none" stroke="#bdc3c7" stroke-miterlimit="10" stroke-width="2">
                                                            <rect width="32" height="32" stroke="none"></rect>
                                                            <rect x="1" y="1" width="30" height="30" fill="none"></rect>
                                                          </g>
                                                          <g id="lines" transform="translate(8 21)">
                                                            <g id="Group" transform="translate(28 1) rotate(90)">
                                                              <path id="Line" d="M1,3H31" transform="translate(2)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-2" data-name="Line" d="M1,3H31" transform="translate(2 6)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-3" data-name="Line" d="M1,3H31" transform="translate(2 12)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-4" data-name="Line" d="M1,3H31" transform="translate(2 18)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                            </g>
                                                            <g id="Group-2" data-name="Group" transform="translate(0 7)">
                                                              <path id="Line-5" data-name="Line" d="M1,3H31" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-6" data-name="Line" d="M1,3H31" transform="translate(0 6)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-7" data-name="Line" d="M1,3H31" transform="translate(0 12)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-8" data-name="Line" d="M1,3H31" transform="translate(0 18)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                            </g>
                                                          </g>
                                                        </g>
                                                      </svg>
                                                </div>
                                                <span>Download EXCEL file</span>
                                            </button>
                                            <button class="pdf">
                                                <div class="icon">
                                                    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                                        <style type="text/css">
                                                            .st0{fill:#F4F4F3;}
                                                            .st1{fill:#EDECEB;}
                                                            .st2{fill:#F05458;}
                                                        </style>
                                                        <g>
                                                            <g>
                                                                <path class="st0" d="M414.2,121.5v317.6c0,7.4-6,13.4-13.4,13.4H111.2c-7.4,0-13.4-6-13.4-13.4V72.9c0-7.4,6-13.4,13.4-13.4h237.6
                                                                    L414.2,121.5z"></path>
                                                                <path class="st1" d="M414.2,121.5h-52.1c-7.4,0-13.4-6-13.4-13.4V59.5L414.2,121.5z"></path>
                                                            </g>
                                                            <rect x="97.8" y="307.9" class="st2" width="316.5" height="103.3"></rect>
                                                            <g>
                                                                <path class="st0" d="M188.6,366.9h-13.3v20.3c0,2.9-0.7,5.1-2.1,6.6s-3.1,2.2-5.2,2.2c-2.2,0-3.9-0.7-5.3-2.2
                                                                    c-1.3-1.5-2-3.7-2-6.5V332c0-3.2,0.7-5.5,2.2-6.8s3.8-2.1,7-2.1h18.6c5.5,0,9.7,0.4,12.7,1.3c2.9,0.8,5.5,2.2,7.6,4.1
                                                                    c2.1,1.9,3.8,4.2,4.9,6.9s1.7,5.8,1.7,9.2c0,7.3-2.2,12.8-6.7,16.6S197.5,366.9,188.6,366.9z M185.1,334.1h-9.8v21.9h9.8
                                                                    c3.4,0,6.3-0.4,8.6-1.1c2.3-0.7,4-1.9,5.2-3.5c1.2-1.6,1.8-3.8,1.8-6.4c0-3.2-0.9-5.7-2.8-7.7
                                                                    C195.9,335.1,191.6,334.1,185.1,334.1z"></path>
                                                                <path class="st0" d="M236.5,323.2h18.9c4.9,0,9.1,0.5,12.6,1.4c3.5,0.9,6.7,2.6,9.6,5.1c7.5,6.4,11.2,16.1,11.2,29.1
                                                                    c0,4.3-0.4,8.2-1.1,11.8c-0.7,3.5-1.9,6.7-3.5,9.6c-1.6,2.8-3.6,5.4-6,7.6c-1.9,1.7-4,3.1-6.3,4.2c-2.3,1-4.7,1.8-7.3,2.2
                                                                    c-2.6,0.4-5.6,0.6-8.9,0.6h-18.9c-2.6,0-4.6-0.4-6-1.2c-1.3-0.8-2.2-1.9-2.6-3.4c-0.4-1.4-0.6-3.3-0.6-5.6V332
                                                                    c0-3.1,0.7-5.4,2.1-6.8C231.1,323.9,233.4,323.2,236.5,323.2z M242.1,334.6v48.6h11c2.4,0,4.3-0.1,5.7-0.2c1.4-0.1,2.8-0.5,4.2-1
                                                                    c1.5-0.5,2.7-1.3,3.8-2.2c4.8-4.1,7.3-11.2,7.3-21.2c0-7.1-1.1-12.4-3.2-15.9c-2.1-3.5-4.8-5.8-7.9-6.7c-3.1-1-6.9-1.4-11.3-1.4
                                                                    H242.1z"></path>
                                                                <path class="st0" d="M344.3,334.3h-28.6v18.3h23.9c2.2,0,3.9,0.5,5,1.5c1.1,1,1.6,2.3,1.6,4s-0.6,3-1.7,4c-1.1,1-2.8,1.5-4.9,1.5
                                                                    h-23.9v23.6c0,3-0.7,5.2-2,6.7c-1.4,1.4-3.1,2.2-5.2,2.2c-2.1,0-3.9-0.7-5.2-2.2c-1.4-1.5-2-3.7-2-6.6V332c0-2.1,0.3-3.8,0.9-5.1
                                                                    c0.6-1.3,1.6-2.3,2.9-2.9c1.3-0.6,3-0.9,5.1-0.9h34.2c2.3,0,4,0.5,5.2,1.5s1.7,2.4,1.7,4c0,1.7-0.6,3.1-1.7,4.1
                                                                    S346.6,334.3,344.3,334.3z"></path>
                                                            </g>
                                                        </g>
                                                    </svg>
                                                </div>
                                                <span>Download PDF file</span>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                   User List
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">

                            <?php
                                include('../../../config.php');
                                $sqlView ="SELECT 
                                                us.*,
                                                rl.name as roles
                                            FROM user us
                                            INNER JOIN roles rl on us.roles_id = rl.id
                                            ORDER BY us.id DESC";
                                $result = $conn->query($sqlView );

                                if ($result->num_rows > 0){
                                    while ($row = $result->fetch_assoc()){
                                        ?>
                                            <div class="pcb-boxes">
                                                <div class="flex">
                                                    <div class="act-details pcb-box">
                                                        <div class="ref-date">
                                                            Registered on <?php echo date('d M Y', strtotime($row['dates'])); ?> at <?php echo date('g:i A', strtotime($row['timee'])); ?>
                                                        </div>
                                                        <div class="item-name">
                                                            <?php echo $row['name'];?>
                                                        </div>
                                                        <div class="code">
                                                            <?php echo $row['code'];?>
                                                        </div>
                                                    </div>
                                                    <div class="contacts pcb-box">
                                                        <span><?php echo $row['phone'];?></span>
                                                        <span><?php echo $row['email'];?></span>
                                                    </div>

                                    
                                                    <div class="role pcb-box">
                                                        <span><?php echo $row['roles'];?></span>
                                                    </div>

    
                                                    <div class="desc pcb-box">
                                                        <?php echo $row['note'];?>
                                                    </div>
    
                    
                                                </div>
                                            </div>
                                        <?php
                                    }
                                }?>


                        </div>
                    </div>

                </div>

                <!--Admin-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                   Admin
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">

                            <?php
                                include('../../../config.php');
                                $sqlView ="SELECT 
                                                us.*,
                                                rl.name as roles
                                            FROM user us
                                            INNER JOIN roles rl on us.roles_id = rl.id
                                            WHERE us.company_id = '$company' 
                                                AND rl.name = 'Admin'
                                            ORDER BY us.id DESC";
                                $result = $conn->query($sqlView );

                                if ($result->num_rows > 0){
                                    while ($row = $result->fetch_assoc()){
                                        ?>
                                            <div class="pcb-boxes">
                                                <div class="flex">
                                                    <div class="act-details pcb-box">
                                                        <div class="ref-date">
                                                            Registered on <?php echo date('d M Y', strtotime($row['dates'])); ?> at <?php echo date('g:i A', strtotime($row['timee'])); ?>
                                                        </div>
                                                        <div class="item-name">
                                                            <?php echo $row['name'];?>
                                                        </div>
                                                        <div class="code">
                                                            <?php echo $row['code'];?>
                                                        </div>
                                                    </div>
                                                    <div class="contacts pcb-box">
                                                        <span><?php echo $row['phone'];?></span>
                                                        <span><?php echo $row['email'];?></span>
                                                    </div>

    
                                                    <div class="desc pcb-box">
                                                        <?php echo $row['note'];?>
                                                    </div>

                                                    <div class="action-btns pcb-box">
                                                        <div class="edit edit-drop">
                                                            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                                        </div>
                                                    </div>
    
                    
                                                </div>
<div class="sub-section">
    <div class="ss-body">
        <div class="edit ss-body-option">
            <form action="edit.php" method="POST" class="edit-sub-form">
                <div class="form-heading">
                    <h3>Edit User Details:</h3>
                </div>
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div class="inputs">
                    <div class="input-row">
                        <div class="inputs code">
                            <label for="code">Code:</label><br>
                            <input type="text" id="code" name="code" value="<?php echo $row['code']; ?>">
                        </div>
                        <div class="inputs name">
                            <label for="name">Name:</label><br>
                            <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>">
                        </div>
                        <div class="inputs passcode">
                            <label for="passcode">Passcode:</label><br>
                            <input type="text" id="passcode" name="passcode" value="<?php echo $row['passcode']; ?>">
                        </div>
                    </div>
                    <div class="input-row">
                        <div class="inputs email">
                            <label for="email">Email:</label><br>
                            <input type="text" id="email" name="email" value="<?php echo $row['email']; ?>">
                        </div>

                        <div class="inputs phone">
                            <label for="phone">Phone:</label><br>
                            <input type="text" id="phone" name="phone" value="<?php echo $row['phone']; ?>">
                        </div>
                    </div>
                    <div class="input-row desc">
                        <div class="inputs desc">
                            <label for="desc">Description:</label><br>
                            <textarea id="note" name="note"><?php echo $row['note']; ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="submits">
                    <button type="button" onclick="this.closest('.edit').style.display='none';">
                        <div class="icon"></div><span>CANCEL</span>
                    </button>
                    <button type="submit" name="update">
                        <div class="icon"></div><span>DONE</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
                                            </div>
                                        <?php
                                    }
                                }?>


                        </div>
                    </div>
                </div>

                <!--Manager-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                   Manager
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">

                            <?php
                                include('../../../config.php');
                                $sqlView ="SELECT 
                                                us.*,
                                                rl.name as roles
                                            FROM user us
                                            INNER JOIN roles rl on us.roles_id = rl.id
                                            WHERE us.company_id = '$company' 
                                                AND rl.name = 'Manager'
                                            ORDER BY us.id DESC";
                                $result = $conn->query($sqlView );

                                if ($result->num_rows > 0){
                                    while ($row = $result->fetch_assoc()){
                                        ?>
                                            <div class="pcb-boxes">
                                                <div class="flex">
                                                    <div class="act-details pcb-box">
                                                        <div class="ref-date">
                                                            Registered on <?php echo date('d M Y', strtotime($row['dates'])); ?> at <?php echo date('g:i A', strtotime($row['timee'])); ?>
                                                        </div>
                                                        <div class="item-name">
                                                            <?php echo $row['name'];?>
                                                        </div>
                                                        <div class="code">
                                                            <?php echo $row['code'];?>
                                                        </div>
                                                    </div>
                                                    <div class="contacts pcb-box">
                                                        <span><?php echo $row['phone'];?></span>
                                                        <span><?php echo $row['email'];?></span>
                                                    </div>

                                                    <div class="password pcb-box">
                                                        <span>User Password:</span>
                                                        <span><?php echo $row['passcode'];?></span>
                                                    </div>

    
                                                    <div class="desc pcb-box">
                                                        <?php echo $row['note'];?>
                                                    </div>

                                                    <div class="action-btns pcb-box">
                                                        <div class="edit edit-drop">
                                                            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                                        </div>
                    
                                                    </div>
    
                    
                                                </div>
                                                <div class="sub-section">
    <div class="ss-body">
        <div class="edit ss-body-option">
            <form action="edit.php" method="POST" class="edit-sub-form">
                <div class="form-heading">
                    <h3>Edit User Details:</h3>
                </div>
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div class="inputs">
                    <div class="input-row">
                        <div class="inputs code">
                            <label for="code">Code:</label><br>
                            <input type="text" id="code" name="code" value="<?php echo $row['code']; ?>">
                        </div>
                        <div class="inputs name">
                            <label for="name">Name:</label><br>
                            <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>">
                        </div>
                        <div class="inputs passcode">
                            <label for="passcode">Passcode:</label><br>
                            <input type="text" id="passcode" name="passcode" value="<?php echo $row['passcode']; ?>">
                        </div>
                    </div>
                    <div class="input-row">
                        <div class="inputs email">
                            <label for="email">Email:</label><br>
                            <input type="text" id="email" name="email" value="<?php echo $row['email']; ?>">
                        </div>

                        <div class="inputs phone">
                            <label for="phone">Phone:</label><br>
                            <input type="text" id="phone" name="phone" value="<?php echo $row['phone']; ?>">
                        </div>
                    </div>
                    <div class="input-row desc">
                        <div class="inputs desc">
                            <label for="desc">Description:</label><br>
                            <textarea id="note" name="note"><?php echo $row['note']; ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="submits">
                    <button type="button" onclick="this.closest('.edit').style.display='none';">
                        <div class="icon"></div><span>CANCEL</span>
                    </button>
                    <button type="submit" name="update">
                        <div class="icon"></div><span>DONE</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
                                            </div>
                                        <?php
                                    }
                                }?>


                        </div>
                    </div>
                </div>

                <!--Staff-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                   Staff
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">

                            <?php
                                include('../../../config.php');
                                $sqlView ="SELECT 
                                                us.*,
                                                rl.name as roles
                                            FROM user us
                                            INNER JOIN roles rl on us.roles_id = rl.id
                                            WHERE us.company_id = '$company' 
                                                AND rl.name = 'Staff'
                                            ORDER BY us.id DESC";
                                $result = $conn->query($sqlView );

                                if ($result->num_rows > 0){
                                    while ($row = $result->fetch_assoc()){
                                        ?>
                                            <div class="pcb-boxes">
                                                <div class="flex">
                                                    <div class="act-details pcb-box">
                                                        <div class="ref-date">
                                                            Registered on <?php echo date('d M Y', strtotime($row['dates'])); ?> at <?php echo date('g:i A', strtotime($row['timee'])); ?>
                                                        </div>
                                                        <div class="item-name">
                                                            <?php echo $row['name'];?>
                                                        </div>
                                                        <div class="code">
                                                            <?php echo $row['code'];?>
                                                        </div>
                                                    </div>
                                                    <div class="contacts pcb-box">
                                                        <span><?php echo $row['phone'];?></span>
                                                        <span><?php echo $row['email'];?></span>
                                                    </div>

                                                    <div class="password pcb-box">
                                                        <span>User Password:</span>
                                                        <span><?php echo $row['passcode'];?></span>
                                                    </div>

    
                                                    <div class="desc pcb-box">
                                                        <?php echo $row['note'];?>
                                                    </div>

                                                    <div class="action-btns pcb-box">
                                                        <div class="edit edit-drop">
                                                            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                                        </div>
                    
                                                    </div>
    
                    
                                                </div>
                                                <div class="sub-section">
    <div class="ss-body">
        <div class="edit ss-body-option">
            <form action="edit.php" method="POST" class="edit-sub-form">
                <div class="form-heading">
                    <h3>Edit User Details:</h3>
                </div>
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div class="inputs">
                    <div class="input-row">
                        <div class="inputs code">
                            <label for="code">Code:</label><br>
                            <input type="text" id="code" name="code" value="<?php echo $row['code']; ?>">
                        </div>
                        <div class="inputs name">
                            <label for="name">Name:</label><br>
                            <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>">
                        </div>
                        <div class="inputs passcode">
                            <label for="passcode">Passcode:</label><br>
                            <input type="text" id="passcode" name="passcode" value="<?php echo $row['passcode']; ?>">
                        </div>


                    </div>
                    <div class="input-row">
                        <div class="inputs email">
                            <label for="email">Email:</label><br>
                            <input type="text" id="email" name="email" value="<?php echo $row['email']; ?>">
                        </div>

                        <div class="inputs phone">
                            <label for="phone">Phone:</label><br>
                            <input type="text" id="phone" name="phone" value="<?php echo $row['phone']; ?>">
                        </div>
                    </div>
                    <div class="input-row desc">
                        <div class="inputs desc">
                            <label for="desc">Description:</label><br>
                            <textarea id="note" name="note"><?php echo $row['note']; ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="submits">
                    <button type="button" onclick="this.closest('.edit').style.display='none';">
                        <div class="icon"></div><span>CANCEL</span>
                    </button>
                    <button type="submit" name="update">
                        <div class="icon"></div><span>DONE</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
                                            </div>
                                        <?php
                                    }
                                }?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php
        include '../../../assets/components/root/js.php';
    ?>
</body>
</html>