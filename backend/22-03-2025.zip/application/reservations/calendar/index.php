<?php
include '../../../config.php';
session_start();

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

// Fetch room types
$rtypeQuery = "SELECT rt.* FROM rtype rt WHERE rt.company_id = '$company' ORDER BY rt.id";
$rtypeResult = $conn->query($rtypeQuery);
$rtypes = $rtypeResult->fetch_all(MYSQLI_ASSOC);

// Fetch rooms
$roomQuery = "SELECT rm.*, rt.name as rtype_name 
              FROM rooms rm 
              INNER JOIN rtype rt ON rm.rtype_id = rt.id 
              WHERE rm.company_id = '$company' 
              ORDER BY rt.id, rm.id";
$roomResult = $conn->query($roomQuery);
$rooms = $roomResult->fetch_all(MYSQLI_ASSOC);

// Fetch bookings
$bookingQuery = "SELECT 
                bk.id,
                bk.code,
                bk.fromdate,
                bk.todate,
                bk.dates,
                bk.rooms_id,
                bk.company_id,
                rm.name as room,
                cu.name as customer
              FROM bookings bk
              INNER JOIN rooms rm ON bk.rooms_id = rm.id
              INNER JOIN customer cu ON bk.customer_idno = cu.idno
              WHERE bk.company_id = '$company'
              ORDER BY bk.id";
$bookingResult = $conn->query($bookingQuery);
$bookings = $bookingResult->fetch_all(MYSQLI_ASSOC);

// Determine date range limits
$earliestDate = null;
$latestDate = null;
foreach ($bookings as $booking) {
    if (!$earliestDate || $booking['dates'] < $earliestDate) $earliestDate = $booking['dates'];
    if (!$latestDate || $booking['todate'] > $latestDate) $latestDate = $booking['todate'];
}
$startDate = $earliestDate ? new DateTime($earliestDate) : new DateTime();
$endDate = $latestDate ? new DateTime($latestDate) : (clone $startDate)->modify('+7 days');
$today = new DateTime(); // March 21, 2025

// Generate full date range
$dateRange = [];
$currentDate = clone $startDate;
while ($currentDate <= $endDate) {
    $dateRange[] = $currentDate->format('Y-m-d');
    $currentDate->modify('+1 day');
}

// Group rooms by room type
$roomsByType = [];
foreach ($rooms as $room) {
    $roomsByType[$room['rtype_name']][] = $room;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $title = 'Calendar';
    include '../../../assets/components/head/head.php'; 
    ?>
    <style>
        .pcb-calendar {
            overflow-x: auto;
            white-space: nowrap;
            max-height: 70vh;
        }
        .calendar-table {
            border-collapse: collapse;
            width: auto;
            font-size: 12px;
        }
        .calendar-table th, .calendar-table td {
            border: 1px solid #ddd;
            padding: 4px;
            text-align: center;
            vertical-align: top;
            height: 50px;
            width: 80px;
        }
        .calendar-table th.date-header {
            background-color: #0d3366;
            color: white;
            position: sticky;
            top: 0;
            z-index: 2;
        }
        .calendar-table td.room-name, .calendar-table th.rtype-header {
            position: sticky;
            left: 0;
            z-index: 1;
            background-color: #f5f5f5; /* Ensure visibility over scrolling content */
        }
        .calendar-table th.rtype-header {
            background-color: #e0e0e0;
            color: #333;
            font-weight: bold;
            text-align: left;
            padding-left: 8px;
            z-index: 3; /* Higher z-index for type headers */
        }
        .calendar-table td.room-name {
            font-weight: bold;
            text-align: left;
        }
        .booking-block {
            background-color: #4CAF50;
            color: white;
            padding: 3px;
            margin: 1px 0;
            border-radius: 2px;
            font-size: 10px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            cursor: pointer; /* Pointer cursor */
        }
    </style>
</head>
<body>
    <div class="navi">
        <?php include '../../../assets/components/navi/navi.php'; ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
            $header = 'Reservations';
            include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">The Calendar</a>
            </div>
            <div class="inline-page-body">
                <div class="page active">

                    <div class="page-content-body">
                        <div class="pcb-calendar">
                            <table class="calendar-table">
                                <thead>
                                    <tr>
                                        <th class="room-name"></th> <!-- Empty header for alignment -->
                                        <?php foreach ($dateRange as $date): ?>
                                            <th class="date-header" <?php if ($date === $today->format('Y-m-d')) echo 'style="background-color: #1a5bb8;"'; ?>>
                                                <?php echo date('D, M d', strtotime($date)); ?>
                                            </th>
                                        <?php endforeach; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($roomsByType as $rtype => $typeRooms): ?>
                                        <tr>
                                            <th class="rtype-header" colspan="<?php echo count($dateRange) + 1; ?>">
                                                <?php echo htmlspecialchars($rtype); ?>
                                            </th>
                                        </tr>
                                        <?php foreach ($typeRooms as $room): ?>
                                            <tr>
                                                <td class="room-name"><?php echo htmlspecialchars($room['name']); ?></td>
                                                <?php foreach ($dateRange as $date): ?>
                                                    <td>
                                                        <?php
                                                        foreach ($bookings as $booking) {
                                                            if ($booking['rooms_id'] == $room['id'] &&
                                                                $date >= $booking['fromdate'] &&
                                                                $date <= $booking['todate']) {
                                                                echo '<div class="booking-block">' . htmlspecialchars($booking['customer']) . '</div>';
                                                            }
                                                        }
                                                        ?>
                                                    </td>
                                                <?php endforeach; ?>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include '../../../assets/components/root/js.php'; ?>
    <script>
        // Scroll to today on page load
        document.addEventListener('DOMContentLoaded', function() {
            const todayCol = document.querySelector('th[style*="background-color: #1a5bb8"]');
            if (todayCol) {
                todayCol.scrollIntoView({ behavior: 'smooth', inline: 'center' });
            }
        });
    </script>
</body>
</html>