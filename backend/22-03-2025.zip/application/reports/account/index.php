<?php

include '../../../config.php';

session_start();

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Account Report';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Reports';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    Account Report
                </a>
                <a href="#" data-page="1">
                    Cashflow Report
                </a>

            </div>
            <div class="inline-page-body">
                <!--Account Report-->
                <div class="page active">

                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Account Report</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form">
                                <div class="form-section">
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">FROM:</label><br>
                                            <input type="date">
                                        </div>
                                        
                                        <div class="input-label">
                                            <label for="">TO:</label><br>
                                            <input type="date">
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Method:</label><br>
                                            <select name="" id="">
                                                <option value="" selected disabled>--Select Method--</option>
                                                <option value="">CASH</option>
                                                <option value="">MOBILE</option>
                                                <option value="">POS</option>
                                                <option value="">BANK</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Account:</label><br>
                                            <select name="" id="">
                                                <option value="" selected disabled>--Select Account--</option>
                                                <option value="">NMB</option>
                                                <option value="">CRDB</option>
                                                <option value="">EQUITY</option>
                                                <option value="">AZANIA</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-submit">
                                    <button class="cancel">
                                        <div class="icon">
                                            <i class="fa fa-times" aria-hidden="true"></i>
                                        </div>
                                        <span>CANCEL</span>
                                    </button>
                                    <button class="confirm">
                                        <div class="icon">
                                            <i class="fa fa-check" aria-hidden="true"></i>
                                        </div>
                                        <span>CONFIRM</span>
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>

                </div>

                <!--Cashflow Report-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Cashflow Report</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form">
                                <div class="form-section">
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">FROM:</label><br>
                                            <input type="date">
                                        </div>
                                        
                                        <div class="input-label">
                                            <label for="">TO:</label><br>
                                            <input type="date">
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Direction:</label><br>
                                            <select name="" id="">
                                                <option value="" selected disabled>--Select Method--</option>
                                                <option value="">SENT</option>
                                                <option value="">RECEIVED</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Method:</label><br>
                                            <select name="" id="">
                                                <option value="" selected disabled>--Select Method--</option>
                                                <option value="">CASH</option>
                                                <option value="">MOBILE</option>
                                                <option value="">POS</option>
                                                <option value="">BANK</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Account:</label><br>
                                            <select name="" id="">
                                                <option value="" selected disabled>--Select Account--</option>
                                                <option value="">NMB</option>
                                                <option value="">CRDB</option>
                                                <option value="">EQUITY</option>
                                                <option value="">AZANIA</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-submit">
                                    <button class="cancel">
                                        <div class="icon">
                                            <i class="fa fa-times" aria-hidden="true"></i>
                                        </div>
                                        <span>CANCEL</span>
                                    </button>
                                    <button class="confirm">
                                        <div class="icon">
                                            <i class="fa fa-check" aria-hidden="true"></i>
                                        </div>
                                        <span>CONFIRM</span>
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>


    <?php
        include '../../../assets/components/root/js.php';
    ?>

</body>
</html>