<?php

include '../../../config.php';

session_start();

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

$etypeQuery = "SELECT et.*
               FROM etype et
               WHERE et.company_id = '$company'
               ORDER BY et.id DESC";
$etypeResult = $conn->query($etypeQuery);
$etypes = $etypeResult->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Expenses Report';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Reports';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    Expenses Report
                </a>
                <a href="#" data-page="1">
                    Expense Type Report
                </a>

            </div>
            <div class="inline-page-body">
                <!--Expenses Report-->
                <div class="page active">

                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Expenses Report</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form">
                                <div class="form-section">
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">FROM:</label><br>
                                            <input type="date">
                                        </div>
                                        
                                        <div class="input-label">
                                            <label for="">TO:</label><br>
                                            <input type="date">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-submit">
                                    <button class="cancel">
                                        <div class="icon">
                                            <i class="fa fa-times" aria-hidden="true"></i>
                                        </div>
                                        <span>CANCEL</span>
                                    </button>
                                    <button class="confirm">
                                        <div class="icon">
                                            <i class="fa fa-check" aria-hidden="true"></i>
                                        </div>
                                        <span>CONFIRM</span>
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>

                </div>

                <!--Expense Type Report-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Expense Type Report</h2>
                            </div>
                            <hr>

<form action="" class="report-form" id="reportForm">
    <div class="form-section">
        <div class="sec">
            <div class="input-label">
                <label for="fromdate">FROM:</label><br>
                <input type="date" name="fromdate" id="fromdate" required>
            </div>
            <div class="input-label">
                <label for="todate">TO:</label><br>
                <input type="date" name="todate" id="todate" required>
            </div>
        </div>
        <div class="sec">
            <div class="input-label">
                <label for="etype">Expense Type:<span>*</span></label><br>
                <select name="etype" id="etype" required>
                    <option value="" selected disabled>--Select an Expense Type--</option>
                    <?php
                        foreach ($etypes as $etype) {
                            echo "<option value='{$etype['id']}'>{$etype['name']}</option>";
                        }
                    ?>
                </select>
            </div>
        </div>
    </div>
    <div class="form-submit">
        <button type="button" class="cancel" onclick="this.closest('.report-form').reset();">
            <div class="icon">
                <i class="fa fa-times" aria-hidden="true"></i>
            </div>
            <span>CANCEL</span>
        </button>
        <button type="submit" class="confirm">
            <div class="icon">
                <i class="fa fa-check" aria-hidden="true"></i>
            </div>
            <span>CONFIRM</span>
        </button>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const reportForm = document.getElementById('reportForm');

    reportForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch('generate_expense_report.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.blob();
        })
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `Expense_Report_${new Date().toISOString().slice(0,10)}.pdf`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
        })
        .catch(error => console.error('Error generating PDF:', error));
    });
});
</script>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>


    <?php
        include '../../../assets/components/root/js.php';
    ?>

</body>
</html>