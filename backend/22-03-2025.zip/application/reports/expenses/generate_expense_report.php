<?php
ob_start();
require('../../../fpdf/fpdf.php');
include '../../../config.php';
session_start();

ob_clean();

if (!isset($_SESSION['company_id'])) {
    header('Content-Type: text/plain');
    die('Unauthorized');
}

$company_id = $_SESSION['company_id'];
$fromdate = $_POST['fromdate'] ?? '';
$todate = $_POST['todate'] ?? '';
$etype_id = $_POST['etype'] ?? '';

if (!$fromdate || !$todate || !$etype_id) {
    header('Content-Type: text/plain');
    die('Missing required parameters');
}

// Validate dates
$start = new DateTime($fromdate);
$end = new DateTime($todate);
if ($start > $end) {
    header('Content-Type: text/plain');
    die('From date must be before To date');
}

// Fetch expense type name
$query = "SELECT name FROM etype WHERE id = ? AND company_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $etype_id, $company_id);
$stmt->execute();
$result = $stmt->get_result();
$etype = $result->fetch_assoc();
$etype_name = $etype['name'] ?? 'Unknown Expense Type';
$stmt->close();

// Format dates for header
$fromdate_formatted = $start->format('d F Y');
$todate_formatted = $end->format('d F Y');

// Custom PDF class
class PDF extends FPDF {
    function Header() {
        $this->SetMargins(15, 15, 15);
        $this->SetFont('Arial', 'B', 14);
        $this->SetTextColor(0, 51, 102);
        $this->Cell(0, 10, "Expense Report", 0, 1, 'C');
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 8, "For Expense Type: $GLOBALS[etype_name]  |  From $GLOBALS[fromdate_formatted] To $GLOBALS[todate_formatted]", 0, 1, 'C');
        $this->SetFont('Arial', 'I', 9);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 6, 'Generated on: ' . date('d F Y H:i'), 0, 1, 'C');
        $this->Ln(10);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . ' of {nb}', 0, 0, 'C');
    }

    function FancyTable($header, $data, $total) {
        $this->SetFont('Arial', 'B', 11);
        $this->SetFillColor(0, 51, 102);
        $this->SetTextColor(255, 255, 255);
        $this->SetDrawColor(0, 51, 102);
        $w = array(60, 60); // Widths: Date, Amount Spent
        for ($i = 0; $i < count($header); $i++) {
            $this->Cell($w[$i], 8, $header[$i], 1, 0, 'C', true);
        }
        $this->Ln();

        $this->SetFont('Arial', '', 10);
        $this->SetFillColor(245, 245, 245);
        $fill = false;
        foreach ($data as $row) {
            $this->SetTextColor(0, 0, 0);
            $this->Cell($w[0], 7, $row['date'], 1, 0, 'L', $fill);
            $this->Cell($w[1], 7, number_format($row['amount_spent'], 2), 1, 0, 'R', $fill);
            $this->Ln();
            $fill = !$fill;
        }

        // Total row
        $this->SetFont('Arial', 'B', 11);
        $this->SetFillColor(200, 200, 200);
        $this->Cell($w[0], 8, 'Total Amount Spent:', 1, 0, 'R', true);
        $this->Cell($w[1], 8, number_format($total, 2), 1, 0, 'R', true);
    }
}

// Generate data for date range
$data = [];
$total_amount_spent = 0;
$end->modify('+1 day');
$interval = new DateInterval('P1D');
$daterange = new DatePeriod($start, $interval, $end);

foreach ($daterange as $date) {
    $date_str = $date->format('Y-m-d');

    // Amount Spent (sum(expenses.amount) for etype_id)
    $query = "SELECT SUM(amount) as expense_sum 
              FROM expenses 
              WHERE company_id = ? 
              AND etype_id = ? 
              AND dates = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        header('Content-Type: text/plain');
        die('SQL Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("iis", $company_id, $etype_id, $date_str);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $amount_spent = floatval($row['expense_sum'] ?? 0);
    $total_amount_spent += $amount_spent;
    $stmt->close();

    $data[] = [
        'date' => $date_str,
        'amount_spent' => $amount_spent
    ];
}

// Reverse data for descending order
$data = array_reverse($data);

$conn->close();

// Generate PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$header = ['Date', 'Amount Spent'];
$pdf->FancyTable($header, $data, $total_amount_spent);

// Set headers
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="Expense_Report_' . $etype_name . '_' . $fromdate . '_to_' . $todate . '.pdf"');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Output PDF
$pdf->Output('D', 'Expense_Report_' . $etype_name . '_' . $fromdate . '_to_' . $todate . '.pdf');
exit();
