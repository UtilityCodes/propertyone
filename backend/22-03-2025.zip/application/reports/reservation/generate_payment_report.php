<?php
ob_start();
require('../../../fpdf/fpdf.php');
include '../../../config.php';
session_start();

ob_clean();

if (!isset($_SESSION['company_id'])) {
    header('Content-Type: text/plain');
    die('Unauthorized');
}

$company_id = $_SESSION['company_id'];
$fromdate = $_POST['fromdate'] ?? '';
$todate = $_POST['todate'] ?? '';

if (!$fromdate || !$todate) {
    header('Content-Type: text/plain');
    die('Missing required parameters');
}

// Validate dates
$start = new DateTime($fromdate);
$end = new DateTime($todate);
if ($start > $end) {
    header('Content-Type: text/plain');
    die('From date must be before To date');
}

// Format dates for header
$fromdate_formatted = $start->format('d F Y');
$todate_formatted = $end->format('d F Y');

// Custom PDF class
class PDF extends FPDF {
    function Header() {
        $this->SetMargins(15, 15, 15);
        $this->SetFont('Arial', 'B', 14);
        $this->SetTextColor(0, 51, 102);
        $this->Cell(0, 10, "Payment and Reservation Report", 0, 1, 'C');
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 8, "From $GLOBALS[fromdate_formatted] To $GLOBALS[todate_formatted]", 0, 1, 'C');
        $this->SetFont('Arial', 'I', 9);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 6, 'Generated on: ' . date('d F Y H:i'), 0, 1, 'C');
        $this->Ln(10);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . ' of {nb}', 0, 0, 'C');
    }

    function FancyTable($header, $data, $totals) {
        $this->SetFont('Arial', 'B', 11);
        $this->SetFillColor(0, 51, 102);
        $this->SetTextColor(255, 255, 255);
        $this->SetDrawColor(0, 51, 102);
        $w = array(40, 40, 40, 40); // Widths: Date, Reservation Amounts, Direct Payments, Credit Payments
        for ($i = 0; $i < count($header); $i++) {
            $this->Cell($w[$i], 8, $header[$i], 1, 0, 'C', true);
        }
        $this->Ln();

        $this->SetFont('Arial', '', 10);
        $this->SetFillColor(245, 245, 245);
        $fill = false;
        foreach ($data as $row) {
            $this->SetTextColor(0, 0, 0);
            $this->Cell($w[0], 7, $row['date'], 1, 0, 'L', $fill);
            $this->Cell($w[1], 7, number_format($row['reservation_amount'], 2), 1, 0, 'R', $fill);
            $this->Cell($w[2], 7, number_format($row['direct_payments'], 2), 1, 0, 'R', $fill);
            $this->Cell($w[3], 7, number_format($row['credit_payments'], 2), 1, 0, 'R', $fill);
            $this->Ln();
            $fill = !$fill;
        }

        // Totals row
        $this->SetFont('Arial', 'B', 11);
        $this->SetFillColor(200, 200, 200);
        $this->Cell($w[0], 8, 'Totals:', 1, 0, 'R', true);
        $this->Cell($w[1], 8, number_format($totals['reservation_amount'], 2), 1, 0, 'R', $fill);
        $this->Cell($w[2], 8, number_format($totals['direct_payments'], 2), 1, 0, 'R', $fill);
        $this->Cell($w[3], 8, number_format($totals['credit_payments'], 2), 1, 0, 'R', $fill);
    }
}

// Generate data for date range
$data = [];
$totals = ['reservation_amount' => 0, 'direct_payments' => 0, 'credit_payments' => 0];
$end->modify('+1 day');
$interval = new DateInterval('P1D');
$daterange = new DatePeriod($start, $interval, $end);

foreach ($daterange as $date) {
    $date_str = $date->format('Y-m-d');

    // Reservation Amounts (sum(bookings.amount))
    $query = "SELECT SUM(amount) as reservation_sum 
              FROM bookings 
              WHERE company_id = ? 
              AND dates = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        header('Content-Type: text/plain');
        die('SQL Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("is", $company_id, $date_str);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $reservation_amount = floatval($row['reservation_sum'] ?? 0);
    $totals['reservation_amount'] += $reservation_amount;
    $stmt->close();

    // Direct Payments (sum(payments.amount) where paytype.name = 'DIRECT')
    $query = "SELECT SUM(p.amount) as direct_sum 
              FROM payments p 
              INNER JOIN paytype pt ON p.paytype_id = pt.id 
              WHERE p.company_id = ? 
              AND p.dates = ? 
              AND pt.name = 'DIRECT'";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        header('Content-Type: text/plain');
        die('SQL Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("is", $company_id, $date_str);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $direct_payments = floatval($row['direct_sum'] ?? 0);
    $totals['direct_payments'] += $direct_payments;
    $stmt->close();

    // Credit Payments (sum(payments.amount) where paytype.name = 'CREDIT')
    $query = "SELECT SUM(p.amount) as credit_sum 
              FROM payments p 
              INNER JOIN paytype pt ON p.paytype_id = pt.id 
              WHERE p.company_id = ? 
              AND p.dates = ? 
              AND pt.name = 'CREDIT'";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        header('Content-Type: text/plain');
        die('SQL Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("is", $company_id, $date_str);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $credit_payments = floatval($row['credit_sum'] ?? 0);
    $totals['credit_payments'] += $credit_payments;
    $stmt->close();

    $data[] = [
        'date' => $date_str,
        'reservation_amount' => $reservation_amount,
        'direct_payments' => $direct_payments,
        'credit_payments' => $credit_payments
    ];
}

// Reverse data for descending order
$data = array_reverse($data);

$conn->close();

// Generate PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$header = ['Date', 'Reservation Amounts', 'Direct Payments', 'Credit Payments'];
$pdf->FancyTable($header, $data, $totals);

// Set headers
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="Payment_Report_' . $fromdate . '_to_' . $todate . '.pdf"');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Output PDF
$pdf->Output('D', 'Payment_Report_' . $fromdate . '_to_' . $todate . '.pdf');
exit();
