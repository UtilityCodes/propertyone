<?php
// arrdep.php


date_default_timezone_set('Africa/Dar_es_Salaam'); // Your timezone

// Company ID from session
$companyId = $_SESSION['company_id'];

// Current date and time
$currentDate = date('Y-m-d');
$currentTime = date('H:i:s');

// Today's Arrivals (list of times and guests)
$query = "
    SELECT 
        bk.checkintime,
        cu.name AS guest
    FROM bookings bk
    INNER JOIN rooms rm ON bk.rooms_id = rm.id
    INNER JOIN rtype rt ON rm.rtype_id = rt.id
    INNER JOIN customer cu ON bk.customer_idno = cu.idno
    INNER JOIN user us ON bk.user_id = us.id
    WHERE bk.company_id = ?
      AND bk.checkindate = ?
      AND bk.checkintime <= ?
      AND bk.checkoutdate IS NULL
    ORDER BY bk.checkintime DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $companyId, $currentDate, $currentTime);
$stmt->execute();
$result = $stmt->get_result();
$arrivalList = $result->fetch_all(MYSQLI_ASSOC);

// Format arrivals into arrays
$arrivalTimesList = [];
$arrivalGuestsList = [];
if ($arrivalList) {
    foreach ($arrivalList as $arrivalItem) {
        $arrivalTimesList[] = date('h:i A', strtotime($arrivalItem['checkintime']));
        $arrivalGuestsList[] = $arrivalItem['guest'];
    }
} else {
    $arrivalTimesList[] = 'N/A';
    $arrivalGuestsList[] = 'No arrivals yet';
}

// Today's Departures (list of times and guests)
$query = "
    SELECT 
        bk.totime,
        cu.name AS guest
    FROM bookings bk
    INNER JOIN rooms rm ON bk.rooms_id = rm.id
    INNER JOIN rtype rt ON rm.rtype_id = rt.id
    INNER JOIN customer cu ON bk.customer_idno = cu.idno
    INNER JOIN user us ON bk.user_id = us.id
    WHERE bk.company_id = ?
      AND bk.checkindate IS NOT NULL
      AND bk.todate = ?
      AND bk.totime <= ?
      AND bk.checkoutdate IS NULL
    ORDER BY bk.totime DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $companyId, $currentDate, $currentTime);
$stmt->execute();
$result = $stmt->get_result();
$departureList = $result->fetch_all(MYSQLI_ASSOC);

// Format departures into arrays
$departureTimesList = [];
$departureGuestsList = [];
if ($departureList) {
    foreach ($departureList as $departureItem) {
        $departureTimesList[] = date('h:i A', strtotime($departureItem['totime']));
        $departureGuestsList[] = $departureItem['guest'];
    }
} else {
    $departureTimesList[] = 'N/A';
    $departureGuestsList[] = 'No departures yet';
}

