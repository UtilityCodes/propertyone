
<style>
.calendar.room, .rt, .rms, .sched { 
    display: block; 
    min-height: 50px;
    border: 1px solid #000; 
}
.rtype-btn, .room-btn { 
    padding: 5px; 
    margin: 2px; 
    background: #f0f0f0; 
    border: 1px solid #ccc; 
}
.available-box { 
    background: #e0ffe0; 
}
.customer-box { 
    background: #ffe0e0; 
}
/* Styles for arrivals/departures */
.up .arr, .up .dep {
    width: 48%;
    padding: 10px;
}
.up .heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}
.up .title {
    font-size: 16px;
    font-weight: bold;
    color: #0d3366;
}
.up .more a {
    font-size: 12px;
    color: #1a5bb8;
    text-decoration: none;
}
.up .content {
    max-height: 150px; /* Optional: scroll if many entries */
    overflow-y: auto;
}
.up .entry {
    display: flex;
    justify-content: space-between;
    padding: 5px;
    background-color: #f5f5f5;
    margin-bottom: 5px;
    border-radius: 3px;
}
.up .time {
    font-weight: bold;
    font-size: 12px;
}
.up .customer {
    font-size: 12px;
}
</style>

<div class="dashbody sec-1">
    <div class="left">
        <div class="graph booking">
            <div class="heading">
                <div class="title">Booking</div>
                <div class="more"><a href="">More</a></div>
            </div>
            <div class="thegraph">
                <canvas id="bookingChart"></canvas>
            </div>
        </div>
        <div class="guest-btns">
            <div class="flex">
                <?php foreach ($guests as $guest): ?>
                    <button><?php echo htmlspecialchars($guest); ?></button>
                <?php endforeach; ?>
                <?php if (empty($guests)): ?>
                    <p>No current guests.</p>
                <?php endif; ?>
            </div>
            <div class="flex-more">
                <a href="../../reservations/guest">See More Guests</a>
            </div>
        </div>
    </div>
    <div class="right">
        <div class="graph occupancy">
            <div class="thegraph">
                <canvas id="occupancyChart"></canvas>
            </div>
            <div class="descr">
                <div class="item">
                    <div class="item-details">
                        <div class="colour vacant"></div>
                        <div class="name">Vacant</div>
                    </div>
                    <div class="item-capacity">
                        <span><?php echo $vacantRooms; ?></span>
                    </div>
                </div>
                <div class="item">
                    <div class="item-details">
                        <div class="colour occupied"></div>
                        <div class="name">Occupied</div>
                    </div>
                    <div class="item-capacity">
                        <span><?php echo $occupiedRooms; ?></span>
                    </div>
                </div>
                <div class="item">
                    <div class="item-details">
                        <div class="colour not-ready"></div>
                        <div class="name">Not Ready</div>
                    </div>
                    <div class="item-capacity">
                        <span><?php echo $notReadyRooms; ?></span>
                    </div>
                </div>
            </div>
            <div class="more-descr">
                <article>There are <span><?php echo $totalRooms; ?></span> Rooms Currently</article>
            </div>
        </div>
    </div>
</div>
<div class="dashbody sec-2">
    <div class="left">
        <div class="up">
            <div class="arr">
                <div class="heading">
                    <div class="title">Today's Arrival</div>
                    <div class="more"><a href="">See More</a></div>
                </div>
                <div class="content">
                    <?php for ($i = 0; $i < count($arrivalTimesList); $i++): ?>
                        <div class="entry">
                            <div class="time"><?php echo htmlspecialchars($arrivalTimesList[$i]); ?></div>
                            <div class="customer"><?php echo htmlspecialchars($arrivalGuestsList[$i]); ?></div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
            <div class="dep">
                <div class="heading">
                    <div class="title">Today's Departure</div>
                    <div class="more"><a href="">See More</a></div>
                </div>
                <div class="content">
                    <?php for ($i = 0; $i < count($departureTimesList); $i++): ?>
                        <div class="entry">
                            <div class="time"><?php echo htmlspecialchars($departureTimesList[$i]); ?></div>
                            <div class="customer"><?php echo htmlspecialchars($departureGuestsList[$i]); ?></div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
        <div class="down">
            <div class="graph payment">
                <div class="heading">
                    <div class="title">Payments</div>
                    <div class="more"><a href="">See More</a></div>
                </div>
                <div class="thegraph">
                    <canvas id="paymentChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="right">
        <div class="calendar room">
            <div class="heading">
                <div class="title">Room Calendar</div>
                <div class="more"><a href="">Go To Calendar</a></div>
            </div>
            <div class="rt">
                <div class="flex" id="room-types"></div>
            </div>
            <div class="rms">
                <div class="flex" id="room-buttons"></div>
            </div>
            <div class="sched" id="schedule-display"></div>
        </div>
    </div>
</div>