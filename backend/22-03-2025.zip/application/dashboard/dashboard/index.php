<?php
// index.php for dashboard
include '../../../config.php';
session_start();


if (!isset($_SESSION['company_id']) || !isset($_SESSION['roles'])) {
    header("Location: login.php");
    exit();
}

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

include 'dashcards.php';
include 'roomstatus.php';
include 'bookings.php';
include 'guests.php';
include 'arrdep.php';
include 'paymentsgraph.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Dashboard';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php include '../../../assets/components/navi/navi.php'; ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Dashboard';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>
        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">Today</a>
                <a href="#" data-page="1">Yesterday</a>
                <a href="#" data-page="2">Past Week</a>
                <a href="#" data-page="3">Past Month</a>
            </div>
            <div class="inline-page-body">
                <!-- Today -->
                <div class="page active">
                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Arrivals</div>
                                        <div class="item-figure"><?php echo $arrivals; ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Departure</div>
                                        <div class="item-figure"><?php echo $departures; ?></div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">Direct Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($directPayment); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Credit Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($creditPayment); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Total Revenue</div>
                                        <div class="item-figure"><?php echo formatNumber($totalRevenue); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure"><?php echo formatNumber($totalCost); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Reservation Payments</div>
                                        <div class="item-figure"><?php echo formatNumber($reservationPayments); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Deposits</div>
                                        <div class="item-figure"><?php echo formatNumber($deposits); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure"><?php echo formatNumber($reservationRefunds); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure"><?php echo formatNumber($withdraws); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure"><?php echo formatNumber($expenses); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php include 'dashbody.php'; ?>
                    </div>
                </div>

                <!-- Yesterday -->
                <div class="page">
                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Arrivals</div>
                                        <div class="item-figure"><?php echo $yesterday_arrivals; ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Departure</div>
                                        <div class="item-figure"><?php echo $yesterday_departures; ?></div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">Direct Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_directPayment); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Credit Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_creditPayment); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Total Revenue</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_totalRevenue); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_totalCost); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Reservation Payments</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_reservationPayments); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Deposits</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_deposits); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_reservationRefunds); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_withdraws); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_expenses); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Past Week -->
                <div class="page">
                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Arrivals</div>
                                        <div class="item-figure"><?php echo $week_arrivals; ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Departure</div>
                                        <div class="item-figure"><?php echo $week_departures; ?></div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">Direct Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($week_directPayment); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Credit Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($week_creditPayment); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Total Revenue</div>
                                        <div class="item-figure"><?php echo formatNumber($week_totalRevenue); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure"><?php echo formatNumber($week_totalCost); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Reservation Payments</div>
                                        <div class="item-figure"><?php echo formatNumber($week_reservationPayments); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Deposits</div>
                                        <div class="item-figure"><?php echo formatNumber($week_deposits); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure"><?php echo formatNumber($week_reservationRefunds); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure"><?php echo formatNumber($week_withdraws); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure"><?php echo formatNumber($week_expenses); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Past Month -->
                <div class="page">
                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Arrivals</div>
                                        <div class="item-figure"><?php echo $month_arrivals; ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Departure</div>
                                        <div class="item-figure"><?php echo $month_departures; ?></div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">Direct Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($month_directPayment); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Credit Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($month_creditPayment); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Total Revenue</div>
                                        <div class="item-figure"><?php echo formatNumber($month_totalRevenue); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure"><?php echo formatNumber($month_totalCost); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Reservation Payments</div>
                                        <div class="item-figure"><?php echo formatNumber($month_reservationPayments); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Deposits</div>
                                        <div class="item-figure"><?php echo formatNumber($month_deposits); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure"><?php echo formatNumber($month_reservationRefunds); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure"><?php echo formatNumber($month_withdraws); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure"><?php echo formatNumber($month_expenses); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
        include '../../../assets/components/root/js.php';
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        console.log('DOM fully loaded');
        console.log('Room types element:', document.getElementById('room-types'));
        console.log('Room buttons element:', document.getElementById('room-buttons'));
        console.log('Schedule display element:', document.getElementById('schedule-display'));

        initializeCharts();
        initializeRoomCalendar();

        function initializeCharts() {
            const occupancyCtx = document.getElementById('occupancyChart').getContext('2d');
            new Chart(occupancyCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Vacant', 'Occupied', 'Not Ready'],
                    datasets: [{
                        data: [<?php echo $vacantRooms; ?>, <?php echo $occupiedRooms; ?>, <?php echo $notReadyRooms; ?>],
                        backgroundColor: ['green', 'blue', 'red'],
                        borderWidth: 1
                    }]
                },
                options: {
                    cutout: '50%',
                    rotation: -90,
                    circumference: 180,
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: { enabled: true }
                    }
                }
            });

            const bookingCtx = document.getElementById('bookingChart').getContext('2d');
            new Chart(bookingCtx, {
                type: 'line',
                data: {
                    labels: <?php echo $datesJson; ?>,
                    datasets: [{
                        label: 'Bookings',
                        data: <?php echo $countsJson; ?>,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        fill: true,
                        tension: 0.1,
                        pointRadius: 3,
                        pointBackgroundColor: 'rgba(75, 192, 192, 1)'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: { title: { display: true, text: 'Date' }, ticks: { maxTicksLimit: 10 } },
                        y: { title: { display: true, text: 'Number of Bookings' }, beginAtZero: true, ticks: { stepSize: 1 } }
                    },
                    plugins: {
                        legend: { display: true, position: 'top' },
                        tooltip: { enabled: true }
                    }
                }
            });

            const paymentCtx = document.getElementById('paymentChart').getContext('2d');
            new Chart(paymentCtx, {
                type: 'bar',
                data: {
                    labels: <?php echo $datesJson; ?>,
                    datasets: [
                        {
                            label: 'Reservation Amounts',
                            data: <?php echo $reservationJson; ?>,
                            backgroundColor: 'rgba(54, 162, 235, 0.7)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            borderWidth: 1
                        },
                        {
                            label: 'Direct Payments',
                            data: <?php echo $directJson; ?>,
                            backgroundColor: 'rgba(75, 192, 192, 0.7)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1
                        },
                        {
                            label: 'Credit Payments',
                            data: <?php echo $creditJson; ?>,
                            backgroundColor: 'rgba(255, 99, 132, 0.7)',
                            borderColor: 'rgba(255, 99, 132, 1)',
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: { title: { display: true, text: 'Date' }, ticks: { maxTicksLimit: 10 } },
                        y: { title: { display: true, text: 'Amount' }, beginAtZero: true }
                    },
                    plugins: {
                        legend: { display: true, position: 'top' },
                        tooltip: { enabled: true, mode: 'index', intersect: false }
                    }
                }
            });
        }

        function initializeRoomCalendar() {
            console.log('Initializing room calendar...');
            
            // Load room types
            fetch('./roomcalendar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=get_room_types'
            })
            .then(response => {
                console.log('Room types fetch status:', response.status);
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(roomTypes => {
                console.log('Room types received:', roomTypes);
                if (roomTypes.error) {
                    console.error('Server error:', roomTypes.error);
                    return;
                }
                const container = document.getElementById('room-types');
                if (!container) {
                    console.error('Room types container not found');
                    return;
                }
                container.innerHTML = '';
                if (roomTypes.length === 0) {
                    container.innerHTML = '<p>No room types available</p>';
                } else {
                    roomTypes.forEach(type => {
                        const btn = document.createElement('button');
                        btn.className = 'rtype-btn';
                        btn.dataset.rtypeId = type.id;
                        btn.textContent = type.name;
                        btn.addEventListener('click', loadRooms);
                        container.appendChild(btn);
                    });
                }

                // Load default room after room types are populated
                loadDefaultRoom();
            })
            .catch(error => console.error('Fetch error for room types:', error));
        }

        function loadRooms(event) {
            const rtypeId = event.target.dataset.rtypeId;
            console.log('Loading rooms for rtype_id:', rtypeId);
            fetch('./roomcalendar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=get_rooms&rtype_id=${rtypeId}`
            })
            .then(response => {
                console.log('Rooms fetch status:', response.status);
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(rooms => {
                console.log('Rooms received:', rooms);
                if (rooms.error) {
                    console.error('Server error:', rooms.error);
                    return;
                }
                const container = document.getElementById('room-buttons');
                if (!container) {
                    console.error('Room buttons container not found');
                    return;
                }
                container.innerHTML = '';
                if (rooms.length === 0) {
                    container.innerHTML = '<p>No rooms available</p>';
                } else {
                    rooms.forEach(room => {
                        const btn = document.createElement('button');
                        btn.className = 'room-btn';
                        btn.dataset.roomId = room.id;
                        btn.textContent = room.name;
                        btn.addEventListener('click', loadSchedule);
                        container.appendChild(btn);
                    });
                }
                document.getElementById('schedule-display').innerHTML = '';
            })
            .catch(error => console.error('Fetch error for rooms:', error));
        }

        function loadSchedule(event) {
            const roomId = event.target.dataset.roomId;
            console.log('Loading schedule for room_id:', roomId);
            fetch('./roomcalendar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=get_schedule&room_id=${roomId}`
            })
            .then(response => {
                console.log('Schedule fetch status:', response.status);
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(schedule => {
                console.log('Schedule received:', schedule);
                if (schedule.error) {
                    console.error('Server error:', schedule.error);
                    return;
                }
                const container = document.getElementById('schedule-display');
                if (!container) {
                    console.error('Schedule display container not found');
                    return;
                }
                container.innerHTML = '';
                schedule.forEach(day => {
                    const div = document.createElement('div');
                    div.className = 'flex ' + (day.available ? 'available-box' : 'customer-box');
                    div.innerHTML = `
                        <div class="day">
                            <div class="flex">
                                <div class="date">${day.date}</div>
                                <div class="day">${day.day}</div>
                            </div>
                        </div>
                        <div class="customer">
                            <div class="flex">
                                <div class="${day.available ? 'available' : 'customer'}">
                                    ${day.available ? 'Available for Booking' : day.customer}
                                </div>
                                <div class="icon"></div>
                            </div>
                        </div>
                    `;
                    container.appendChild(div);
                });
            })
            .catch(error => console.error('Fetch error for schedule:', error));
        }

        function loadDefaultRoom() {
            console.log('Fetching default room...');
            fetch('./roomcalendar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=get_default_room'
            })
            .then(response => {
                console.log('Default room fetch status:', response.status);
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(defaultRoom => {
                console.log('Default room received:', defaultRoom);
                if (defaultRoom.error) {
                    console.log('No default room found:', defaultRoom.error);
                    return; // Don’t proceed if no default room
                }

                // Simulate clicking the room type button for the default room’s rtype_id
                const rtypeBtn = document.querySelector(`.rtype-btn[data-rtype-id="${defaultRoom.rtype_id}"]`);
                if (rtypeBtn) {
                    console.log('Simulating click on rtype_id:', defaultRoom.rtype_id);
                    rtypeBtn.click(); // Load rooms for this type

                    // Wait briefly for rooms to load, then load the default room’s schedule
                    setTimeout(() => {
                        const roomBtn = document.querySelector(`.room-btn[data-room-id="${defaultRoom.id}"]`);
                        if (roomBtn) {
                            console.log('Simulating click on default room_id:', defaultRoom.id);
                            roomBtn.style.backgroundColor = '#ffff99'; // Highlight default room
                            roomBtn.click(); // Load schedule
                        } else {
                            console.error('Default room button not found after loading rooms');
                        }
                    }, 100); // Small delay to ensure rooms are rendered
                } else {
                    console.error('Room type button not found for rtype_id:', defaultRoom.rtype_id);
                }
            })
            .catch(error => console.error('Fetch error for default room:', error));
        }
    });
    </script>
    <?php
    // Close the database connection after all operations
    $conn->close();
    ?>
</body>
</html>



