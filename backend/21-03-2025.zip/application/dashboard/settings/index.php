<?php

include '../../../config.php';

session_start();

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Settings | Company Details';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Company';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    Settings
                </a>
                <a href="#" data-page="1">
                    Details
                </a>

            </div>
            <div class="inline-page-body">
                <!--Settings-->
                <div class="page active">
                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Settings:</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form">
                                <div class="form-section">
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Code:</label><br>
                                            <input type="text" value="Co-4236789">
                                        </div>
                                        <div class="input-label">
                                            <label for="">Name:</label><br>
                                            <input type="text" value="Capital Inn">
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">District:</label><br>
                                            <input type="text" value="Makole">
                                        </div>
                                        <div class="input-label">
                                            <label for="">City:</label><br>
                                            <input type="text" value="Dodoma">
                                        </div>
                                        <div class="input-label">
                                            <label for="">Country:</label><br>
                                            <input type="text" value="Tanzania">
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Phone:</label><br>
                                            <input type="text" value="0765432189">
                                        </div>
                                        <div class="input-label">
                                            <label for="">Email:</label><br>
                                            <input type="text" value="capitalinn@gmail.com">
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Description:</label><br>
                                            <textarea name="" id="">This is the beginning</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-submit">
                                    <button class="cancel">
                                        <div class="icon">
                                            <i class="fa fa-times" aria-hidden="true"></i>
                                        </div>
                                        <span>CANCEL</span>
                                    </button>
                                    <button class="confirm">
                                        <div class="icon">
                                            <i class="fa fa-check" aria-hidden="true"></i>
                                        </div>
                                        <span>CONFIRM</span>
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>


                </div>

                <!--Details-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Company Details:</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form">
                                <div class="form-section">
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Code:</label><br>
                                            <input type="text" value="Co-4236789" disabled>
                                        </div>
                                        <div class="input-label">
                                            <label for="">Name:</label><br>
                                            <input type="text" value="Capital Inn" disabled>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">District:</label><br>
                                            <input type="text" value="Makole" disabled>
                                        </div>
                                        <div class="input-label">
                                            <label for="">City:</label><br>
                                            <input type="text" value="Dodoma" disabled>
                                        </div>
                                        <div class="input-label">
                                            <label for="">Country:</label><br>
                                            <input type="text" value="Tanzania" disabled>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Phone:</label><br>
                                            <input type="text" value="0765432189" disabled>
                                        </div>
                                        <div class="input-label">
                                            <label for="">Email:</label><br>
                                            <input type="text" value="capitalinn@gmail.com" disabled>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Description:</label><br>
                                            <textarea name="" id="" disabled>This is the beginning</textarea>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>


    <?php
        include '../../../assets/components/root/js.php';
    ?>
</body>
</html>