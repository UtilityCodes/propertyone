<?php

$sql = "SELECT *
        FROM company
        WHERE id = '$company'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$code = $row['code'];
$name = $row['name'];
$note = $row['note'];
$region = $row['region'];
$city = $row['city'];
$country = $row['country'];
$phone = $row['phone'];
$email = $row['email'];
