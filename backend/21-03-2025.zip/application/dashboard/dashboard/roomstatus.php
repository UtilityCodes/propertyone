<?php
// roomstatus.php

// Ensure config is included if not already included in index.php
// Uncomment if needed: include '../../../config.php';
date_default_timezone_set('Africa/Dar_es_Salaam'); // Your timezone

// Company ID from session
$companyId = $_SESSION['company_id'];

// Get current date and time
$currentDateTime = date('Y-m-d H:i:s');

// Total rooms
$query = "SELECT COUNT(*) as total_rooms FROM rooms WHERE company_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $companyId);
$stmt->execute();
$result = $stmt->get_result();
$totalRooms = $result->fetch_assoc()['total_rooms'] ?? 0;

// Vacant rooms: Not within any active booking period
$query = "
    SELECT COUNT(DISTINCT rooms.id) as vacant
    FROM rooms
    LEFT JOIN bookings ON rooms.id = bookings.rooms_id
    WHERE rooms.company_id = ?
    AND (bookings.id IS NULL
        OR NOT EXISTS (
            SELECT 1 FROM bookings b
            WHERE b.rooms_id = rooms.id
            AND ? BETWEEN 
                COALESCE(CONCAT(b.checkindate, ' ', b.checkintime), '1970-01-01 00:00:00')
                AND COALESCE(
                    LEAST(
                        CONCAT(b.todate, ' ', b.totime),
                        CONCAT(b.checkoutdate, ' ', b.checkouttime),
                        CONCAT(b.cancdate, ' ', b.canctime)
                    ),
                    '9999-12-31 23:59:59'
                )
        )
    )";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $companyId, $currentDateTime);
$stmt->execute();
$result = $stmt->get_result();
$vacantRooms = $result->fetch_assoc()['vacant'] ?? 0;

// Occupied rooms: Currently within an active booking period
$query = "
    SELECT COUNT(DISTINCT rooms.id) as occupied
    FROM rooms
    INNER JOIN bookings ON rooms.id = bookings.rooms_id
    WHERE rooms.company_id = ?
    AND ? BETWEEN 
        COALESCE(CONCAT(bookings.checkindate, ' ', bookings.checkintime), '1970-01-01 00:00:00')
        AND COALESCE(
            LEAST(
                CONCAT(bookings.todate, ' ', bookings.totime),
                CONCAT(bookings.checkoutdate, ' ', bookings.checkouttime),
                CONCAT(bookings.cancdate, ' ', bookings.canctime)
            ),
            '9999-12-31 23:59:59'
        )";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $companyId, $currentDateTime);
$stmt->execute();
$result = $stmt->get_result();
$occupiedRooms = $result->fetch_assoc()['occupied'] ?? 0;

// Not Ready rooms: Last action was a booking, not housekeeping
$query = "
    SELECT COUNT(DISTINCT rooms.id) as not_ready
    FROM rooms
    LEFT JOIN (
        SELECT rooms_id, 
               GREATEST(
                   COALESCE(CONCAT(todate, ' ', totime), '1970-01-01 00:00:00'),
                   COALESCE(CONCAT(checkoutdate, ' ', checkouttime), '1970-01-01 00:00:00'),
                   COALESCE(CONCAT(cancdate, ' ', canctime), '1970-01-01 00:00:00')
               ) as last_booking_time
        FROM bookings
    ) b ON rooms.id = b.rooms_id
    LEFT JOIN (
        SELECT rooms_id, COALESCE(CONCAT(todate, ' ', totime), '1970-01-01 00:00:00') as last_hk_time
        FROM house_keeping
        WHERE (todate, totime) = (
            SELECT todate, totime 
            FROM house_keeping hk2 
            WHERE hk2.rooms_id = house_keeping.rooms_id 
            ORDER BY todate DESC, totime DESC 
            LIMIT 1
        )
    ) hk ON rooms.id = hk.rooms_id
    WHERE rooms.company_id = ?
    AND b.last_booking_time IS NOT NULL
    AND (hk.last_hk_time IS NULL OR b.last_booking_time > hk.last_hk_time)";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $companyId);
$stmt->execute();
$result = $stmt->get_result();
$notReadyRooms = $result->fetch_assoc()['not_ready'] ?? 0;

// Ensure counts don’t exceed total rooms (sanity check)
$vacantRooms = min($vacantRooms, $totalRooms);
$occupiedRooms = min($occupiedRooms, $totalRooms - $vacantRooms);
$notReadyRooms = min($notReadyRooms, $totalRooms - $vacantRooms - $occupiedRooms);

// No need to close $conn here since index.php will handle it

