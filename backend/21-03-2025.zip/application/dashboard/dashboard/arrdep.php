<?php
// arrdep.php

date_default_timezone_set('Africa/Dar_es_Salaam'); // Your timezone

// Company ID from session
$companyId = $_SESSION['company_id'];

// Current date and time
$currentDate = date('Y-m-d');
$currentTime = date('H:i:s');

// Today's Arrivals
$query = "
    SELECT 
        bk.checkintime,
        cu.name AS guest
    FROM bookings bk
    INNER JOIN rooms rm ON bk.rooms_id = rm.id
    INNER JOIN rtype rt ON rm.rtype_id = rt.id
    INNER JOIN customer cu ON bk.customer_idno = cu.idno
    INNER JOIN user us ON bk.user_id = us.id
    WHERE bk.company_id = ?
      AND bk.checkindate = ?
      AND bk.checkintime <= ?
      AND bk.checkoutdate IS NULL
    ORDER BY bk.checkintime DESC
    LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $companyId, $currentDate, $currentTime);
$stmt->execute();
$result = $stmt->get_result();
$arrival = $result->fetch_assoc();
$arrivalTime = $arrival ? date('h:i A', strtotime($arrival['checkintime'])) : 'N/A';
$arrivalGuest = $arrival ? $arrival['guest'] : 'No arrivals yet';

// Today's Departures
$query = "
    SELECT 
        bk.totime,
        cu.name AS guest
    FROM bookings bk
    INNER JOIN rooms rm ON bk.rooms_id = rm.id
    INNER JOIN rtype rt ON rm.rtype_id = rt.id
    INNER JOIN customer cu ON bk.customer_idno = cu.idno
    INNER JOIN user us ON bk.user_id = us.id
    WHERE bk.company_id = ?
      AND bk.checkindate IS NOT NULL
      AND bk.todate = ?
      AND bk.totime <= ?
      AND bk.checkoutdate IS NULL
    ORDER BY bk.totime DESC
    LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $companyId, $currentDate, $currentTime);
$stmt->execute();
$result = $stmt->get_result();
$departure = $result->fetch_assoc();
$departureTime = $departure ? date('h:i A', strtotime($departure['totime'])) : 'N/A';
$departureGuest = $departure ? $departure['guest'] : 'No departures yet';

// No $conn->close() here; let index.php handle it
