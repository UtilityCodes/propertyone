<?php

include '../../../config.php';
session_start();

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

function generateCode(){
    $timestamp = time();

    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);

    $code = 'rt' . '-'  . $timestamp . '-' . $randomNumber;

    return $code;
}

if (isset($_POST["submit"])){  
    $dates = $_POST['date'];
    $timee = $_POST['time'];
    $name = $_POST['name'];
    $code = $_POST['code'];
    $note = $_POST['note'];
    $price = $_POST['price'];
    $company = $_SESSION['company_id'];

    date_default_timezone_set('Africa/Dar_es_Salaam');

    if($code == null){
        $code = generateCode();   
    }

    if($dates == null){
        $dates = date('Y-m-d');  
    }

    if($timee == null){
        $timee = date("H:i:s"); 
    }

    if($note == null){
        $note = 'No Note';   
    }

    $sql = "INSERT INTO rtype (code, name, price,  note, company_id, dates, timee) 
                         VALUES ('$code', '$name', '$price', '$note', '$company', '$dates', '$timee')";

    if ($conn->query($sql) === TRUE) {
        header("location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

}

$conn->close();