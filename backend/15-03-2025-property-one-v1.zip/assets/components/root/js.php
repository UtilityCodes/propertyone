<script src="../../../assets/js/script.js"></script>
<script src="../../../assets/js/time.js"></script>
<script src="../../../assets/js/inline-paging.js"></script>