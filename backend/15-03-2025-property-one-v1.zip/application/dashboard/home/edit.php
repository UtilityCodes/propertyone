<?php

include '../../../config.php';

if (isset($_POST['update'])){
    $viewId = $_POST['view_id'];
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];

    $region = $_POST['region'];
    $city = $_POST['city'];
    $country = $_POST['country'];

    $phone = $_POST['phone'];
    $email = $_POST['email'];

    $sql = "UPDATE `company` 
            SET `code` = '$code', 
                `name` = '$name', 
                `note` = '$note',
                `region` = '$region',
                `city` = '$city',
                `country` = '$country',
                `phone` = '$phone',
                `email` = '$email'
            WHERE `id` = '$viewId' ";
    $result = $conn->query($sql);

    if($result == TRUE){
        header('location: index.php');
    }else{
        echo 'Error:' . $sql . "<br>" . $conn->error;
    }
}

if(isset($_GET['id'])){
    $viewId = $_GET['id'];

    $sql = "SELECT * FROM `company` WHERE `id` = '$viewId' ";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $code = $row['code'];
            $name = $row['name'];
            $note = $row['note'];
            $region = $row['region'];
            $city = $row['city'];
            $country = $row['country'];
            $phone = $row['phone'];
            $email = $row['email'];
            $id = $row['id'];


        }

        ?>
        <form action="" class="report-form">
            <input type="hidden" name="view_id" value="<?php echo $id;?>">
            <div class="form-section">
                <div class="sec">
                    <div class="input-label">
                        <label for="">Code:</label><br>
                        <input type="text" name="code" value="<?php echo $code ?>">
                    </div>
                    <div class="input-label">
                        <label for="">Name:</label><br>
                        <input type="text" name="name" value="<?php echo $name ?>">
                    </div>
                </div>
                <div class="sec">
                    <div class="input-label">
                        <label for="">District:</label><br>
                        <input type="text" name="region" value="<?php echo $region ?>">
                    </div>
                    <div class="input-label">
                        <label for="">City:</label><br>
                        <input type="text" name="city" value="<?php echo $city ?>">
                    </div>
                    <div class="input-label">
                        <label for="">Country:</label><br>
                        <input type="text" name="country" value="<?php echo $country ?>">
                    </div>
                </div>
                <div class="sec">
                    <div class="input-label">
                        <label for="">Phone:</label><br>
                        <input type="text" name="phone" value="<?php echo $phone ?>">
                    </div>
                    <div class="input-label">
                        <label for="">Email:</label><br>
                        <input type="text" name="email" value="<?php echo $email ?>">
                    </div>
                </div>
                <div class="sec">
                    <div class="input-label">
                        <label for="">Description:</label><br>
                        <textarea name="note"><?php echo $note ?></textarea>
                    </div>
                </div>
            </div>
            <div class="form-submit">
                <button class="cancel">
                    <div class="icon">
                        <i class="fa fa-times" aria-hidden="true"></i>
                    </div>
                    <span>CANCEL</span>
                </button>
                <button class="confirm" name="update">
                    <div class="icon">
                        <i class="fa fa-check" aria-hidden="true"></i>
                    </div>
                    <span>UPDATE</span>
                </button>
            </div>

        </form>

        <?php 
    }else{
        header('location: view.php');
    }
}

?>    