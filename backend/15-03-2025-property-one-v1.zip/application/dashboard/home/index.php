<?php

include '../../../config.php';


session_start();

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

include 'home.php';


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Company Details';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Company';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    Details
                </a>
                <!-- <a href="#" data-page="1">
                    Settings
                </a> -->

            </div>
            <div class="inline-page-body">
                <!--Details-->
                <div class="page active">

                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Company Details:</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form">
                                <div class="form-section">
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Code:</label><br>
                                            <input type="text" value="<?php echo $code ?>" disabled>
                                        </div>
                                        <div class="input-label">
                                            <label for="">Name:</label><br>
                                            <input type="text" value="<?php echo $name ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">District:</label><br>
                                            <input type="text" value="<?php echo $region ?>" disabled>
                                        </div>
                                        <div class="input-label">
                                            <label for="">City:</label><br>
                                            <input type="text" value="<?php echo $city ?>" disabled>
                                        </div>
                                        <div class="input-label">
                                            <label for="">Country:</label><br>
                                            <input type="text" value="<?php echo $country ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Phone:</label><br>
                                            <input type="text" value="<?php echo $phone ?>" disabled>
                                        </div>
                                        <div class="input-label">
                                            <label for="">Email:</label><br>
                                            <input type="text" value="<?php echo $email ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Description:</label><br>
                                            <textarea disabled><?php echo $note ?></textarea>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>

                </div>

                <!--Settings-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Settings:</h2>
                            </div>
                            <hr>   
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>


    <?php
        include '../../../assets/components/root/js.php';
    ?>
</body>
</html>