<?php

include '../../../config.php';

session_start();

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Dashboard';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Dashboard';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    Today
                </a>
                <a href="#" data-page="1">
                    Yesterday
                </a>
                <a href="#" data-page="2">
                    Past Week
                </a>
                <a href="#" data-page="3">
                    Past Month
                </a>

            </div>
            <div class="inline-page-body">
                <!--Today-->
                <div class="page active">

                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">
                                            Arrivals
                                        </div>
                                        <div class="item-figure">12</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Departure
                                        </div>
                                        <div class="item-figure">10</div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">
                                            Direct Payment
                                        </div>
                                        <div class="item-figure">120,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Credit Payment
                                        </div>
                                        <div class="item-figure">90,000</div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">
                                            Total Revenue
                                        </div>
                                        <div class="item-figure">340,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure">120,000</div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">
                                            Reservation Payments
                                        </div>
                                        <div class="item-figure">550,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Deposits
                                        </div>
                                        <div class="item-figure">800,000</div>
                                    </div>
                                </div>

                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure">100,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure">500,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure">220,000</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="dashbody sec-1">
                            <div class="left">
                                <div class="graph booking">
                                    <div class="heading">
                                        <div class="title">
                                            Booking
                                        </div>
                                        <div class="more">
                                            <a href="">More</a>
                                        </div>
                                    </div>
                                    <div class="thegraph"></div>
                                </div>
                                <div class="guest-btns">
                                    <div class="flex">
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                    </div>
                                    <div class="flex-more">
                                        <a href="">See More Guests</a>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="graph occupancy">
                                    <div class="thegraph"></div>
                                    <div class="descr">
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour vacant"></div>
                                                <div class="name">Vacant</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>40</span>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour occupied"></div>
                                                <div class="name">Occupied</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>35</span>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour not-ready"></div>
                                                <div class="name">Not Ready</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>17</span>
                                            </div>
                                        </div>
    
                                    </div>
                                    <div class="more-descr">
                                        <article>There are <span>92</span> Rooms Currently</article>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="dashbody sec-2">
                            <div class="left">
                                <div class="up">
                                    <div class="arr">
                                        <div class="heading">
                                            <div class="title">Today's Arrival</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <div class="time">08:30 AM</div>
                                            <div class="customer">Kevin Thobias</div>
                                        </div>
                                    </div>
                                    <div class="dep">
                                        <div class="heading">
                                            <div class="title">Today's Departure</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <div class="time">08:30 AM</div>
                                            <div class="customer">Jarleen Michaels</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="down">
                                    <div class="graph payment">
                                        <div class="heading">
                                            <div class="title">Payments</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="thegraph"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="calendar room">
                                    <div class="heading">
                                        <div class="title">Room Calendar</div>
                                        <div class="more">
                                            <a href="">Go To Calendar</a>
                                        </div>
                                    </div>
                                    <div class="rt">
                                        <div class="flex">
                                            <button>Executive</button>
                                            <button>Guest</button>
                                            <button>Double Bedroom</button>
                                            <button>Presidential</button>
                                        </div>
                                    </div>
                                    <div class="rms">
                                        <div class="flex">
                                            <button>E23</button>
                                            <button>P09</button>
                                            <button>DB56</button>
                                            <button>G65</button>
                                        </div>
                                        
                                    </div>
                                    <div class="sched">
                                        <div class="flex customer-box">
                                            <div class="day">
                                                <div class="flex">
                                                    <div class="date">05</div>
                                                    <div class="day">Wed</div>
                                                </div>
                                            </div>
                                            <div class="customer">
                                                <div class="flex">
                                                    <div class="customer">Kevin Thobias</div>
                                                    <div class="icon"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex available-box">
                                            <div class="day">
                                                <div class="flex">
                                                    <div class="date">06</div>
                                                    <div class="day">Thu</div>
                                                </div>
                                            </div>
                                            <div class="customer">
                                                <div class="flex">
                                                    <div class="available">Available for Booking</div>
                                                    <div class="icon"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>

                <!--Yesterday-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">
                                            Arrivals
                                        </div>
                                        <div class="item-figure">12</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Departure
                                        </div>
                                        <div class="item-figure">10</div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">
                                            Direct Payment
                                        </div>
                                        <div class="item-figure">120,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Credit Payment
                                        </div>
                                        <div class="item-figure">90,000</div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">
                                            Total Revenue
                                        </div>
                                        <div class="item-figure">340,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure">120,000</div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">
                                            Reservation Payments
                                        </div>
                                        <div class="item-figure">550,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Deposits
                                        </div>
                                        <div class="item-figure">800,000</div>
                                    </div>
                                </div>

                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure">100,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure">500,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure">220,000</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="dashbody sec-1">
                            <div class="left">
                                <div class="graph booking">
                                    <div class="heading">
                                        <div class="title">
                                            Booking
                                        </div>
                                        <div class="more">
                                            <a href="">More</a>
                                        </div>
                                    </div>
                                    <div class="thegraph"></div>
                                </div>
                                <div class="guest-btns">
                                    <div class="flex">
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                    </div>
                                    <div class="flex-more">
                                        <a href="">See More Guests</a>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="graph occupancy">
                                    <div class="thegraph"></div>
                                    <div class="descr">
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour vacant"></div>
                                                <div class="name">Vacant</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>40</span>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour occupied"></div>
                                                <div class="name">Occupied</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>35</span>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour not-ready"></div>
                                                <div class="name">Not Ready</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>17</span>
                                            </div>
                                        </div>
    
                                    </div>
                                    <div class="more-descr">
                                        <article>There are <span>92</span> Rooms Currently</article>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="dashbody sec-2">
                            <div class="left">
                                <div class="up">
                                    <div class="arr">
                                        <div class="heading">
                                            <div class="title">Today's Arrival</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <div class="time">08:30 AM</div>
                                            <div class="customer">Kevin Thobias</div>
                                        </div>
                                    </div>
                                    <div class="dep">
                                        <div class="heading">
                                            <div class="title">Today's Departure</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <div class="time">08:30 AM</div>
                                            <div class="customer">Jarleen Michaels</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="down">
                                    <div class="graph payment">
                                        <div class="heading">
                                            <div class="title">Payments</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="thegraph"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="calendar room">
                                    <div class="heading">
                                        <div class="title">Room Calendar</div>
                                        <div class="more">
                                            <a href="">Go To Calendar</a>
                                        </div>
                                    </div>
                                    <div class="rt">
                                        <div class="flex">
                                            <button>Executive</button>
                                            <button>Guest</button>
                                            <button>Double Bedroom</button>
                                            <button>Presidential</button>
                                        </div>
                                    </div>
                                    <div class="rms">
                                        <div class="flex">
                                            <button>E23</button>
                                            <button>P09</button>
                                            <button>DB56</button>
                                            <button>G65</button>
                                        </div>
                                        
                                    </div>
                                    <div class="sched">
                                        <div class="flex customer-box">
                                            <div class="day">
                                                <div class="flex">
                                                    <div class="date">05</div>
                                                    <div class="day">Wed</div>
                                                </div>
                                            </div>
                                            <div class="customer">
                                                <div class="flex">
                                                    <div class="customer">Kevin Thobias</div>
                                                    <div class="icon"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex available-box">
                                            <div class="day">
                                                <div class="flex">
                                                    <div class="date">06</div>
                                                    <div class="day">Thu</div>
                                                </div>
                                            </div>
                                            <div class="customer">
                                                <div class="flex">
                                                    <div class="available">Available for Booking</div>
                                                    <div class="icon"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <!--Past Week-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">
                                            Arrivals
                                        </div>
                                        <div class="item-figure">12</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Departure
                                        </div>
                                        <div class="item-figure">10</div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">
                                            Direct Payment
                                        </div>
                                        <div class="item-figure">120,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Credit Payment
                                        </div>
                                        <div class="item-figure">90,000</div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">
                                            Total Revenue
                                        </div>
                                        <div class="item-figure">340,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure">120,000</div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">
                                            Reservation Payments
                                        </div>
                                        <div class="item-figure">550,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Deposits
                                        </div>
                                        <div class="item-figure">800,000</div>
                                    </div>
                                </div>

                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure">100,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure">500,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure">220,000</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="dashbody sec-1">
                            <div class="left">
                                <div class="graph booking">
                                    <div class="heading">
                                        <div class="title">
                                            Booking
                                        </div>
                                        <div class="more">
                                            <a href="">More</a>
                                        </div>
                                    </div>
                                    <div class="thegraph"></div>
                                </div>
                                <div class="guest-btns">
                                    <div class="flex">
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                    </div>
                                    <div class="flex-more">
                                        <a href="">See More Guests</a>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="graph occupancy">
                                    <div class="thegraph"></div>
                                    <div class="descr">
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour vacant"></div>
                                                <div class="name">Vacant</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>40</span>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour occupied"></div>
                                                <div class="name">Occupied</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>35</span>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour not-ready"></div>
                                                <div class="name">Not Ready</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>17</span>
                                            </div>
                                        </div>
    
                                    </div>
                                    <div class="more-descr">
                                        <article>There are <span>92</span> Rooms Currently</article>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="dashbody sec-2">
                            <div class="left">
                                <div class="up">
                                    <div class="arr">
                                        <div class="heading">
                                            <div class="title">Today's Arrival</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <div class="time">08:30 AM</div>
                                            <div class="customer">Kevin Thobias</div>
                                        </div>
                                    </div>
                                    <div class="dep">
                                        <div class="heading">
                                            <div class="title">Today's Departure</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <div class="time">08:30 AM</div>
                                            <div class="customer">Jarleen Michaels</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="down">
                                    <div class="graph payment">
                                        <div class="heading">
                                            <div class="title">Payments</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="thegraph"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="calendar room">
                                    <div class="heading">
                                        <div class="title">Room Calendar</div>
                                        <div class="more">
                                            <a href="">Go To Calendar</a>
                                        </div>
                                    </div>
                                    <div class="rt">
                                        <div class="flex">
                                            <button>Executive</button>
                                            <button>Guest</button>
                                            <button>Double Bedroom</button>
                                            <button>Presidential</button>
                                        </div>
                                    </div>
                                    <div class="rms">
                                        <div class="flex">
                                            <button>E23</button>
                                            <button>P09</button>
                                            <button>DB56</button>
                                            <button>G65</button>
                                        </div>
                                        
                                    </div>
                                    <div class="sched">
                                        <div class="flex customer-box">
                                            <div class="day">
                                                <div class="flex">
                                                    <div class="date">05</div>
                                                    <div class="day">Wed</div>
                                                </div>
                                            </div>
                                            <div class="customer">
                                                <div class="flex">
                                                    <div class="customer">Kevin Thobias</div>
                                                    <div class="icon"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex available-box">
                                            <div class="day">
                                                <div class="flex">
                                                    <div class="date">06</div>
                                                    <div class="day">Thu</div>
                                                </div>
                                            </div>
                                            <div class="customer">
                                                <div class="flex">
                                                    <div class="available">Available for Booking</div>
                                                    <div class="icon"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <!--Past Month-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">
                                            Arrivals
                                        </div>
                                        <div class="item-figure">50</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Departure
                                        </div>
                                        <div class="item-figure">45</div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">
                                            Direct Payment
                                        </div>
                                        <div class="item-figure">16,700,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Credit Payment
                                        </div>
                                        <div class="item-figure">7,490,000</div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">
                                            Total Revenue
                                        </div>
                                        <div class="item-figure">25,670,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure">3,800,000</div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">
                                            Reservation Payments
                                        </div>
                                        <div class="item-figure">17,770,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">
                                            Deposits
                                        </div>
                                        <div class="item-figure">1,200,000</div>
                                    </div>
                                </div>

                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure">500,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure">800,000</div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure">3,820,000</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="dashbody sec-1">
                            <div class="left">
                                <div class="graph booking">
                                    <div class="heading">
                                        <div class="title">
                                            Booking
                                        </div>
                                        <div class="more">
                                            <a href="">More</a>
                                        </div>
                                    </div>
                                    <div class="thegraph"></div>
                                </div>
                                <div class="guest-btns">
                                    <div class="flex">
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                        <button>Kevin Thobias</button>
                                    </div>
                                    <div class="flex-more">
                                        <a href="">See More Guests</a>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="graph occupancy">
                                    <div class="thegraph"></div>
                                    <div class="descr">
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour vacant"></div>
                                                <div class="name">Vacant</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>40</span>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour occupied"></div>
                                                <div class="name">Occupied</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>35</span>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="item-details">
                                                <div class="colour not-ready"></div>
                                                <div class="name">Not Ready</div>
                                            </div>
                                            <div class="item-capacity">
                                                <span>17</span>
                                            </div>
                                        </div>
    
                                    </div>
                                    <div class="more-descr">
                                        <article>There are <span>92</span> Rooms Currently</article>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="dashbody sec-2">
                            <div class="left">
                                <div class="up">
                                    <div class="arr">
                                        <div class="heading">
                                            <div class="title">Today's Arrival</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <div class="time">08:30 AM</div>
                                            <div class="customer">Kevin Thobias</div>
                                        </div>
                                    </div>
                                    <div class="dep">
                                        <div class="heading">
                                            <div class="title">Today's Departure</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <div class="time">08:30 AM</div>
                                            <div class="customer">Jarleen Michaels</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="down">
                                    <div class="graph payment">
                                        <div class="heading">
                                            <div class="title">Payments</div>
                                            <div class="more">
                                                <a href="">See More</a>
                                            </div>
                                        </div>
                                        <div class="thegraph"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="calendar room">
                                    <div class="heading">
                                        <div class="title">Room Calendar</div>
                                        <div class="more">
                                            <a href="">Go To Calendar</a>
                                        </div>
                                    </div>
                                    <div class="rt">
                                        <div class="flex">
                                            <button>Executive</button>
                                            <button>Guest</button>
                                            <button>Double Bedroom</button>
                                            <button>Presidential</button>
                                        </div>
                                    </div>
                                    <div class="rms">
                                        <div class="flex">
                                            <button>E23</button>
                                            <button>P09</button>
                                            <button>DB56</button>
                                            <button>G65</button>
                                        </div>
                                        
                                    </div>
                                    <div class="sched">
                                        <div class="flex customer-box">
                                            <div class="day">
                                                <div class="flex">
                                                    <div class="date">05</div>
                                                    <div class="day">Wed</div>
                                                </div>
                                            </div>
                                            <div class="customer">
                                                <div class="flex">
                                                    <div class="customer">Kevin Thobias</div>
                                                    <div class="icon"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex available-box">
                                            <div class="day">
                                                <div class="flex">
                                                    <div class="date">06</div>
                                                    <div class="day">Thu</div>
                                                </div>
                                            </div>
                                            <div class="customer">
                                                <div class="flex">
                                                    <div class="available">Available for Booking</div>
                                                    <div class="icon"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>


    <?php
        include '../../../assets/components/root/js.php';
    ?>
</body>
</html>