<?php

include '../../../config.php';

session_start();

date_default_timezone_set('Africa/Dar_es_Salaam');

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Guest List';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Reservations';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    All Guests
                </a>
                <a href="#" data-page="1">
                    Today Arrivals
                </a>
                <a href="#" data-page="2">
                    Today Departures
                </a>

            </div>
            <div class="inline-page-body">
                <!--All Guests-->
                <div class="page active">

                    <div class="options-tab">
                        <div class="ot-flex">
                            <div class="more-options">
                                <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                    <title>More Options</title>
                                    <path d="M416,170.667H96A53.333,53.333,0,0,1,96,64H416a53.333,53.333,0,0,1,0,106.667Zm-320-64A10.667,10.667,0,1,0,96,128H416a10.667,10.667,0,1,0,0-21.333Z"></path>
                                    <path d="M416,309.333H96a53.333,53.333,0,1,1,0-106.667H416a53.333,53.333,0,0,1,0,106.667Zm-320-64a10.667,10.667,0,0,0,0,21.333H416a10.667,10.667,0,0,0,0-21.333Z"></path>
                                    <path d="M416,448H96a53.333,53.333,0,0,1,0-106.667H416A53.333,53.333,0,0,1,416,448ZM96,384a10.667,10.667,0,1,0,0,21.333H416A10.667,10.667,0,1,0,416,384Z"></path>
                                </svg>
                            </div>
                        </div>

                        <div class="extra-tab">
                            <div class="extra-options">
                                <div class="eo-flex">
                                    <a href="">
                                        <button>
                                            <div class="icon">
                                                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;" xml:space="preserve">
                                                    <title>Reports</title>
                                                    <g id="Layer_1">
                                                        <path d="M26,3V1h-2v2H3H1v2h2v26H1v2h2h17.471L14,47.791V49h2v-0.791L22.654,33H24v16h2V33h1.346L34,48.209V49h2v-1.209L29.529,33
                                                            H47h2v-2h-2V5h2V3h-2H26z M45,31H5V5h40V31z"></path>
                                                        <path d="M16,28c4.411,0,8-3.589,8-8v-1h-7v-7h-1c-4.411,0-8,3.589-8,8S11.589,28,16,28z M15,14.083V21h6.917
                                                            c-0.478,2.834-2.949,5-5.917,5c-3.309,0-6-2.691-6-6C10,17.032,12.166,14.561,15,14.083z"></path>
                                                        <path d="M28,16c0-4.411-3.589-8-8-8h-1v9h9V16z M21,15v-4.917c2.509,0.422,4.494,2.408,4.917,4.917H21z"></path>
                                                        <rect x="31" y="10" width="10" height="2"></rect>
                                                        <rect x="31" y="15" width="10" height="2"></rect>
                                                        <rect x="31" y="20" width="10" height="2"></rect>
                                                    </g>
                                                    <g>
                                                    </g>
                                                </svg>
                                            </div>
                                            <span>Go To Reports</span>
                                        </button>
                                    </a>
                                    <a href="">
                                        <button>
                                            <div class="icon">
                                                <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100.353 100.353" style="enable-background:new 0 0 100.353 100.353;" xml:space="preserve">
                                                    <title>Calendar</title>
                                                    <g>
                                                        <path style="fill:#231F20;" d="M33.46,43.065h-9.051c-0.829,0-1.5,0.671-1.5,1.5v9.045c0,0.829,0.671,1.5,1.5,1.5h9.051
                                                            c0.829,0,1.5-0.671,1.5-1.5v-9.045C34.96,43.737,34.288,43.065,33.46,43.065z M31.96,52.111h-6.051v-6.045h6.051V52.111z"></path>
                                                        <path style="fill:#231F20;" d="M54.571,43.065h-9.054c-0.829,0-1.5,0.671-1.5,1.5v9.045c0,0.829,0.671,1.5,1.5,1.5h9.054
                                                            c0.829,0,1.5-0.671,1.5-1.5v-9.045C56.071,43.737,55.4,43.065,54.571,43.065z M53.071,52.111h-6.054v-6.045h6.054V52.111z"></path>
                                                        <path style="fill:#231F20;" d="M33.46,63.677h-9.051c-0.829,0-1.5,0.672-1.5,1.5v9.051c0,0.829,0.671,1.5,1.5,1.5h9.051
                                                            c0.829,0,1.5-0.671,1.5-1.5v-9.051C34.96,64.349,34.288,63.677,33.46,63.677z M31.96,72.728h-6.051v-6.051h6.051V72.728z"></path>
                                                        <path style="fill:#231F20;" d="M54.571,63.677h-9.054c-0.829,0-1.5,0.672-1.5,1.5v9.051c0,0.829,0.671,1.5,1.5,1.5h9.054
                                                            c0.829,0,1.5-0.671,1.5-1.5v-9.051C56.071,64.349,55.4,63.677,54.571,63.677z M53.071,72.728h-6.054v-6.051h6.054V72.728z"></path>
                                                        <path style="fill:#231F20;" d="M75.024,63.677h-9.047c-0.829,0-1.5,0.672-1.5,1.5v9.051c0,0.829,0.671,1.5,1.5,1.5h9.047
                                                            c0.829,0,1.5-0.671,1.5-1.5v-9.051C76.524,64.349,75.852,63.677,75.024,63.677z M73.524,72.728h-6.047v-6.051h6.047V72.728z"></path>
                                                        <path style="fill:#231F20;" d="M86.04,16.132h-9.111v-1.739c0-3.09-2.513-5.604-5.601-5.604c-3.09,0-5.604,2.514-5.604,5.604v1.739
                                                            H55.592v-1.739c0-3.09-2.513-5.604-5.601-5.604c-3.092,0-5.607,2.514-5.607,5.604v1.739H34.255v-1.739
                                                            c0-3.09-2.512-5.604-5.601-5.604c-3.092,0-5.607,2.514-5.607,5.604v1.739h-9.085c-0.829,0-1.5,0.671-1.5,1.5v72.08
                                                            c0,0.828,0.671,1.5,1.5,1.5h72.08c0.829,0,1.5-0.672,1.5-1.5v-72.08C87.54,16.803,86.869,16.132,86.04,16.132z M68.723,14.393
                                                            c0-1.437,1.168-2.604,2.604-2.604c1.434,0,2.601,1.168,2.601,2.604v7.676c0,1.436-1.167,2.604-2.601,2.604
                                                            c-1.436,0-2.604-1.168-2.604-2.604V14.393z M49.99,11.788c1.434,0,2.601,1.168,2.601,2.604v7.676c0,1.436-1.167,2.604-2.601,2.604
                                                            c-1.438,0-2.607-1.168-2.607-2.604v-4.272c0.006-0.055,0.017-0.108,0.017-0.165s-0.011-0.11-0.017-0.165v-3.074
                                                            C47.383,12.956,48.553,11.788,49.99,11.788z M26.046,14.393c0-1.437,1.17-2.604,2.607-2.604c1.434,0,2.601,1.168,2.601,2.604v7.676
                                                            c0,1.436-1.167,2.604-2.601,2.604c-1.438,0-2.607-1.168-2.607-2.604V14.393z M84.54,88.211H15.46v-69.08h7.585v2.937
                                                            c0,3.09,2.516,5.604,5.607,5.604c3.088,0,5.601-2.514,5.601-5.604v-2.937h10.129v2.937c0,3.09,2.516,5.604,5.607,5.604
                                                            c3.088,0,5.601-2.514,5.601-5.604v-2.937h10.132v2.937c0,3.09,2.514,5.604,5.604,5.604c3.088,0,5.601-2.514,5.601-5.604v-2.937
                                                            h7.611v69.08H84.54z"></path>
                                                        <path style="fill:#231F20;" d="M76.683,38.729l-7.654,9.434l-3.193-3.048c-0.599-0.572-1.548-0.55-2.121,0.049
                                                            c-0.572,0.6-0.55,1.549,0.049,2.121l4.369,4.171c0.28,0.267,0.651,0.415,1.036,0.415c0.032,0,0.063-0.001,0.095-0.003
                                                            c0.418-0.026,0.806-0.227,1.07-0.552l8.679-10.696c0.522-0.643,0.423-1.588-0.22-2.11C78.15,37.987,77.205,38.086,76.683,38.729z"></path>
                                                    </g>
                                                </svg>
                                            </div>
                                            <span>Go To Calendar</span>
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                    Guest List
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">
                            <?php
                                include '../../../config.php';

                                
                                $sqlView ="SELECT 
                                                bk.*,
                                                rt.name as rtype,
                                                rm.name as room,
                                                cu.name as guest,
                                                cu.phone as phone,
                                                cu.email as email,
                                                cu.code as guestcode,
                                                us.name as user
                                            FROM bookings bk
                                            INNER JOIN rooms rm ON bk.rooms_id = rm.id
                                            INNER JOIN rtype rt ON rm.rtype_id = rt.id
                                            INNER JOIN customer cu ON bk.customer_idno = cu.idno
                                            INNER JOIN user us ON bk.user_id = us.id
                                            WHERE bk.company_id = '$company'
                                              AND bk.checkindate IS NOT NULL
                                              AND bk.checkoutdate IS NULL
                                            ORDER BY bk.checkindate DESC, bk.checkintime DESC";
                                $result = $conn->query($sqlView );
                               
                                if ($result->num_rows > 0){
                                    while ($row = $result->fetch_assoc()){
                                        ?>
                                        <div class="pcb-boxes">
                                            <div class="flex">
                                                <div class="act-details pcb-box">
                                                    <div class="ref-date">
                                                        <?php echo $row['guestcode']?>
                                                    </div>
                                                    <div class="item-name">
                                                        <?php echo $row['guest'];?>
                                                    </div>
                                                    <div class="item-code">
                                                        <?php echo $row['phone'];?>
                                                    </div>
                                                </div>
                                                <div class="room-rt pcb-box">
                                                    <div class="rt">
                                                        <?php echo $row['rtype']?>
                                                    </div>
                                                    <span><?php echo $row['room']?></span>
                                                </div>
            
                                                <div class="duration pcb-box">
                                                    <div class="from">
                                                        <span>Arrived at:</span>
                                                        <span><?php echo date('d M Y', strtotime($row['checkindate'])); ?> at <?php echo date('g:i A', strtotime($row['checkintime'])); ?></span>
                                                    </div>
                                                    <div class="to">
                                                        <span>Expected to depart at:</span>
                                                        <span><?php echo date('d M Y', strtotime($row['todate'])); ?> at <?php echo date('g:i A', strtotime($row['totime'])); ?></span>
                                                    </div>
                                                </div>

                                                <div class="payments-balance pcb-box">
                                                    <span>
                                                        <a href="">Add Payment</a>
                                                    </span>
                                                    <span>
                                                        <a href="">View Payments</a>
                                                    </span>
                                                    <span>
                                                        <a href="">Balance</a>
                                                    </span>
                                                </div>
            
                
                                                <div class="desc pcb-box">
                                                    <?php echo $row['note']?>
                                                </div>
                
                
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }
                            ?>

                        </div>
                    </div>

                </div>

                <!-- Today Arrivals -->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                    Today Arrivals
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">
                            <?php
                            include '../../../config.php';
                            date_default_timezone_set('Africa/Dar_es_Salaam'); // Ensure timezone consistency
            
                            $currentDate = date('Y-m-d');
                            $currentTime = date('H:i:s'); // Current time (e.g., 04:00:00)
            
                            $sqlView = "SELECT 
                                            bk.*,
                                            rt.name AS rtype,
                                            rm.name AS room,
                                            cu.name AS guest,
                                            cu.phone AS phone,
                                            cu.email AS email,
                                            cu.code AS guestcode,
                                            us.name AS user
                                        FROM bookings bk
                                        INNER JOIN rooms rm ON bk.rooms_id = rm.id
                                        INNER JOIN rtype rt ON rm.rtype_id = rt.id
                                        INNER JOIN customer cu ON bk.customer_idno = cu.idno
                                        INNER JOIN user us ON bk.user_id = us.id
                                        WHERE bk.company_id = '$company'
                                          AND bk.checkindate = '$currentDate'
                                          AND bk.checkintime <= '$currentTime'
                                          AND bk.checkoutdate IS NULL
                                        ORDER BY bk.checkintime DESC";
                            $result = $conn->query($sqlView);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    ?>
                                    <div class="pcb-boxes">
                                        <div class="flex">
                                            <div class="act-details pcb-box">
                                                <div class="ref-date">
                                                    <?php echo $row['guestcode']; ?>
                                                </div>
                                                <div class="item-name">
                                                    <?php echo $row['guest']; ?>
                                                </div>
                                                <div class="item-code">
                                                    <?php echo $row['phone']; ?>
                                                </div>
                                            </div>
                                            <div class="room-rt pcb-box">
                                                <div class="rt">
                                                    <?php echo $row['rtype']; ?>
                                                </div>
                                                <span><?php echo $row['room']; ?></span>
                                            </div>
                                            <div class="duration pcb-box">
                                                <div class="from">
                                                    <span>Arrived at:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['checkindate'])); ?> at <?php echo date('g:i A', strtotime($row['checkintime'])); ?></span>
                                                </div>
                                                <div class="to">
                                                    <span>Expected to depart at:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['todate'])); ?> at <?php echo date('g:i A', strtotime($row['totime'])); ?></span>
                                                </div>
                                            </div>
                                            <div class="dropdowns">
                                                <span><a href="">Check-Out</a></span>
                                                <span><a href="">Add Payment</a></span>
                                                <span><a href="">View Payments</a></span>
                                                <span><a href="">Balance</a></span>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                            } else {
                                echo "<p>No arrivals today before this time.</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <!-- Today Departures -->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                    Today Expected Departures
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">
                            <?php
                            include '../../../config.php';
                            date_default_timezone_set('Africa/Dar_es_Salaam'); // Ensure timezone consistency
            
                            $currentDate = date('Y-m-d');
                            $currentTime = date('H:i:s'); // Current time (e.g., 04:00:00)
            
                            $sqlView = "SELECT 
                                            bk.*,
                                            rt.name AS rtype,
                                            rm.name AS room,
                                            cu.name AS guest,
                                            cu.phone AS phone,
                                            cu.email AS email,
                                            cu.code AS guestcode,
                                            us.name AS user
                                        FROM bookings bk
                                        INNER JOIN rooms rm ON bk.rooms_id = rm.id
                                        INNER JOIN rtype rt ON rm.rtype_id = rt.id
                                        INNER JOIN customer cu ON bk.customer_idno = cu.idno
                                        INNER JOIN user us ON bk.user_id = us.id
                                        WHERE bk.company_id = '$company'
                                          AND bk.checkindate IS NOT NULL
                                          AND bk.todate = '$currentDate'
                                          AND bk.totime <= '$currentTime'
                                          AND bk.checkoutdate IS NULL
                                        ORDER BY bk.totime DESC";
                            $result = $conn->query($sqlView);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    ?>
                                    <div class="pcb-boxes">
                                        <div class="flex">
                                            <div class="act-details pcb-box">
                                                <div class="ref-date">
                                                    <?php echo $row['guestcode']; ?>
                                                </div>
                                                <div class="item-name">
                                                    <?php echo $row['guest']; ?>
                                                </div>
                                                <div class="item-code">
                                                    <?php echo $row['phone']; ?>
                                                </div>
                                            </div>
                                            <div class="room-rt pcb-box">
                                                <div class="rt">
                                                    <?php echo $row['rtype']; ?>
                                                </div>
                                                <span><?php echo $row['room']; ?></span>
                                            </div>
                                            <div class="duration pcb-box">
                                                <div class="from">
                                                    <span>Arrived at:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['checkindate'])); ?> at <?php echo date('g:i A', strtotime($row['checkintime'])); ?></span>
                                                </div>
                                                <div class="to">
                                                    <span>Expected to depart at:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['todate'])); ?> at <?php echo date('g:i A', strtotime($row['totime'])); ?></span>
                                                </div>
                                            </div>
                                            <div class="dropdowns">
                                                <span><a href="">Check-Out</a></span>
                                                <span><a href="">Add Payment</a></span>
                                                <span><a href="">View Payments</a></span>
                                                <span><a href="">Balance</a></span>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                            } else {
                                echo "<p>No departures expected today before this time.</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>


    <?php
        include '../../../assets/components/root/js.php';
    ?>

</body>
</html>