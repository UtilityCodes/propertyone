<?php

include 'config.php';

session_start();

if (isset($_POST["submit"])){
    $company = $_POST['company'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT
               us.*,
               rl.id as roles_id,
               rl.name as roles,
               c.id as company_id,
               c.name as company,
               c.region as region,
               c.city as city,
               c.country as country
            FROM user us
            INNER JOIN roles rl ON us.roles_id = rl.id
            INNER JOIN company c ON us.company_id = c.id
            WHERE us.name = '$username' AND us.passcode = '$password' AND c.name = '$company' ";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Set session variables
        // User details
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];

        // company details
        $_SESSION['company_id'] = $user['company_id'];
        $_SESSION['company'] = $user['company'];
        $_SESSION['region'] = $user['region'];
        $_SESSION['city'] = $user['city'];
        $_SESSION['country'] = $user['country'];

        // role details
        $_SESSION['roles'] = $user['roles'];

        switch ($_SESSION['roles']) {
            case 'Admin':
                header("Location: application/dashboard/dashboard/index.php"); 
                break;
            case 'Manager':
                header("Location: application/reservations/list/index.php"); 
                break;
            case 'Staff':
                header("Location: application/reservations/guest/index.php"); 
                break;
            default:
                break;
        }
    }  else {
        // Handle unsuccessful login
        echo "Invalid username or password";
    }

}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="assets/css/login.css">
</head>
<body>

    <div class="login-container">
        <h2>Login</h2>
        <span class="message">Invalid User Details. Try Again...</span>
        <form action="" method="post">

            <div class="input-group">
                <label for="username">Company:</label>
                <input type="text" id="company" name="company" required>
            </div>
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>

            <div class="input-group">
                <label for="password">Password</label>
                <div class="password-wrapper">
                    <input type="password" id="password" name="password" required>
                    <button type="button" id="togglePassword">?</button>
                </div>

                
            </div>

            <button type="submit" class="login-btn" name="submit">Login</button>
        </form>
    </div>


    <script src="assets/js/login.js"></script>
</body>
</html>