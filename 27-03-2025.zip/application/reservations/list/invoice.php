<?php
// invoice.php
include '../../../config.php';
require_once '../../../fpdf/fpdf.php'; // Adjust path to where you placed fpdf.php

session_start();
date_default_timezone_set('Africa/Dar_es_Salaam');

// Check if booking code is provided
if (!isset($_GET['code']) || empty($_GET['code'])) {
    die("No booking code provided.");
}

$bookingCode = $_GET['code'];
$companyId = $_SESSION['company_id'];

// Fetch booking details
$bookingQuery = "SELECT 
                    bk.code, 
                    bk.dates, 
                    bk.timee, 
                    bk.fromdate, 
                    bk.fromtime, 
                    bk.todate, 
                    bk.totime, 
                    bk.ogprice, 
                    bk.mprice, 
                    bk.nights, 
                    bk.adults, 
                    bk.children, 
                    bk.babies, 
                    bk.note, 
                    bk.customer_idno, 
                    bk.discount, 
                    bk.amount, 
                    bk.paid, 
                    bk.vat, 
                    bk.vatpercent, 
                    rm.name AS room_name, 
                    rt.name AS rtype_name
                FROM bookings bk
                INNER JOIN rooms rm ON bk.rooms_id = rm.id
                INNER JOIN rtype rt ON rm.rtype_id = rt.id
                WHERE bk.code = ? AND bk.company_id = ?";
$stmt = $conn->prepare($bookingQuery);
$stmt->bind_param("ss", $bookingCode, $companyId);
$stmt->execute();
$bookingResult = $stmt->get_result();

if ($bookingResult->num_rows === 0) {
    die("Booking not found.");
}

$booking = $bookingResult->fetch_assoc();
$customerIdno = $booking['customer_idno'];

// Fetch customer details
$customerQuery = "SELECT name, email, phone, city, country 
                  FROM customer 
                  WHERE idno = ?";
$stmt = $conn->prepare($customerQuery);
$stmt->bind_param("s", $customerIdno);
$stmt->execute();
$customerResult = $stmt->get_result();
$customer = $customerResult->fetch_assoc();

// Fetch company details
$companyQuery = "SELECT name, phone, email, region, city, country 
                 FROM company 
                 WHERE id = ?";
$stmt = $conn->prepare($companyQuery);
$stmt->bind_param("s", $companyId);
$stmt->execute();
$companyResult = $stmt->get_result();
$company = $companyResult->fetch_assoc();

// Close database connection
$conn->close();

// Initialize FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetMargins(10, 15, 10);

// --- Header ---
$pdf->SetFont('Arial', 'B', 16);
$pdf->SetFillColor(230, 230, 250); // Light lavender background
$pdf->Cell(0, 10, 'INVOICE', 1, 1, 'C', true);
$pdf->Ln(5);

$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(0, 51, 102); // Dark blue
$pdf->Cell(0, 8, $company['name'], 0, 1, 'L');
$pdf->SetFont('Arial', '', 10);
$pdf->SetTextColor(0, 0, 0); // Black
$pdf->Cell(0, 6, 'Phone: ' . $company['phone'], 0, 1);
$pdf->Cell(0, 6, 'Email: ' . $company['email'], 0, 1);
$pdf->Cell(0, 6, $company['city'] . ', ' . $company['region'] . ', ' . $company['country'], 0, 1);
$pdf->Ln(10);

// Optional: Add a logo (uncomment and adjust path if you have one)
// $pdf->Image('../../../images/logo.png', 15, 15, 30); // Adjust x, y, width

// --- Customer Information ---
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetFillColor(245, 245, 245); // Very light gray
$pdf->Cell(0, 8, 'Bill To:', 1, 1, 'L', true);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 6, $customer['name'], 0, 1);
$pdf->Cell(0, 6, 'Phone: ' . $customer['phone'], 0, 1);
$pdf->Cell(0, 6, 'Email: ' . $customer['email'], 0, 1);
$pdf->Cell(0, 6, $customer['city'] . ', ' . $customer['country'], 0, 1);
$pdf->Ln(10);

// --- Booking Information ---
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetFillColor(245, 245, 245);
$pdf->Cell(0, 8, 'Booking Details:', 1, 1, 'L', true);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(50, 6, 'Booking ID:', 0, 0);
$pdf->Cell(0, 6, $booking['code'], 0, 1);
$pdf->Cell(50, 6, 'Creation Date:', 0, 0);
$pdf->Cell(0, 6, date('d M Y, g:i A', strtotime($booking['dates'] . ' ' . $booking['timee'])), 0, 1);
$pdf->Cell(50, 6, 'Due Date:', 0, 0);
$pdf->Cell(0, 6, date('d M Y, g:i A', strtotime($booking['todate'] . ' ' . $booking['totime'])), 0, 1);
$pdf->Cell(50, 6, 'Room:', 0, 0);
$pdf->Cell(0, 6, $booking['rtype_name'] . ' - ' . $booking['room_name'], 0, 1);
$pdf->Ln(10);

// --- Costs Table ---
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetFillColor(245, 245, 245);
$pdf->Cell(0, 8, 'Cost Breakdown:', 1, 1, 'L', true);

// Table Header
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(200, 220, 255); // Light blue
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(90, 7, 'Description', 1, 0, 'L', true);
$pdf->Cell(30, 7, 'Unit Price', 1, 0, 'R', true);
$pdf->Cell(30, 7, 'Quantity', 1, 0, 'R', true);
$pdf->Cell(40, 7, 'Total', 1, 1, 'R', true);

$pdf->SetFont('Arial', '', 9);

// Price per night
$pricePerNight = floatval($booking['mprice']);
$nights = intval($booking['nights']);
$priceForNights = $pricePerNight * $nights;
$pdf->Cell(90, 6, 'Room Rate (' . $booking['room_name'] . ')', 1, 0, 'L');
$pdf->Cell(30, 6, number_format($pricePerNight, 2), 1, 0, 'R');
$pdf->Cell(30, 6, $nights, 1, 0, 'R');
$pdf->Cell(40, 6, number_format($priceForNights, 2), 1, 1, 'R');

// Other payments
$subtotalBeforeTax = $priceForNights + floatval($booking['vat']) - floatval($booking['discount']);
$otherPayments = floatval($booking['amount']) - $subtotalBeforeTax;
$pdf->Cell(90, 6, 'Other Payments', 1, 0, 'L');
$pdf->Cell(30, 6, number_format($otherPayments, 2), 1, 0, 'R');
$pdf->Cell(30, 6, '1', 1, 0, 'R');
$pdf->Cell(40, 6, number_format($otherPayments, 2), 1, 1, 'R');

// Subtotal
$subtotal = $priceForNights + $otherPayments;
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(240, 240, 240); // Light gray for totals
$pdf->Cell(150, 6, 'Subtotal', 1, 0, 'R', true);
$pdf->Cell(40, 6, number_format($subtotal, 2), 1, 1, 'R', true);

// Tax
$vatPercent = floatval($booking['vatpercent']);
$vatAmount = floatval($booking['vat']);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(90, 6, 'Tax (' . $vatPercent . '%)', 1, 0, 'L');
$pdf->Cell(60, 6, '', 1, 0);
$pdf->Cell(40, 6, number_format($vatAmount, 2), 1, 1, 'R');

// Discount
$discount = floatval($booking['discount']);
$pdf->SetTextColor(0, 128, 0); // Green for discount
$pdf->Cell(90, 6, 'Discount', 1, 0, 'L');
$pdf->Cell(60, 6, '', 1, 0);
$pdf->Cell(40, 6, '-' . number_format($discount, 2), 1, 1, 'R');
$pdf->SetTextColor(0, 0, 0); // Reset to black

// Total Amount
$totalAmount = floatval($booking['amount']);
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(220, 255, 220); // Light green for total
$pdf->Cell(150, 6, 'Total Amount', 1, 0, 'R', true);
$pdf->Cell(40, 6, number_format($totalAmount, 2), 1, 1, 'R', true);

// Amount Paid
$paid = floatval($booking['paid']);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(150, 6, 'Amount Paid', 1, 0, 'R');
$pdf->Cell(40, 6, number_format($paid, 2), 1, 1, 'R');

// Balance Due
$balanceDue = $totalAmount - $paid;
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(255, 245, 245); // Light red if balance due
$pdf->Cell(150, 6, 'Balance Due', 1, 0, 'R', true);
$pdf->Cell(40, 6, number_format($balanceDue, 2), 1, 1, 'R', true);

// Output the PDF
$pdf->Output('invoice_' . $booking['code'] . '.pdf', 'I'); // 'I' for inline display
