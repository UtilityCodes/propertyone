<?php

include '../../../config.php';

session_start();

date_default_timezone_set('Africa/Dar_es_Salaam');

$currentDate = date('Y-m-d');
$currentTime = date('H:i:s');

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

$idtypeQuery = "SELECT idt.id, idt.name
               FROM idtype idt
               ORDER BY idt.id DESC";
$idtypeResult = $conn->query($idtypeQuery);
$idtypes = $idtypeResult->fetch_all(MYSQLI_ASSOC);

$languageQuery = "SELECT la.id, la.name
               FROM languages la
               ORDER BY la.id DESC";
$languageResult = $conn->query($languageQuery);
$languages = $languageResult->fetch_all(MYSQLI_ASSOC);



$customerQuery = "SELECT 
                    cu.id,
                    cu.code,
                    cu.dates,
                    cu.timee,
                    cu.fname,
                    cu.lname,
                    cu.name,
                    cu.languages_id,
                    cu.idtype_id,
                    cu.idno,
                    cu.phone,
                    cu.email,
                    cu.city,
                    cu.state,
                    cu.country,
                    cu.note,
                    cu.company_id
                  FROM customer cu
                  WHERE cu.company_id = '$company'
                  ORDER BY cu.id DESC";
$customerResult = $conn->query($customerQuery);
$customers = $customerResult->fetch_all(MYSQLI_ASSOC);


$rtypeQuery = "SELECT rt.*
               FROM rtype rt
               WHERE rt.company_id = '$company'
               ORDER BY rt.id";
$rtypeResult = $conn->query($rtypeQuery);
$rtypes = $rtypeResult->fetch_all(MYSQLI_ASSOC);


$roomQuery = "SELECT 
                rm.id,
                rm.dates,
                rm.timee,
                rm.code,
                rm.name,
                rm.rtype_id,
                rm.uprice,
                rm.note,
                rm.company_id
              FROM rooms rm
              INNER JOIN rtype rt ON rm.rtype_id = rt.id
              WHERE rm.company_id = '$company'
              ORDER BY rm.id";
$roomResult = $conn->query($roomQuery);
$rooms = $roomResult->fetch_all(MYSQLI_ASSOC);

$housekeepingQuery = "SELECT
                        hk.id,
                        hk.code,
                        hk.dates,
                        hk.timee,
                        hk.rooms_id,
                        hk.hktype_id,
                        hk.fromdate,
                        hk.fromtime,
                        hk.todate,
                        hk.totime,
                        hk.note,
                        hk.company_id,
                        hk.user_id
                      FROM house_keeping hk
                      INNER JOIN rooms rm ON hk.rooms_id = rm.id
                      INNER JOIN hktype hkt ON hk.hktype_id = hkt.id
                      INNER JOIN user us ON hk.user_id = us.id
                      WHERE hk.company_id = '$company'
                      ORDER BY hk.id";
$housekeepingResult = $conn->query($housekeepingQuery);
$housekeepings = $housekeepingResult->fetch_all(MYSQLI_ASSOC);




$bookingQuery = "SELECT 
                bk.id,
                bk.code,
                bk.dates,
                bk.timee,
                bk.fromdate,
                bk.fromtime,
                bk.checkindate,
                bk.checkintime,
                bk.checkoutdate,
                bk.checkouttime,
                bk.cancdate,
                bk.canctime,
                bk.todate,
                bk.totime,
                bk.rooms_id,
                bk.ogprice,
                bk.mprice,
                bk.adults,
                bk.children,
                bk.babies,
                bk.note,
                bk.customer_idno,
                bk.discount,
                bk.amount,
                bk.paid,
                bk.refund,
                bk.company_id,
                bk.user_id,
                rm.name as room,
                rt.name as rtype,
                cu.name as customer,
                us.name as user
              FROM bookings bk
              INNER JOIN rooms rm ON bk.rooms_id = rm.id
              INNER JOIN rtype rt ON rm.rtype_id = rt.id
              INNER JOIN customer cu ON bk.customer_idno = cu.idno
              INNER JOIN user us ON bk.user_id = us.id
              WHERE bk.company_id = '$company'
              ORDER BY bk.id";
$bookingResult = $conn->query($bookingQuery);
$bookings = $bookingResult->fetch_all(MYSQLI_ASSOC);

// Payment Methods Accounts
// Cash Accounts
$cashaccountQuery = "SELECT ac.*
                     FROM accounts ac
                     INNER JOIN methods mt ON ac.methods_id = mt.id
                     WHERE ac.company_id = '$company' AND mt.name = 'CASH'";
$cashaccountResult = $conn->query($cashaccountQuery);
$cashaccounts = $cashaccountResult->fetch_all(MYSQLI_ASSOC);

// Bank Accounts
$bankaccountQuery = "SELECT ac.*
                     FROM accounts ac
                     INNER JOIN methods mt ON ac.methods_id = mt.id
                     WHERE ac.company_id = '$company' AND mt.name = 'BANK'";
$bankaccountResult = $conn->query($bankaccountQuery);
$bankaccounts = $bankaccountResult->fetch_all(MYSQLI_ASSOC);

// Mobile Accounts
$mobileaccountQuery = "SELECT ac.*
                     FROM accounts ac
                     INNER JOIN methods mt ON ac.methods_id = mt.id
                     WHERE ac.company_id = '$company' AND mt.name = 'MOBILE'";
$mobileaccountResult = $conn->query($mobileaccountQuery);
$mobileaccounts = $mobileaccountResult->fetch_all(MYSQLI_ASSOC);

// Pos Accounts
$posaccountQuery = "SELECT ac.*
                     FROM accounts ac
                     INNER JOIN methods mt ON ac.methods_id = mt.id
                     WHERE ac.company_id = '$company' AND mt.name = 'POS'";
$posaccountResult = $conn->query($posaccountQuery);
$posaccounts = $posaccountResult->fetch_all(MYSQLI_ASSOC);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Reservation List';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Reservations';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    All Reservations
                </a>
                <a href="#" data-page="1">
                    Booked
                </a>
                <a href="#" data-page="2">
                    Checked In
                </a>
                <a href="#" data-page="3">
                    Checked Out
                </a>
                <a href="#" data-page="4">
                    Cancelled
                </a>

            </div>
            <div class="inline-page-body">
                <!--All Reservations-->
                <div class="page active">

                    <div class="options-tab">
                        <div class="ot-flex">
                            <div class="more-options">
                                <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                    <title>More Options</title>
                                    <path d="M416,170.667H96A53.333,53.333,0,0,1,96,64H416a53.333,53.333,0,0,1,0,106.667Zm-320-64A10.667,10.667,0,1,0,96,128H416a10.667,10.667,0,1,0,0-21.333Z"></path>
                                    <path d="M416,309.333H96a53.333,53.333,0,1,1,0-106.667H416a53.333,53.333,0,0,1,0,106.667Zm-320-64a10.667,10.667,0,0,0,0,21.333H416a10.667,10.667,0,0,0,0-21.333Z"></path>
                                    <path d="M416,448H96a53.333,53.333,0,0,1,0-106.667H416A53.333,53.333,0,0,1,416,448ZM96,384a10.667,10.667,0,1,0,0,21.333H416A10.667,10.667,0,1,0,416,384Z"></path>
                                </svg>
                            </div>
                            <div class="operative-options">
                                <button class="add-btn">
                                    <div class="icon">
                                        <i class="fa fa-plus" aria-hidden="true"></i>
                                    </div>
                                    <span>Add New Booking</span>
                                </button>
<!-- 
                                <button class="add1-btn">
                                    <div class="icon">
                                        <i class="fa fa-upload" aria-hidden="true"></i>
                                    </div>
                                    <span>Import</span>
                                </button>

                                <button class="export-btn">
                                    <div class="icon">
                                        <i class="fa fa-download" aria-hidden="true"></i>
                                    </div>
                                    <span>Export</span>
                                </button> -->
                            </div>
                        </div>

                        <div class="extra-tab">
                            <div class="extra-options">
                                <div class="eo-flex">
                                    <!-- <a href="">
                                        <button>
                                            <div class="icon">
                                                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;" xml:space="preserve">
                                                    <title>Reports</title>
                                                    <g id="Layer_1">
                                                        <path d="M26,3V1h-2v2H3H1v2h2v26H1v2h2h17.471L14,47.791V49h2v-0.791L22.654,33H24v16h2V33h1.346L34,48.209V49h2v-1.209L29.529,33
                                                            H47h2v-2h-2V5h2V3h-2H26z M45,31H5V5h40V31z"></path>
                                                        <path d="M16,28c4.411,0,8-3.589,8-8v-1h-7v-7h-1c-4.411,0-8,3.589-8,8S11.589,28,16,28z M15,14.083V21h6.917
                                                            c-0.478,2.834-2.949,5-5.917,5c-3.309,0-6-2.691-6-6C10,17.032,12.166,14.561,15,14.083z"></path>
                                                        <path d="M28,16c0-4.411-3.589-8-8-8h-1v9h9V16z M21,15v-4.917c2.509,0.422,4.494,2.408,4.917,4.917H21z"></path>
                                                        <rect x="31" y="10" width="10" height="2"></rect>
                                                        <rect x="31" y="15" width="10" height="2"></rect>
                                                        <rect x="31" y="20" width="10" height="2"></rect>
                                                    </g>
                                                    <g>
                                                    </g>
                                                </svg>
                                            </div>
                                            <span>Go To Reports</span>
                                        </button>
                                    </a> -->
                                    <a href="">
                                        <button>
                                            <div class="icon">
                                                <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100.353 100.353" style="enable-background:new 0 0 100.353 100.353;" xml:space="preserve">
                                                    <title>Calendar</title>
                                                    <g>
                                                        <path style="fill:#231F20;" d="M33.46,43.065h-9.051c-0.829,0-1.5,0.671-1.5,1.5v9.045c0,0.829,0.671,1.5,1.5,1.5h9.051
                                                            c0.829,0,1.5-0.671,1.5-1.5v-9.045C34.96,43.737,34.288,43.065,33.46,43.065z M31.96,52.111h-6.051v-6.045h6.051V52.111z"></path>
                                                        <path style="fill:#231F20;" d="M54.571,43.065h-9.054c-0.829,0-1.5,0.671-1.5,1.5v9.045c0,0.829,0.671,1.5,1.5,1.5h9.054
                                                            c0.829,0,1.5-0.671,1.5-1.5v-9.045C56.071,43.737,55.4,43.065,54.571,43.065z M53.071,52.111h-6.054v-6.045h6.054V52.111z"></path>
                                                        <path style="fill:#231F20;" d="M33.46,63.677h-9.051c-0.829,0-1.5,0.672-1.5,1.5v9.051c0,0.829,0.671,1.5,1.5,1.5h9.051
                                                            c0.829,0,1.5-0.671,1.5-1.5v-9.051C34.96,64.349,34.288,63.677,33.46,63.677z M31.96,72.728h-6.051v-6.051h6.051V72.728z"></path>
                                                        <path style="fill:#231F20;" d="M54.571,63.677h-9.054c-0.829,0-1.5,0.672-1.5,1.5v9.051c0,0.829,0.671,1.5,1.5,1.5h9.054
                                                            c0.829,0,1.5-0.671,1.5-1.5v-9.051C56.071,64.349,55.4,63.677,54.571,63.677z M53.071,72.728h-6.054v-6.051h6.054V72.728z"></path>
                                                        <path style="fill:#231F20;" d="M75.024,63.677h-9.047c-0.829,0-1.5,0.672-1.5,1.5v9.051c0,0.829,0.671,1.5,1.5,1.5h9.047
                                                            c0.829,0,1.5-0.671,1.5-1.5v-9.051C76.524,64.349,75.852,63.677,75.024,63.677z M73.524,72.728h-6.047v-6.051h6.047V72.728z"></path>
                                                        <path style="fill:#231F20;" d="M86.04,16.132h-9.111v-1.739c0-3.09-2.513-5.604-5.601-5.604c-3.09,0-5.604,2.514-5.604,5.604v1.739
                                                            H55.592v-1.739c0-3.09-2.513-5.604-5.601-5.604c-3.092,0-5.607,2.514-5.607,5.604v1.739H34.255v-1.739
                                                            c0-3.09-2.512-5.604-5.601-5.604c-3.092,0-5.607,2.514-5.607,5.604v1.739h-9.085c-0.829,0-1.5,0.671-1.5,1.5v72.08
                                                            c0,0.828,0.671,1.5,1.5,1.5h72.08c0.829,0,1.5-0.672,1.5-1.5v-72.08C87.54,16.803,86.869,16.132,86.04,16.132z M68.723,14.393
                                                            c0-1.437,1.168-2.604,2.604-2.604c1.434,0,2.601,1.168,2.601,2.604v7.676c0,1.436-1.167,2.604-2.601,2.604
                                                            c-1.436,0-2.604-1.168-2.604-2.604V14.393z M49.99,11.788c1.434,0,2.601,1.168,2.601,2.604v7.676c0,1.436-1.167,2.604-2.601,2.604
                                                            c-1.438,0-2.607-1.168-2.607-2.604v-4.272c0.006-0.055,0.017-0.108,0.017-0.165s-0.011-0.11-0.017-0.165v-3.074
                                                            C47.383,12.956,48.553,11.788,49.99,11.788z M26.046,14.393c0-1.437,1.17-2.604,2.607-2.604c1.434,0,2.601,1.168,2.601,2.604v7.676
                                                            c0,1.436-1.167,2.604-2.601,2.604c-1.438,0-2.607-1.168-2.607-2.604V14.393z M84.54,88.211H15.46v-69.08h7.585v2.937
                                                            c0,3.09,2.516,5.604,5.607,5.604c3.088,0,5.601-2.514,5.601-5.604v-2.937h10.129v2.937c0,3.09,2.516,5.604,5.607,5.604
                                                            c3.088,0,5.601-2.514,5.601-5.604v-2.937h10.132v2.937c0,3.09,2.514,5.604,5.604,5.604c3.088,0,5.601-2.514,5.601-5.604v-2.937
                                                            h7.611v69.08H84.54z"></path>
                                                        <path style="fill:#231F20;" d="M76.683,38.729l-7.654,9.434l-3.193-3.048c-0.599-0.572-1.548-0.55-2.121,0.049
                                                            c-0.572,0.6-0.55,1.549,0.049,2.121l4.369,4.171c0.28,0.267,0.651,0.415,1.036,0.415c0.032,0,0.063-0.001,0.095-0.003
                                                            c0.418-0.026,0.806-0.227,1.07-0.552l8.679-10.696c0.522-0.643,0.423-1.588-0.22-2.11C78.15,37.987,77.205,38.086,76.683,38.729z"></path>
                                                    </g>
                                                </svg>
                                            </div>
                                            <span>Go To Calendar</span>
                                        </button>
                                    </a>
                                </div>
                            </div>
                            <div class="register">
                                <div class="reg-flex">
                                    <div class="reg-heading">
                                        <h2> New Booking: </h2>
                                       
                                    </div>
                                    <form action="actionform.php" class="reg-form" method="post">
                                        <div class="form-section">
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Choose Customer:<span>*</span></label><br>
                                                    <select name="customer" id="customer">
                                                        <option value="" selected disabled>--Select Customer--</option>
                                                        <?php
                                                            foreach ($customers as $customer) {
                                                                echo "<option value='{$customer['id']}'>{$customer['name']}</option>";
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">First Name:</label><br>
                                                    <input type="text" value="" name="fname" id="fname" required>
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Last Name:</label><br>
                                                    <input type="text" value="" name="lname" id="lname" required>
                                                </div>

                                                <div class="input-label">
                                                    <label for="">Language:</label><br>
                                                    <select name="language" id="language" required>
                                                        <option value="" selected disabled>--Select Language--</option>
                                                        <?php
                                                            foreach ($languages as $language) {
                                                                echo "<option value='{$language['id']}'>{$language['name']}</option>";
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                                
                                            </div>
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">ID TYPE:</label><br>
                                                    <select name="idtype" id="idtype" required>
                                                        <option value="" selected disabled>--Select ID Type--</option>
                                                        <?php
                                                            foreach ($idtypes as $idtype) {
                                                                echo "<option value='{$idtype['id']}'>{$idtype['name']}</option>";
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                                <div class="input-label">
                                                    <label for="">ID NUMBER:</label><br>
                                                    <input type="text" value="" name="idno" id="idno" required>
                                                </div>
                                            </div>
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Phone:</label><br>
                                                    <input type="text" value="" name="phone" id="phone" required>
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Email:</label><br>
                                                    <input type="text" value="" name="email" id="email">
                                                </div>
                                            </div>
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">City:</label><br>
                                                    <input type="text" value="" name="city" id="city">
                                                </div>
                                                <div class="input-label">
                                                    <label for="">State:</label><br>
                                                    <input type="text" value="" name="state" id="state">
                                                </div>
                                                
                                                <div class="input-label">
                                                    <label for="">Country:</label><br>
                                                    <input type="text" value="" name="country" id="country">
                                                </div>
                                            </div>

                                            <!--from and to-->
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">FROM:<span>*</span></label><br>
                                                    <div class="date-time">
                                                        <input type="date" class="date" name="fromdate" id="fromdate" value="<?php echo $currentDate?>">
                                                        <input type="time" class="time" name="fromtime" id="fromtime" value="<?php echo $currentTime?>">
                                                    </div>
                                                </div>

                                                <div class="input-label">
                                                    <label for="">TO:<span>*</span></label><br>
                                                    <div class="date-time">
                                                        <input type="date" class="date" name="todate" id="todate">
                                                        <input type="time" class="time" name="totime" value="10:00" id="totime">
                                                    </div>
                                                </div>
                                            </div>

                                            <!--rtype and rooms-->
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Room Type:<span>*</span></label><br>
                                                    <select name="rtype">
                                                        <option value="" selected disabled>--Select Room Type--</option>
                                                        <?php
                                                            foreach ($rtypes as $rtype) {
                                                                echo "<option value='{$rtype['id']}'>{$rtype['name']}</option>";
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Room:<span>*</span></label><br>
                                                    <select name="room" required>
                                                        <option value="" selected disabled>--Select Room--</option>
                                                        <!-- Room options will be populated by JavaScript -->
                                                    </select>
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Checked-in?</label><br>
                                                    <input type="checkbox" name="checkedin">
                                                </div>
                                            </div>


                                            <!--initial prices-->
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Original Price:</label><br>
                                                    <input type="number" value="0.00" name="ogprice" id="ogprice" readonly>
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Manual Price:</label><br>
                                                    <input type="number" value="0.00" name="mprice" id="mprice">
                                                </div>
                                            </div>

                                            <!--final prices and other payments-->
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Nights:</label><br>
                                                    <input type="number" value="0" name="nights" id="nights" readonly>
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Price of nights:</label><br>
                                                    <input type="number" value="0.00" id="pricenights">
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Other Payments:</label><br>
                                                    <input type="number" value="0.00" id="otherpay">
                                                </div>
                                            </div>
                                            
                                            <!--adults children babies-->
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Adults:<span>*</span></label><br>
                                                    <input type="number" name="adults" value="1" required>
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Children:</label><br>
                                                    <input type="number" value="0" name="children">
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Babies:</label><br>
                                                    <input type="number" value="0" name="babies">
                                                </div>
                                            </div>

                                            <!--description-->
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Description:</label><br>
                                                    <textarea name="note"></textarea>
                                                </div>
                                            </div>

                                            <!--subtotal discount-->
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Subtotal:</label>
                                                    <input type="number" value="0.00" id="subtotal" readonly>
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Discount:</label>
                                                    <input type="number" value="0.00" name="discount" id="discount">
                                                </div>
                                                <div class="input-label">
                                                    <label for="">New Subtotal:</label>
                                                    <input type="number" value="0.00" id="newsubtotal" readonly>
                                                </div>
                                            </div>

                                            <!--vat-->
                                            <div class="sec">
                                                <label for="">
                                                    Vat <input type="number" value="18" name="vatpercent" id="vatpercent">%
                                                </label>
                                                <input type="number" id="vat" name="vat" readonly>
                                            </div>

                                            <!--amount-->
                                            <div class="sec">
                                                <label for="">Amount:</label>
                                                <input type="number" name="amount" id="amount" readonly>
                                            </div>

                                            <hr>

                                            <h3>Payment Methods</h3>
                                            <!--Cash-->
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Cash:</label><br>
                                                    <div class="account-amount">
                                                        <select name="cashaccount" id="cashaccount">
                                                            <option value="" selected disabled>--Select Account</option>
                                                            <?php
                                                                foreach ($cashaccounts as $cashaccount) {
                                                                    echo "<option value='{$cashaccount['id']}'>{$cashaccount['name']}</option>";
                                                                }
                                                            ?>
                                                        </select>
                                                        <input type="number" name="cashamount" id="cashamount" placeholder="CASH">
                                                    </div>
                                                </div>

                                            </div>
                                            <!--Bank-->
                                            <div class="sec">
                                                
                                                <div class="input-label">
                                                    <label for="">Bank:</label><br>
                                                    <div class="account-amount">
                                                        <select name="bankaccount" id="bankaccount">
                                                            <option value="" selected disabled>--Select Account</option>
                                                            <?php
                                                                foreach ($bankaccounts as $bankaccount) {
                                                                    echo "<option value='{$bankaccount['id']}'>{$bankaccount['name']}</option>";
                                                                }
                                                            ?>
                                                        </select>
                                                        <input type="number" name="bankamount" id="bankamount" placeholder="BANK">
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            <!--Mobile-->
                                            <div class="sec">
                                                
                                                <div class="input-label">
                                                    <label for="">Mobile:</label><br>
                                                    <div class="account-amount">
                                                        <select name="mobileaccount" id="mobileaccount">
                                                            <option value="" selected disabled>--Select Account</option>
                                                            <?php
                                                                foreach ($mobileaccounts as $mobileaccount) {
                                                                    echo "<option value='{$mobileaccount['id']}'>{$mobileaccount['name']}</option>";
                                                                }
                                                            ?>
                                                        </select>
                                                        <input type="number" name="mobileamount" id="mobileamount" placeholder="MOBILE">
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            <!--POS-->
                                            <div class="sec">
                                                
                                                <div class="input-label">
                                                    <label for="">POS:</label><br>
                                                    <div class="account-amount">
                                                        <select name="posaccount" id="posaccount">
                                                            <option value="" selected disabled>--Select Account</option>
                                                            <?php
                                                                foreach ($posaccounts as $posaccount) {
                                                                    echo "<option value='{$posaccount['id']}'>{$posaccount['name']}</option>";
                                                                }
                                                            ?>
                                                        </select>
                                                        <input type="number" name="posamount" id="posamount" placeholder="POS">
                                                    </div>
                                                </div>
                                                
                                            </div>

                                            <!--Total-->
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Total:</label>
                                                    <input type="number" value="0.00" name="paid" id="totalamount" readonly>
                                                </div>
                                            </div>
                                            
                                            <!--Change-->
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Change:</label>
                                                    <input type="number" value="0.00" id="change" readonly>
                                                </div>
                                            </div>
                                            
                                            <!--Remain-->
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Remaining:</label>
                                                    <input type="number" value="0.00" id="remain" readonly>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <div class="form-submit">
                                            <button class="cancel">
                                                <div class="icon">
                                                    <i class="fa fa-times" aria-hidden="true"></i>
                                                </div>
                                                <span>CANCEL</span>
                                            </button>
                                            <button class="confirm" name="submit">
                                                <div class="icon">
                                                    <i class="fa fa-check" aria-hidden="true"></i>
                                                </div>
                                                <span>CONFIRM</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="register2">
                                <div class="reg-flex">
                                    <div class="reg-heading">
                                        <h2>New Customer:</h2>
                                       
                                    </div>
                                    <form action="" class="reg-form">
                                        <div class="form-section">
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Code:</label><br>
                                                    <input type="text">
                                                </div>
                                                <div class="input-label">
                                                    <label for="">First Name: <span>*</span></label><br>
                                                    <input type="text">
                                                </div>
                                                
                                                <div class="input-label">
                                                    <label for="">Last Name: <span>*</span></label><br>
                                                    <input type="text">
                                                </div>
                                            </div>
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Language: <span>*</span></label><br>
                                                    <input type="text">
                                                </div>
                                            </div>
                                            <div class="sec">
                                                
                                                <div class="input-label">
                                                    <label for="">ID TYPE:<span>*</span></label><br>
                                                    <select name="" id="">
                                                        <option value="" selected disabled>--Select ID TYPE--</option>
                                                        <option value="">LICENCE</option>
                                                        <option value="">NATIONAL</option>
                                                        <option value="">STUDENT</option>
                                                        <option value="">VOTING</option>
                                                    </select>
                                                </div>
                                                <div class="input-label">
                                                    <label for="">ID Number: <span>*</span></label><br>
                                                    <input type="text">
                                                </div>
                                            </div>

                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Phone: <span>*</span></label><br>
                                                    <input type="text">
                                                </div>
                                                
                                                <div class="input-label">
                                                    <label for="">Email:</label><br>
                                                    <input type="text">
                                                </div>
                                            </div>

                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">City:</label><br>
                                                    <input type="text">
                                                </div>
                                                <div class="input-label">
                                                    <label for="">State:</label><br>
                                                    <input type="text">
                                                </div>
                                                <div class="input-label">
                                                    <label for="">Country:</label><br>
                                                    <input type="text">
                                                </div>
                                            </div>
                                            <div class="sec">
                                                <div class="input-label">
                                                    <label for="">Description:</label><br>
                                                    <textarea name="" id=""></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-submit">
                                            <button class="cancel">
                                                <div class="icon">
                                                    <i class="fa fa-times" aria-hidden="true"></i>
                                                </div>
                                                <span>CANCEL</span>
                                            </button>
                                            <button class="confirm">
                                                <div class="icon">
                                                    <i class="fa fa-check" aria-hidden="true"></i>
                                                </div>
                                                <span>CONFIRM</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="export">
                                <form class="e-flex">
                                    <div class="exp-heading">
                                        <h2>Export Data To Your Computer:</h2>
                                    </div>
                                    <div class="exp-body">
                                        <div class="exp-btns">
                                            <button class="csv">
                                                <div class="icon">
                                                    <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 56 56" style="enable-background:new 0 0 56 56;" xml:space="preserve">
                                                        <g>
                                                            <path style="fill:#E9E9E0;" d="M36.985,0H7.963C7.155,0,6.5,0.655,6.5,1.926V55c0,0.345,0.655,1,1.463,1h40.074
                                                                c0.808,0,1.463-0.655,1.463-1V12.978c0-0.696-0.093-0.92-0.257-1.085L37.607,0.257C37.442,0.093,37.218,0,36.985,0z"></path>
                                                            <polygon style="fill:#D9D7CA;" points="37.5,0.151 37.5,12 49.349,12 	"></polygon>
                                                            <path style="fill:#F36FA0;" d="M48.037,56H7.963C7.155,56,6.5,55.345,6.5,54.537V39h43v15.537C49.5,55.345,48.845,56,48.037,56z"></path>
                                                            <g>
                                                                <path style="fill:#FFFFFF;" d="M21.58,51.975c-0.374,0.364-0.798,0.638-1.271,0.82c-0.474,0.183-0.984,0.273-1.531,0.273
                                                                    c-0.602,0-1.155-0.109-1.661-0.328s-0.948-0.542-1.326-0.971c-0.378-0.429-0.675-0.966-0.889-1.613
                                                                    c-0.214-0.647-0.321-1.395-0.321-2.242s0.107-1.593,0.321-2.235c0.214-0.643,0.51-1.178,0.889-1.606
                                                                    c0.378-0.429,0.822-0.754,1.333-0.978c0.51-0.224,1.062-0.335,1.654-0.335c0.547,0,1.057,0.091,1.531,0.273
                                                                    c0.474,0.183,0.897,0.456,1.271,0.82l-1.135,1.012c-0.228-0.265-0.481-0.456-0.759-0.574c-0.278-0.118-0.567-0.178-0.868-0.178
                                                                    c-0.337,0-0.659,0.063-0.964,0.191c-0.306,0.128-0.579,0.344-0.82,0.649c-0.242,0.306-0.431,0.699-0.567,1.183
                                                                    s-0.21,1.075-0.219,1.777c0.009,0.684,0.08,1.267,0.212,1.75c0.132,0.483,0.314,0.877,0.547,1.183s0.497,0.528,0.793,0.67
                                                                    c0.296,0.142,0.608,0.212,0.937,0.212s0.636-0.06,0.923-0.178s0.549-0.31,0.786-0.574L21.58,51.975z"></path>
                                                                <path style="fill:#FFFFFF;" d="M29.633,50.238c0,0.364-0.075,0.718-0.226,1.06s-0.362,0.643-0.636,0.902s-0.611,0.467-1.012,0.622
                                                                    c-0.401,0.155-0.857,0.232-1.367,0.232c-0.219,0-0.444-0.012-0.677-0.034s-0.467-0.062-0.704-0.116
                                                                    c-0.237-0.055-0.463-0.13-0.677-0.226c-0.214-0.096-0.399-0.212-0.554-0.349l0.287-1.176c0.127,0.073,0.289,0.144,0.485,0.212
                                                                    c0.196,0.068,0.398,0.132,0.608,0.191c0.209,0.06,0.419,0.107,0.629,0.144c0.209,0.036,0.405,0.055,0.588,0.055
                                                                    c0.556,0,0.982-0.13,1.278-0.39c0.296-0.26,0.444-0.645,0.444-1.155c0-0.31-0.105-0.574-0.314-0.793
                                                                    c-0.21-0.219-0.472-0.417-0.786-0.595s-0.654-0.355-1.019-0.533c-0.365-0.178-0.707-0.388-1.025-0.629
                                                                    c-0.319-0.241-0.583-0.526-0.793-0.854c-0.21-0.328-0.314-0.738-0.314-1.23c0-0.446,0.082-0.843,0.246-1.189
                                                                    s0.385-0.641,0.663-0.882c0.278-0.241,0.602-0.426,0.971-0.554s0.759-0.191,1.169-0.191c0.419,0,0.843,0.039,1.271,0.116
                                                                    c0.428,0.077,0.774,0.203,1.039,0.376c-0.055,0.118-0.119,0.248-0.191,0.39c-0.073,0.142-0.142,0.273-0.205,0.396
                                                                    c-0.064,0.123-0.119,0.226-0.164,0.308c-0.046,0.082-0.073,0.128-0.082,0.137c-0.055-0.027-0.116-0.063-0.185-0.109
                                                                    s-0.167-0.091-0.294-0.137c-0.128-0.046-0.296-0.077-0.506-0.096c-0.21-0.019-0.479-0.014-0.807,0.014
                                                                    c-0.183,0.019-0.355,0.07-0.52,0.157s-0.31,0.193-0.438,0.321c-0.128,0.128-0.228,0.271-0.301,0.431
                                                                    c-0.073,0.159-0.109,0.313-0.109,0.458c0,0.364,0.104,0.658,0.314,0.882c0.209,0.224,0.469,0.419,0.779,0.588
                                                                    c0.31,0.169,0.647,0.333,1.012,0.492c0.364,0.159,0.704,0.354,1.019,0.581s0.576,0.513,0.786,0.854
                                                                    C29.528,49.261,29.633,49.7,29.633,50.238z"></path>
                                                                <path style="fill:#FFFFFF;" d="M34.035,53.055l-3.131-10.131h1.873l2.338,8.695l2.475-8.695h1.859l-3.281,10.131H34.035z"></path>
                                                            </g>
                                                            <path style="fill:#C8BDB8;" d="M23.5,16v-4h-12v4v2v2v2v2v2v2v2v4h10h2h21v-4v-2v-2v-2v-2v-2v-4H23.5z M13.5,14h8v2h-8V14z
                                                                 M13.5,18h8v2h-8V18z M13.5,22h8v2h-8V22z M13.5,26h8v2h-8V26z M21.5,32h-8v-2h8V32z M42.5,32h-19v-2h19V32z M42.5,28h-19v-2h19V28
                                                                z M42.5,24h-19v-2h19V24z M23.5,20v-2h19v2H23.5z"></path>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                        <g>
                                                        </g>
                                                    </svg>
                                                </div>
                                                <span>Download CSV file</span>
                                            </button>
                                            <button class="excel">
                                                <div class="icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 48 64">
                                                        <g id="Excel_Paper_32" data-name="Excel Paper 32" transform="translate(0)">
                                                          <g id="paper_32" data-name="paper 32">
                                                            <path id="Rectangle_23" data-name="Rectangle 23" d="M0,0,16,16H0Z" transform="translate(32)" fill="#bdc3c7"></path>
                                                            <path id="Rectangle_21" data-name="Rectangle 21" d="M44,64H4a4,4,0,0,1-4-4V4A4,4,0,0,1,4,0H32V12a4,4,0,0,0,4,4H48V60A4,4,0,0,1,44,64Z" fill="#ecf0f1"></path>
                                                          </g>
                                                          <g id="Rectangle_38" data-name="Rectangle 38" transform="translate(8 24)" fill="none" stroke="#bdc3c7" stroke-miterlimit="10" stroke-width="2">
                                                            <rect width="32" height="32" stroke="none"></rect>
                                                            <rect x="1" y="1" width="30" height="30" fill="none"></rect>
                                                          </g>
                                                          <g id="lines" transform="translate(8 21)">
                                                            <g id="Group" transform="translate(28 1) rotate(90)">
                                                              <path id="Line" d="M1,3H31" transform="translate(2)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-2" data-name="Line" d="M1,3H31" transform="translate(2 6)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-3" data-name="Line" d="M1,3H31" transform="translate(2 12)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-4" data-name="Line" d="M1,3H31" transform="translate(2 18)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                            </g>
                                                            <g id="Group-2" data-name="Group" transform="translate(0 7)">
                                                              <path id="Line-5" data-name="Line" d="M1,3H31" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-6" data-name="Line" d="M1,3H31" transform="translate(0 6)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-7" data-name="Line" d="M1,3H31" transform="translate(0 12)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                              <path id="Line-8" data-name="Line" d="M1,3H31" transform="translate(0 18)" fill="none" stroke="#bdc3c7" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2"></path>
                                                            </g>
                                                          </g>
                                                        </g>
                                                      </svg>
                                                </div>
                                                <span>Download EXCEL file</span>
                                            </button>
                                            <button class="pdf">
                                                <div class="icon">
                                                    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                                        <style type="text/css">
                                                            .st0{fill:#F4F4F3;}
                                                            .st1{fill:#EDECEB;}
                                                            .st2{fill:#F05458;}
                                                        </style>
                                                        <g>
                                                            <g>
                                                                <path class="st0" d="M414.2,121.5v317.6c0,7.4-6,13.4-13.4,13.4H111.2c-7.4,0-13.4-6-13.4-13.4V72.9c0-7.4,6-13.4,13.4-13.4h237.6
                                                                    L414.2,121.5z"></path>
                                                                <path class="st1" d="M414.2,121.5h-52.1c-7.4,0-13.4-6-13.4-13.4V59.5L414.2,121.5z"></path>
                                                            </g>
                                                            <rect x="97.8" y="307.9" class="st2" width="316.5" height="103.3"></rect>
                                                            <g>
                                                                <path class="st0" d="M188.6,366.9h-13.3v20.3c0,2.9-0.7,5.1-2.1,6.6s-3.1,2.2-5.2,2.2c-2.2,0-3.9-0.7-5.3-2.2
                                                                    c-1.3-1.5-2-3.7-2-6.5V332c0-3.2,0.7-5.5,2.2-6.8s3.8-2.1,7-2.1h18.6c5.5,0,9.7,0.4,12.7,1.3c2.9,0.8,5.5,2.2,7.6,4.1
                                                                    c2.1,1.9,3.8,4.2,4.9,6.9s1.7,5.8,1.7,9.2c0,7.3-2.2,12.8-6.7,16.6S197.5,366.9,188.6,366.9z M185.1,334.1h-9.8v21.9h9.8
                                                                    c3.4,0,6.3-0.4,8.6-1.1c2.3-0.7,4-1.9,5.2-3.5c1.2-1.6,1.8-3.8,1.8-6.4c0-3.2-0.9-5.7-2.8-7.7
                                                                    C195.9,335.1,191.6,334.1,185.1,334.1z"></path>
                                                                <path class="st0" d="M236.5,323.2h18.9c4.9,0,9.1,0.5,12.6,1.4c3.5,0.9,6.7,2.6,9.6,5.1c7.5,6.4,11.2,16.1,11.2,29.1
                                                                    c0,4.3-0.4,8.2-1.1,11.8c-0.7,3.5-1.9,6.7-3.5,9.6c-1.6,2.8-3.6,5.4-6,7.6c-1.9,1.7-4,3.1-6.3,4.2c-2.3,1-4.7,1.8-7.3,2.2
                                                                    c-2.6,0.4-5.6,0.6-8.9,0.6h-18.9c-2.6,0-4.6-0.4-6-1.2c-1.3-0.8-2.2-1.9-2.6-3.4c-0.4-1.4-0.6-3.3-0.6-5.6V332
                                                                    c0-3.1,0.7-5.4,2.1-6.8C231.1,323.9,233.4,323.2,236.5,323.2z M242.1,334.6v48.6h11c2.4,0,4.3-0.1,5.7-0.2c1.4-0.1,2.8-0.5,4.2-1
                                                                    c1.5-0.5,2.7-1.3,3.8-2.2c4.8-4.1,7.3-11.2,7.3-21.2c0-7.1-1.1-12.4-3.2-15.9c-2.1-3.5-4.8-5.8-7.9-6.7c-3.1-1-6.9-1.4-11.3-1.4
                                                                    H242.1z"></path>
                                                                <path class="st0" d="M344.3,334.3h-28.6v18.3h23.9c2.2,0,3.9,0.5,5,1.5c1.1,1,1.6,2.3,1.6,4s-0.6,3-1.7,4c-1.1,1-2.8,1.5-4.9,1.5
                                                                    h-23.9v23.6c0,3-0.7,5.2-2,6.7c-1.4,1.4-3.1,2.2-5.2,2.2c-2.1,0-3.9-0.7-5.2-2.2c-1.4-1.5-2-3.7-2-6.6V332c0-2.1,0.3-3.8,0.9-5.1
                                                                    c0.6-1.3,1.6-2.3,2.9-2.9c1.3-0.6,3-0.9,5.1-0.9h34.2c2.3,0,4,0.5,5.2,1.5s1.7,2.4,1.7,4c0,1.7-0.6,3.1-1.7,4.1
                                                                    S346.6,334.3,344.3,334.3z"></path>
                                                            </g>
                                                        </g>
                                                    </svg>
                                                </div>
                                                <span>Download PDF file</span>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                    Reservation List
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">
    <?php
    include '../../../config.php';

    $sqlView = "SELECT 
                    bk.*,
                    rt.name AS rtype,
                    rm.name AS room,
                    cu.name AS customer,
                    cu.phone AS phone,
                    cu.email AS email,
                    us.name AS user
                FROM bookings bk
                INNER JOIN rooms rm ON bk.rooms_id = rm.id
                INNER JOIN rtype rt ON rm.rtype_id = rt.id
                INNER JOIN customer cu ON bk.customer_idno = cu.idno
                INNER JOIN user us ON bk.user_id = us.id
                WHERE bk.company_id = ?
                GROUP BY bk.id
                ORDER BY bk.id DESC";
    $stmt = $conn->prepare($sqlView);
    $stmt->bind_param("s", $company);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            ?>
            <div class="pcb-boxes">
                <div class="flex">
                    <div class="act-details pcb-box">
                        <div class="code"><?php echo htmlspecialchars($row['code']); ?></div>
                        <div class="date"><?php echo date('d M Y', strtotime($row['dates'])); ?></div>
                        <div class="time"><?php echo date('g:i A', strtotime($row['timee'])); ?></div>
                    </div>
                    <div class="room-rt pcb-box">
                        <div class="rt"><?php echo htmlspecialchars($row['rtype']); ?></div>
                        <span><?php echo htmlspecialchars($row['room']); ?></span>
                    </div>
                    <div class="customer pcb-box">
                        <span><?php echo htmlspecialchars($row['customer']); ?></span>
                        <span><?php echo htmlspecialchars($row['phone']); ?></span>
                        <span><?php echo htmlspecialchars($row['email']); ?></span>
                    </div>
                    <div class="duration pcb-box">
                        <div class="from act">
                            <span>From:</span>
                            <span><?php echo date('d M Y', strtotime($row['fromdate'])) . ' at ' . date('g:i A', strtotime($row['fromtime'])); ?></span>
                        </div>
                        <div class="to act">
                            <span>To:</span>
                            <span><?php echo date('d M Y', strtotime($row['todate'])) . ' at ' . date('g:i A', strtotime($row['totime'])); ?></span>
                        </div>
                    </div>
                    <div class="status-type pcb-box">
                        <span>
                            <?php
                            $currentDateTime = date('Y-m-d H:i:s');
                            $fromDateTime = date('Y-m-d H:i:s', strtotime($row['fromdate'] . ' ' . $row['fromtime']));
                            $toDateTime = date('Y-m-d H:i:s', strtotime($row['todate'] . ' ' . $row['totime']));

                            if (!empty($row['cancdate']) && !empty($row['canctime'])) {
                                echo "Cancelled";
                            } elseif (!empty($row['checkoutdate']) && !empty($row['checkouttime'])) {
                                echo "Checked Out";
                            } elseif (!empty($row['checkindate']) && !empty($row['checkintime']) && 
                                     $currentDateTime >= date('Y-m-d H:i:s', strtotime($row['checkindate'] . ' ' . $row['checkintime'])) && 
                                     $currentDateTime <= $toDateTime) {
                                echo "Checked In";
                            } elseif ($currentDateTime >= $fromDateTime && $currentDateTime <= $toDateTime && 
                                     empty($row['checkindate']) && empty($row['checkintime']) && 
                                     empty($row['checkoutdate']) && empty($row['checkouttime']) && 
                                     empty($row['cancdate']) && empty($row['canctime'])) {
                                echo "Booked";
                            } else {
                                echo $currentDateTime < $fromDateTime ? "Upcoming" : "Expired";
                            }
                            ?>
                        </span>
                        <span>
                            <?php
                            $amount = floatval($row['amount']);
                            $paid = floatval($row['paid']);
                            if ($paid >= $amount && $amount > 0) {
                                echo "Fully Paid";
                            } elseif ($paid > 0 && $paid < $amount) {
                                echo "Partially Paid";
                            } else {
                                echo "Not Paid";
                            }
                            ?>
                        </span>
                    </div>
                    <div class="user pcb-box">
                        <span><?php echo htmlspecialchars($row['user']); ?></span>
                    </div>
                    <div class="payment-balance pcb-box">
                        <span>
                            <a href="" class="moreDetails">More Details</a>
                        </span>
                        <span><a href="" class="addPayment">Add Payment</a></span>
                        <span><a href="" class="viewPayment">View Payments</a></span>
                        <span><a href="" class="balanceView">Balance</a></span>
                    </div>
                </div>
                <div class="sub-section">
                    <div class="ss-body">
                        <div class="more ss-body-option">
                            <form action="more.php" method="POST" class="edit-sub-form">
                                <div class="form-heading"><h3>More Details</h3></div>
                                <div class="inputs">
                                    <div class="input-row">
                                        <div class="inputs"><label>Adults:</label><br><input type="number" value="<?php echo $row['adults']; ?>" readonly></div>
                                        <div class="inputs"><label>Children:</label><br><input type="number" value="<?php echo $row['children']; ?>" readonly></div>
                                        <div class="inputs"><label>Babies:</label><br><input type="number" value="<?php echo $row['babies']; ?>" readonly></div>
                                    </div>
                                    <div class="input-row">
                                        <div class="inputs"><label>Original Price:</label><br><input type="number" value="<?php echo $row['ogprice']; ?>" readonly></div>
                                        <div class="inputs"><label>Manual Price:</label><br><input type="number" value="<?php echo $row['mprice']; ?>" readonly></div>
                                        <div class="inputs">
                                            <label>Nights:</label><br>
                                            <input type="number" value="<?php echo $row['nights']; ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="input-row">
                                        <div class="inputs"><label>Description:</label><br><textarea readonly><?php echo $row['note']; ?></textarea></div>
                                    </div>
                                </div>
                                <div class="submits">
                                    <button type="button" onclick="this.closest('.more').style.display='none';"><div class="icon"></div><span>CANCEL</span></button>
                                    <button type="submit" name="update"><div class="icon"></div><span>DONE</span></button>
                                </div>
                            </form>
                        </div>
                        <div class="addpay ss-body-option">
    <form action="addpay.php" method="POST" class="edit-sub-form">
        <div class="form-heading">
            <h3>Add Payment:</h3>
        </div>
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <div class="inputs">
            <div class="input-row">
                <div class="inputs">
                    <label for="left">Amount Left:</label><br>
                    <span class="left"><?php echo number_format($row['amount'] - $row['paid']); ?></span>
                </div>
                <div class="inputs">
                    <label for="addPay">Add Payment:</label><br>
                    <input type="number" class="addPay" name="addpayment" value="0.00" step="0.01">
                </div>
            </div>
            <div class="input-row">
                <div class="inputs">
                    <label for="amountTotal">Amount:</label><br>
                    <input type="number" class="amountTotal" name="amount" value="0.00" readonly>
                </div>
            </div>

            <h3>Payment Methods</h3>

            <!-- Cash -->
            <div class="sec">
                <div class="input-label">
                    <label for="cashaccount">Cash:</label><br>
                    <div class="account-amount">
                        <select name="cashaccount" class="cashaccount">
                            <option value="" selected disabled>--Select Account--</option>
                            <?php
                                foreach ($cashaccounts as $cashaccount) {
                                    echo "<option value='{$cashaccount['id']}'>{$cashaccount['name']}</option>";
                                }
                            ?>
                        </select>
                        <input type="number" name="cashamount" class="cashamount" placeholder="CASH" step="0.01">
                    </div>
                </div>
            </div>

            <!-- Bank -->
            <div class="sec">
                <div class="input-label">
                    <label for="bankaccount">Bank:</label><br>
                    <div class="account-amount">
                        <select name="bankaccount" class="bankaccount">
                            <option value="" selected disabled>--Select Account--</option>
                            <?php
                                foreach ($bankaccounts as $bankaccount) {
                                    echo "<option value='{$bankaccount['id']}'>{$bankaccount['name']}</option>";
                                }
                            ?>
                        </select>
                        <input type="number" name="bankamount" class="bankamount" placeholder="BANK" step="0.01">
                    </div>
                </div>
            </div>

            <!-- Mobile -->
            <div class="sec">
                <div class="input-label">
                    <label for="mobileaccount">Mobile:</label><br>
                    <div class="account-amount">
                        <select name="mobileaccount" class="mobileaccount">
                            <option value="" selected disabled>--Select Account--</option>
                            <?php
                                foreach ($mobileaccounts as $mobileaccount) {
                                    echo "<option value='{$mobileaccount['id']}'>{$mobileaccount['name']}</option>";
                                }
                            ?>
                        </select>
                        <input type="number" name="mobileamount" class="mobileamount" placeholder="MOBILE" step="0.01">
                    </div>
                </div>
            </div>

            <!-- POS -->
            <div class="sec">
                <div class="input-label">
                    <label for="posaccount">POS:</label><br>
                    <div class="account-amount">
                        <select name="posaccount" class="posaccount">
                            <option value="" selected disabled>--Select Account--</option>
                            <?php
                                foreach ($posaccounts as $posaccount) {
                                    echo "<option value='{$posaccount['id']}'>{$posaccount['name']}</option>";
                                }
                            ?>
                        </select>
                        <input type="number" name="posamount" class="posamount" placeholder="POS" step="0.01">
                    </div>
                </div>
            </div>

            <!-- Total -->
            <div class="sec">
                <div class="input-label">
                    <label for="paidTotal">Total:</label><br>
                    <input type="number" name="paid" class="paidTotal" value="0.00" readonly>
                </div>
            </div>

            <!-- Change -->
            <div class="sec">
                <div class="input-label">
                    <label for="changeLeft">Change:</label><br>
                    <input type="number" class="changeLeft" value="0.00" readonly>
                </div>
            </div>

            <!-- Remaining -->
            <div class="sec">
                <div class="input-label">
                    <label for="remainLeft">Remaining:</label><br>
                    <input type="number" class="remainLeft" value="0.00" readonly>
                </div>
            </div>
        </div>

        <div class="submits">
            <button type="button" onclick="this.closest('.addpay').style.display='none';">
                <div class="icon"></div><span>CANCEL</span>
            </button>
            <button type="submit" name="addpay">
                <div class="icon"></div><span>DONE</span>
            </button>
        </div>
    </form>
</div>
                        <div class="viewpay ss-body-option">
                            <div class="form-heading"><h3>View Payments</h3></div>
                            <?php
                            $bookingId = $row['id'];
                            $bookingQuery = "SELECT code FROM bookings WHERE id = ?";
                            $bookingStmt = $conn->prepare($bookingQuery);
                            $bookingStmt->bind_param("i", $bookingId);
                            $bookingStmt->execute();
                            $bookingResult = $bookingStmt->get_result();

                            if ($bookingResult->num_rows > 0) {
                                $booking = $bookingResult->fetch_assoc();
                                $bookingCode = $booking['code'];

                                $paymentsQuery = "SELECT 
                                                    p.code as paycode,
                                                    p.dates as paydate,
                                                    p.timee as paytime,
                                                    p.amount as payamount,
                                                    a.name as accountname,
                                                    a.number as accountnumber,
                                                    pt.name as method,
                                                    u.name as user,
                                                    p.note
                                                FROM payments p
                                                JOIN accounts a ON p.accounts_id = a.id
                                                JOIN paytype pt ON p.paytype_id = pt.id
                                                JOIN user u ON p.user_id = u.id
                                                WHERE p.act_code = ?
                                                ORDER BY p.dates DESC, p.timee DESC";
                                $paymentsStmt = $conn->prepare($paymentsQuery);
                                $paymentsStmt->bind_param("s", $bookingCode);
                                $paymentsStmt->execute();
                                $paymentsResult = $paymentsStmt->get_result();

                                if ($paymentsResult->num_rows > 0) {
                                    ?>
                                    <div class="viewtable">
                                        <table>
                                            <thead>
                                                <tr>
                                                    <th>Time</th>
                                                    <th>Payment Code</th>
                                                    <th>Amount</th>
                                                    <th>Account Details</th>
                                                    <th>User</th>
                                                    <th>Description</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while ($payment = $paymentsResult->fetch_assoc()) { ?>
                                                    <tr>
                                                        <td>
                                                            <p><?php echo date('d M Y', strtotime($payment['paydate'])); ?></p>
                                                            <p><?php echo date('g:i A', strtotime($payment['paytime'])); ?></p>
                                                        </td>
                                                        <td><?php echo htmlspecialchars($payment['paycode']); ?></td>
                                                        <td><?php echo number_format($payment['payamount'], 2); ?></td>
                                                        <td>
                                                            <p><?php echo htmlspecialchars($payment['method']); ?></p>
                                                            <p><?php echo htmlspecialchars($payment['accountname']); ?></p>
                                                            <p><?php echo htmlspecialchars($payment['accountnumber']); ?></p>
                                                        </td>
                                                        <td><?php echo htmlspecialchars($payment['user']); ?></td>
                                                        <td><?php echo htmlspecialchars($payment['note']); ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php
                                } else {
                                    echo "<p>No payment records found for this booking.</p>";
                                }
                                $paymentsStmt->close();
                            } else {
                                echo "<p>Booking not found.</p>";
                            }
                            $bookingStmt->close();
                            ?>
                            <div class="submits">
                                <button type="button" onclick="this.closest('.viewpay').style.display='none';">
                                    <div class="icon"></div><span>CANCEL</span>
                                </button>
                            </div>
                        </div>
                        <div class="balance ss-body-option">
                            <form action="balance.php" method="POST" class="edit-sub-form">
                                <div class="form-heading"><h3>Balance:</h3></div>
                                <div class="viewtable">
                                    <table>
                                        <thead><tr><th>Amount</th><th>Paid</th><th>Remaining</th></tr></thead>
                                        <tbody>
                                            <tr>
                                                <td><?php echo number_format($row['amount']); ?></td>
                                                <td><?php echo number_format($row['paid']); ?></td>
                                                <td><?php echo number_format($row['amount'] - $row['paid']); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="submits">
                                    <button type="button" onclick="this.closest('.balance').style.display='none';"><div class="icon"></div><span>CANCEL</span></button>
                                    <button><div class="icon"></div><span>DONE</span></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
    } else {
        ?>
        <p>No Data Yet</p>
        <?php
    }
    $stmt->close();

    ?>
                        </div>
                    </div>

                </div>

                <!--Booked-->
                <div class="page">

                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                    Booked
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">
                            <?php
                                
                                include '../../../config.php';
                                $currentDateTime = date('Y-m-d H:i:s');
                                $currentDate = date('Y-m-d');
                                $currentTime = date('H:i:s');
                                
                                // Simplified query
                                $sqlView = "SELECT 
                                                bk.*,
                                                rt.name as rtype,
                                                rm.name as room,
                                                cu.name as customer,
                                                cu.phone as phone,
                                                cu.email as email,
                                                us.name as user,
                                                IFNULL(ag.name, '') as agent,
                                                bt.name as booktype
                                            FROM bookings bk
                                            INNER JOIN rooms rm ON bk.rooms_id = rm.id
                                            INNER JOIN rtype rt ON rm.rtype_id = rt.id
                                            INNER JOIN customer cu ON bk.customer_idno = cu.idno
                                            INNER JOIN user us ON bk.user_id = us.id
                                            LEFT JOIN agent ag ON bk.agent_id = ag.id
                                            INNER JOIN booktype bt ON bk.booktype_id = bt.id
                                            WHERE bk.company_id = '$company'
                                              AND bk.todate >= '$currentDate'
                                            --   AND bk.totime >= '$currentTime'
                                              AND bk.checkindate IS NULL
                                              AND bk.checkoutdate IS NULL
                                              AND bk.cancdate IS NULL
                                            ORDER BY bk.fromdate ASC, bk.fromtime ASC";
                                
                                $result = $conn->query($sqlView);

                            if ($result->num_rows > 0){
                                while ($row = $result->fetch_assoc()){
                                    ?>
                                    <div class="pcb-boxes">
                                        <div class="flex">
                                            <div class="act-details pcb-box">
                                                <div class="code">
                                                    <?php echo $row['code']?>
                                                </div>
                                                <div class="date">
                                                    <?php echo date('d M Y', strtotime($row['dates'])); ?>
                                                </div>
                                                <div class="time">
                                                    <?php echo date('g:i A', strtotime($row['timee'])); ?>
                                                </div>
                                            </div>
                                            <div class="room-rt pcb-box">
                                                <div class="rt">
                                                    <?php echo $row['rtype']?>
                                                </div>
                                                <span><?php echo $row['room']?></span>
                                            </div>
                                            <div class="customer pcb-box">
                                                <span><?php echo $row['customer']?></span>
                                                <span><?php echo $row['phone']?></span>
                                                <span><?php echo $row['email']?></span>
                                            </div>
        
                                            <div class="duration pcb-box">
                                                <div class="from act">
                                                    <span>Expected Arrival:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['fromdate'])); ?> at <?php echo date('g:i A', strtotime($row['fromtime'])); ?></span>
                                                </div>
                                                <div class="to act">
                                                    <span>Expected Departure:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['todate'])); ?> at <?php echo date('g:i A', strtotime($row['totime'])); ?></span>
                                                </div>
                                            </div>

                                            <div class="type pcb-box">
                                                <div class="act">
                                                    <span>Booking Type:</span>
                                                    <span> <?php echo $row['booktype']?></span>
                                                </div>
                                                <div class="act">
                                                    <?php if ($row['booktype'] == 'Agent'): ?>
                                                    <span>Agent:</span>
                                                    <span><?php echo $row['agent']?></span>
                                                    <?php elseif ($row['booktype'] == 'In-House'): ?>
                                                    <span>User:</span>
                                                    <span><?php echo $row['user']?></span>
                                                    <?php else: ?>
                                                    <span>Handled by:</span>
                                                    <span> <?php echo !empty($row['agent']) ? $row['agent'] : $row['user']?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            
                                            <div class="payment-balance pcb-box">
                                                <span>
                                                    <a href="" class="checkinNow">Check-In</a>
                                                </span>
                                                <span>
                                                    <a href="" class="cancelNow">Cancel</a>
                                                </span>
                                                <span id="exportView">
                                                    <a href="invoice.php?code=<?php echo urlencode($row['code']); ?>" target="_blank" class="download">Download Invoice</a>
                                                </span>
                                                
                                            </div>
            
            
                                        </div>
                                                        <!-- In your main page that displays rooms, modify the edit form like this: -->
<div class="sub-section">
    <div class="ss-body">
        <div class="checkin ss-body-option">
            <form action="checkin.php" method="POST" class="edit-sub-form">
                <div class="form-heading">
                    <h3>Check-In into Room</h3>
                </div>
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div class="inputs">
                    <div class="input-row">
                        <div class="inputs from">
                            <label for="code">Check-in Time:<span>*</span></label><br>
                            <div class="date-time">
                                <input type="date" id="checkindate" name="checkindate" value="<?php echo $currentDate?>">
                                <input type="time" id="checkintime" name="checkintime" value="<?php echo $currentTime?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="submits">
                    <button type="button" onclick="this.closest('.checkin').style.display='none';">
                        <div class="icon"></div><span>CANCEL</span>
                    </button>
                    <button type="submit" name="checkin">
                        <div class="icon"></div><span>DONE</span>
                    </button>
                </div>
            </form>
        </div>
        <div class="cancel ss-body-option">
            <form action="cancel.php" method="POST" class="edit-sub-form">
                <div class="form-heading">
                    <h3>Cancel Reservation</h3>
                </div>
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div class="inputs">
                    <div class="input-row">
                        <div class="inputs">
                            <label for="code">Cancel Time:<span>*</span></label><br>
                            <div class="date-time">
                                <input type="date" id="cancdate" name="cancdate" value="<?php echo $currentDate?>">
                                <input type="time" id="canctime" name="canctime" value="<?php echo $currentTime?>">
                            </div>
                        </div>
                    </div>


                </div>
                <div class="submits">
                    <button type="button" onclick="this.closest('.cancel').style.display='none';">
                        <div class="icon"></div><span>CANCEL</span>
                    </button>
                    <button type="submit" name="cancel">
                        <div class="icon"></div><span>DONE</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
                                    </div>
                                    <?php
                                }
                            }?>

                        </div>
                    </div>
                </div>

                <!--Checked In-->
                <div class="page">

                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                    Checked In
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">
                            <?php
                                
                                include '../../../config.php';
                                $currentDateTime = date('Y-m-d H:i:s');
                                $currentDate = date('Y-m-d');
                                $currentTime = date('H:i:s');
                                
                                // Simplified query
                                $sqlView = "SELECT 
                                                bk.*,
                                                rt.name as rtype,
                                                rm.name as room,
                                                cu.name as customer,
                                                cu.phone as phone,
                                                cu.email as email,
                                                us.name as user,
                                                IFNULL(ag.name, '') as agent,
                                                bt.name as booktype
                                            FROM bookings bk
                                            INNER JOIN rooms rm ON bk.rooms_id = rm.id
                                            INNER JOIN rtype rt ON rm.rtype_id = rt.id
                                            INNER JOIN customer cu ON bk.customer_idno = cu.idno
                                            INNER JOIN user us ON bk.user_id = us.id
                                            LEFT JOIN agent ag ON bk.agent_id = ag.id
                                            INNER JOIN booktype bt ON bk.booktype_id = bt.id
                                            WHERE bk.company_id = '$company'
                                              AND bk.checkindate <= '$currentDate'
                                              AND bk.checkintime <= '$currentTime'
                                              AND bk.checkoutdate IS NULL
                                              AND bk.cancdate IS NULL
                                            ORDER BY bk.todate ASC, bk.totime ASC";
                                
                                $result = $conn->query($sqlView);

                            if ($result->num_rows > 0){
                                while ($row = $result->fetch_assoc()){
                                    ?>
                                    <div class="pcb-boxes">
                                        <div class="flex">
                                            <div class="act-details pcb-box">
                                                <div class="code">
                                                    <?php echo $row['code']?>
                                                </div>
                                                <div class="date">
                                                    <?php echo date('d M Y', strtotime($row['dates'])); ?>
                                                </div>
                                                <div class="time">
                                                    <?php echo date('g:i A', strtotime($row['timee'])); ?>
                                                </div>
                                            </div>
                                            <div class="room-rt pcb-box">
                                                <div class="rt">
                                                    <?php echo $row['rtype']?>
                                                </div>
                                                <span><?php echo $row['room']?></span>
                                            </div>

                                            <div class="customer pcb-box">
                                                <span><?php echo $row['customer']?></span>
                                                <span><?php echo $row['phone']?></span>
                                                <span><?php echo $row['email']?></span>
                                            </div>
        
                                            <div class="duration pcb-box">
                                                <div class="from act">
                                                    <span>Expected Arrival:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['fromdate'])); ?> at <?php echo date('g:i A', strtotime($row['fromtime'])); ?></span>
                                                </div>
                                                <div class="to act">
                                                    <span>Arrived at:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['checkindate'])); ?> at <?php echo date('g:i A', strtotime($row['checkintime'])); ?></span>
                                                </div>
                                            </div>
        
                                            <div class="duration pcb-box">
                                                <div class="from act">
                                                    <span>Expected Departure:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['todate'])); ?> at <?php echo date('g:i A', strtotime($row['totime'])); ?></span>
                                                </div>
                                            </div>
                                            
                                            <div class="payment-balance  pcb-box">
                                                <span>
                                                    <a href="" class="checkoutNow">Check-Out</a>
                                                </span>
                                            </div>
            
            
                                        </div>
<div class="sub-section">
    <div class="ss-body">
        <div class="checkout ss-body-option">
            <form action="checkout.php" method="POST" class="edit-sub-form">
                <div class="form-heading">
                    <h3>Check-Out From Room</h3>
                </div>
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div class="inputs">
                    <div class="input-row">
                        <div class="inputs from">
                            <label for="code">Check-out Time:<span>*</span></label><br>
                            <div class="date-time">
                                <input type="date" id="checkoutdate" name="checkoutdate" value="<?php echo $currentDate?>">
                                <input type="time" id="checkouttime" name="checkouttime" value="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="submits">
                    <button type="button" onclick="this.closest('.checkout').style.display='none';">
                        <div class="icon"></div><span>CANCEL</span>
                    </button>
                    <button type="submit" name="checkout">
                        <div class="icon"></div><span>DONE</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
                                    </div>
                                    <?php
                                }
                            }?>

                        </div>
                    </div>
                </div>

                <!--Checked Out-->
                <div class="page">

                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                    Checked Out
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">
                            <?php
                                
                                include '../../../config.php';
                                $currentDateTime = date('Y-m-d H:i:s');
                                $currentDate = date('Y-m-d');
                                
                                // Simplified query
                                $sqlView = "SELECT 
                                                bk.*,
                                                rt.name as rtype,
                                                rm.name as room,
                                                cu.name as customer,
                                                cu.phone as phone,
                                                cu.email as email,
                                                us.name as user,
                                                IFNULL(ag.name, '') as agent,
                                                bt.name as booktype
                                            FROM bookings bk
                                            INNER JOIN rooms rm ON bk.rooms_id = rm.id
                                            INNER JOIN rtype rt ON rm.rtype_id = rt.id
                                            INNER JOIN customer cu ON bk.customer_idno = cu.idno
                                            INNER JOIN user us ON bk.user_id = us.id
                                            LEFT JOIN agent ag ON bk.agent_id = ag.id
                                            INNER JOIN booktype bt ON bk.booktype_id = bt.id
                                            WHERE bk.company_id = '$company'
                                              AND bk.checkoutdate IS NOT NULL
                                              AND bk.cancdate IS NULL
                                            ORDER BY bk.checkoutdate DESC, bk.checkouttime DESC";
                                
                                $result = $conn->query($sqlView);

                            if ($result->num_rows > 0){
                                while ($row = $result->fetch_assoc()){
                                    ?>
                                    <div class="pcb-boxes">
                                        <div class="flex">
                                            <div class="act-details pcb-box">
                                                <div class="code">
                                                    <?php echo $row['code']?>
                                                </div>
                                                <div class="date">
                                                    <?php echo date('d M Y', strtotime($row['dates'])); ?>
                                                </div>
                                                <div class="time">
                                                    <?php echo date('g:i A', strtotime($row['timee'])); ?>
                                                </div>
                                            </div>
                                            <div class="room-rt pcb-box">
                                                <div class="rt">
                                                    <?php echo $row['rtype']?>
                                                </div>
                                                <span><?php echo $row['room']?></span>
                                            </div>

                                            <div class="customer pcb-box">
                                                <span><?php echo $row['customer']?></span>
                                                <span><?php echo $row['phone']?></span>
                                                <span><?php echo $row['email']?></span>
                                            </div>
        
                                            <div class="duration pcb-box">
                                                <div class="from act">
                                                    <span>Expected Arrival:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['fromdate'])); ?> at <?php echo date('g:i A', strtotime($row['fromtime'])); ?></span>
                                                </div>
                                                <div class="to act">
                                                    <span>Arrived at:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['checkindate'])); ?> at <?php echo date('g:i A', strtotime($row['checkintime'])); ?></span>
                                                </div>
                                            </div>
        
                                            <div class="duration pcb-box">
                                                <div class="from act">
                                                    <span>Expected Departure:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['todate'])); ?> at <?php echo date('g:i A', strtotime($row['totime'])); ?></span>
                                                </div>
                                                <div class="to act">
                                                    <span>Departed at:</span>
                                                    <span><?php echo date('d M Y', strtotime($row['checkoutdate'])); ?> at <?php echo date('g:i A', strtotime($row['checkouttime'])); ?></span>
                                                </div>
                                            </div>
                                            
                                            <!-- <div class="payments-balance pcb-box">
                                                <span>
                                                    <a href="">Balance</a>
                                                </span>
                                            </div> -->
            
            
                                        </div>
                                    </div>
                                    <?php
                                }
                            }?>

                        </div>
                    </div>
                </div>

                <!--Cancelled-->
                <div class="page">

                    <div class="page-content-body">
                        <div class="pcb-heading">
                            <div class="flex">
                                <div class="title">
                                    Cancelled
                                </div>
                                <div class="search-box">
                                    <input type="text" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                        <div class="pcb-content">
                            <?php

                                include '../../../config.php';
                                $currentDateTime = date('Y-m-d H:i:s');
                                $currentDate = date('Y-m-d');
                                $currentTime = date('H:i:s');
                                
                                // Simplified query
                                $sqlView = "SELECT 
                                                bk.*,
                                                rt.name as rtype,
                                                rm.name as room,
                                                cu.name as customer,
                                                cu.phone as phone,
                                                cu.email as email,
                                                us.name as user,
                                                IFNULL(ag.name, '') as agent,
                                                bt.name as booktype
                                            FROM bookings bk
                                            INNER JOIN rooms rm ON bk.rooms_id = rm.id
                                            INNER JOIN rtype rt ON rm.rtype_id = rt.id
                                            INNER JOIN customer cu ON bk.customer_idno = cu.idno
                                            INNER JOIN user us ON bk.user_id = us.id
                                            LEFT JOIN agent ag ON bk.agent_id = ag.id
                                            INNER JOIN booktype bt ON bk.booktype_id = bt.id
                                            WHERE bk.company_id = '$company'
                                              AND bk.checkindate IS NULL
                                              AND bk.checkoutdate IS NULL
                                              AND bk.cancdate IS NOT NULL
                                              AND bk.canctime IS NOT NULL
                                            ORDER BY bk.cancdate DESC, bk.canctime DESC, bk.id DESC";
                                
                                $result = $conn->query($sqlView);
                                if ($result->num_rows > 0){
                                    while ($row = $result->fetch_assoc()){
                                        ?>
                                        <div class="pcb-boxes">
                                            <div class="flex">
                                                <div class="act-details pcb-box">
                                                    <div class="code">
                                                        <?php echo $row['code']?>
                                                    </div>
                                                    <div class="date">
                                                        <?php echo date('d M Y', strtotime($row['dates'])); ?>
                                                    </div>
                                                    <div class="time">
                                                        <?php echo date('g:i A', strtotime($row['timee'])); ?>
                                                    </div>
                                                </div>
                                                <div class="room-rt pcb-box">
                                                    <div class="rt">
                                                        <?php echo $row['rtype']?>
                                                    </div>
                                                    <span><?php echo $row['room']?></span>
                                                </div>

                                                <div class="customer pcb-box">
                                                    <span><?php echo $row['customer']?></span>
                                                    <span><?php echo $row['phone']?></span>
                                                    <span><?php echo $row['email']?></span>
                                                </div>
            
                                                <div class="duration pcb-box">
                                                    <div class="from act">
                                                        <span>Expected Arrival:</span>
                                                        <span><?php echo date('d M Y', strtotime($row['fromdate'])); ?> at <?php echo date('g:i A', strtotime($row['fromtime'])); ?></span>
                                                    </div>
                                                    <div class="to act">
                                                        <span>Expected Departure:</span>
                                                        <span><?php echo date('d M Y', strtotime($row['todate'])); ?> at <?php echo date('g:i A', strtotime($row['totime'])); ?></span>
                                                    </div>
                                                </div>
            
                                                <div class="amount-cancel pcb-box">
                                                    <span class="amount"><?php echo number_format($row['amount'], 2)  ?></span>
                                                    <div class="act">
                                                        <span>Cancelled on:</span>
                                                        <span><?php echo date('d M Y', strtotime($row['cancdate'])); ?> at <?php echo date('g:i A', strtotime($row['canctime'])); ?></span>
                                                    </div>
                                                </div>
                                                
                                                <!-- <div class="payments-balance pcb-box">
                                                    <span>
                                                        <a href="">Add Refund</a>
                                                        <a href="">View Refunds</a>
                                                    </span>
                                                </div> -->
                
                
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }?>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <?php
        include '../../../assets/components/root/js.php';
    ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
    // Store all data for both sections (unchanged)
    const allRooms = <?php echo json_encode($rooms); ?>;
    const bookings = <?php echo json_encode($bookings); ?>;
    const housekeepings = <?php echo json_encode($housekeepings); ?>;
    const customers = <?php echo json_encode($customers); ?>;

    console.log("Rooms data type:", typeof allRooms, "length:", allRooms.length);
    console.log("Bookings data type:", typeof bookings, "length:", bookings.length);
    console.log("Housekeepings data type:", typeof housekeepings, "length:", housekeepings.length);
    console.log("Customers data type:", typeof customers, "length:", customers.length);

    // --- JavaScript for "New Booking" (register) Section ---
    // (Unchanged, keeping your original register section logic)
    const rtypeSelect = document.querySelector('select[name="rtype"]');
    const roomSelect = document.querySelector('select[name="room"]');
    const customerSelect = document.getElementById('customer');
    const fromDateInput = document.getElementById('fromdate');
    const fromTimeInput = document.getElementById('fromtime');
    const toDateInput = document.getElementById('todate');
    const toTimeInput = document.getElementById('totime');
    const fnameInput = document.getElementById('fname');
    const lnameInput = document.getElementById('lname');
    const languageSelect = document.getElementById('language');
    const idtypeSelect = document.getElementById('idtype');
    const idnoInput = document.getElementById('idno');
    const phoneInput = document.getElementById('phone');
    const emailInput = document.getElementById('email');
    const cityInput = document.getElementById('city');
    const stateInput = document.getElementById('state');
    const countryInput = document.getElementById('country');
    if (roomSelect) roomSelect.disabled = true;

    function createDateTime(dateStr, timeStr) {
        if (!dateStr || !timeStr) return null;
        if (!timeStr.includes(':')) timeStr = timeStr + ':00';
        try {
            const dt = new Date(`${dateStr}T${timeStr}`);
            return isNaN(dt.getTime()) ? null : dt;
        } catch (e) {
            console.error("Error creating date:", e);
            return null;
        }
    }

    function logBookingOverlap(roomId, newStart, newEnd, bookingStart, bookingEnd) {
        console.log(`Room ${roomId} - Checking overlap:`, {
            'New booking': { 'from': newStart.toISOString(), 'to': newEnd.toISOString() },
            'Existing booking': { 'from': bookingStart.toISOString(), 'to': bookingEnd.toISOString() },
            'Overlap?': (newStart < bookingEnd && newEnd > bookingStart)
        });
    }

    function isRoomAvailable(roomId, fromDate, fromTime, toDate, toTime) {
        const newBookingStart = createDateTime(fromDate, fromTime);
        const newBookingEnd = createDateTime(toDate, toTime);
        if (!newBookingStart || !newBookingEnd) {
            console.log(`Invalid date input for room ${roomId}`);
            return false;
        }
        for (const booking of bookings) {
            if (booking.rooms_id == roomId) {
                let bookingEnd, bookingStart;
                if (booking.cancdate && booking.canctime) {
                    bookingEnd = createDateTime(booking.cancdate, booking.canctime);
                } else if (booking.checkoutdate && booking.checkoutime) {
                    bookingEnd = createDateTime(booking.checkoutdate, booking.checkoutime);
                } else {
                    bookingEnd = createDateTime(booking.todate, booking.totime);
                }
                bookingStart = createDateTime(booking.fromdate, booking.fromtime);
                if (!bookingStart || !bookingEnd) continue;
                const hasOverlap = newBookingStart < bookingEnd && newBookingEnd > bookingStart;
                logBookingOverlap(roomId, newBookingStart, newBookingEnd, bookingStart, bookingEnd);
                if (hasOverlap) {
                    console.log(`Room ${roomId} is booked during requested time`);
                    return false;
                }
            }
        }
        for (const hk of housekeepings) {
            if (hk.rooms_id == roomId) {
                const hkStart = createDateTime(hk.fromdate, hk.fromtime);
                const hkEnd = createDateTime(hk.todate, hk.totime);
                if (!hkStart || !hkEnd) continue;
                if (newBookingStart < hkEnd && newBookingEnd > hkStart) {
                    console.log(`Room ${roomId} is under housekeeping during requested time`);
                    return false;
                }
            }
        }
        let needsCleaning = false;
        let lastCheckout = null;
        for (const booking of bookings) {
            if (booking.rooms_id == roomId && booking.checkoutdate && booking.checkoutime) {
                const checkoutTime = createDateTime(booking.checkoutdate, booking.checkoutime);
                if (!checkoutTime) continue;
                if (checkoutTime < newBookingStart && (!lastCheckout || checkoutTime > lastCheckout)) {
                    lastCheckout = checkoutTime;
                }
            }
        }
        if (lastCheckout) {
            let wasCleanedAfterCheckout = false;
            for (const hk of housekeepings) {
                if (hk.rooms_id == roomId) {
                    const hkEnd = createDateTime(hk.todate, hk.totime);
                    if (!hkEnd) continue;
                    if (hkEnd > lastCheckout && hkEnd <= newBookingStart) {
                        wasCleanedAfterCheckout = true;
                        break;
                    }
                }
            }
            if (!wasCleanedAfterCheckout) {
                console.log(`Room ${roomId} needs cleaning after checkout`);
                return false;
            }
        }
        console.log(`Room ${roomId} is available`);
        return true;
    }

    function updateRoomOptions() {
        const selectedRtypeId = rtypeSelect.value;
        const fromDate = fromDateInput.value;
        const fromTime = fromTimeInput.value;
        const toDate = toDateInput.value;
        const toTime = toTimeInput.value;
        console.log("Checking availability for:", { roomType: selectedRtypeId, from: `${fromDate} ${fromTime}`, to: `${toDate} ${toTime}` });
        while (roomSelect.options.length > 1) {
            roomSelect.remove(1);
        }
        if (selectedRtypeId && fromDate && fromTime && toDate && toTime) {
            const filteredRooms = allRooms.filter(room => {
                const available = room.rtype_id == selectedRtypeId && isRoomAvailable(room.id, fromDate, fromTime, toDate, toTime);
                console.log(`Room ${room.id} (${room.name}) availability: ${available}`);
                return available;
            });
            console.log(`Found ${filteredRooms.length} available rooms`);
            filteredRooms.forEach(room => {
                const option = document.createElement('option');
                option.value = room.id;
                option.textContent = room.name;
                roomSelect.appendChild(option);
            });
            roomSelect.disabled = filteredRooms.length === 0;
            if (filteredRooms.length === 0) {
                const option = document.createElement('option');
                option.value = "";
                option.textContent = "No available rooms for selected period";
                option.disabled = true;
                roomSelect.appendChild(option);
            }
        } else {
            roomSelect.disabled = true;
        }
    }

    function updateCustomerDetails() {
        const selectedCustomerId = customerSelect.value;
        if (selectedCustomerId) {
            const selectedCustomer = customers.find(customer => customer.id == selectedCustomerId);
            if (selectedCustomer) {
                fnameInput.value = selectedCustomer.fname || "";
                lnameInput.value = selectedCustomer.lname || "";
                languageSelect.value = selectedCustomer.languages_id || "";
                idtypeSelect.value = selectedCustomer.idtype_id || "";
                idnoInput.value = selectedCustomer.idno || "";
                phoneInput.value = selectedCustomer.phone || "";
                emailInput.value = selectedCustomer.email || "";
                cityInput.value = selectedCustomer.city || "";
                stateInput.value = selectedCustomer.state || "";
                countryInput.value = selectedCustomer.country || "";
                console.log(`Updated details for customer ${selectedCustomer.name}`);
            } else {
                console.log("Selected customer not found in data");
            }
        } else {
            fnameInput.value = "";
            lnameInput.value = "";
            languageSelect.value = "";
            idtypeSelect.value = "";
            idnoInput.value = "";
            phoneInput.value = "";
            emailInput.value = "";
            cityInput.value = "";
            stateInput.value = "";
            countryInput.value = "";
            console.log("No customer selected, cleared fields");
        }
    }

    const ogPriceInput = document.getElementById('ogprice');
    const mPriceInput = document.getElementById('mprice');

    function updatePriceFields() {
        const selectedRoomId = roomSelect.value;
        if (selectedRoomId) {
            const selectedRoom = allRooms.find(room => room.id == selectedRoomId);
            if (selectedRoom && selectedRoom.uprice) {
                const price = parseFloat(selectedRoom.uprice).toFixed(2);
                ogPriceInput.value = price;
                mPriceInput.value = price;
                ogPriceInput.readOnly = true;
                console.log(`Updated prices for room ${selectedRoom.name}: $${price}`);
                updateRegisterTotals();
            } else {
                ogPriceInput.value = "0.00";
                mPriceInput.value = "0.00";
                updateRegisterTotals();
                console.log("No valid price found for selected room");
            }
        } else {
            ogPriceInput.value = "0.00";
            mPriceInput.value = "0.00";
            updateRegisterTotals();
        }
    }

    const manualPrice = document.getElementById('mprice');
    const otherPay = document.getElementById('otherpay');
    const discount = document.getElementById('discount');
    const subtotal = document.getElementById('subtotal');
    const newSubtotal = document.getElementById('newsubtotal');
    const vatPercent = document.getElementById('vatpercent');
    const vat = document.getElementById('vat');
    const amount = document.getElementById('amount');
    const cashAccountRegister = document.getElementById('cashaccount');
    const cashAmountRegister = document.getElementById('cashamount');
    const bankAccountRegister = document.getElementById('bankaccount');
    const bankAmountRegister = document.getElementById('bankamount');
    const mobileAccountRegister = document.getElementById('mobileaccount');
    const mobileAmountRegister = document.getElementById('mobileamount');
    const posAccountRegister = document.getElementById('posaccount');
    const posAmountRegister = document.getElementById('posamount');
    const totalAmountRegister = document.getElementById('totalamount');
    const changeRegister = document.getElementById('change');
    const remainRegister = document.getElementById('remain');

    if (cashAmountRegister) cashAmountRegister.disabled = true;
    if (bankAmountRegister) bankAmountRegister.disabled = true;
    if (mobileAmountRegister) mobileAmountRegister.disabled = true;
    if (posAmountRegister) posAmountRegister.disabled = true;

    function calculateNights(fromDate, fromTime, toDate, toTime) {
        const fromDateTime = createDateTime(fromDate, fromTime);
        const toDateTime = createDateTime(toDate, toTime);
        if (!fromDateTime || !toDateTime || toDateTime <= fromDateTime) return 0;
        const NIGHT_CUTOFF_HOUR = 10;
        const NIGHT_CUTOFF_MINUTE = 0;
        let nights = 1;
        let currentCutoff = new Date(fromDateTime);
        currentCutoff.setDate(currentCutoff.getDate() + (currentCutoff.getHours() >= NIGHT_CUTOFF_HOUR ? 1 : 0));
        currentCutoff.setHours(NIGHT_CUTOFF_HOUR, NIGHT_CUTOFF_MINUTE, 0, 0);
        while (currentCutoff < toDateTime) {
            nights++;
            currentCutoff.setDate(currentCutoff.getDate() + 1);
        }
        const lastCutoff = new Date(currentCutoff);
        lastCutoff.setDate(lastCutoff.getDate() - 1);
        if (toDateTime <= lastCutoff) nights--;
        return Math.max(nights, 1);
    }

    function toggleAmountInputRegister(selectElement, amountInput) {
        amountInput.disabled = !selectElement.value;
        if (!selectElement.value) {
            amountInput.value = "";
            updateRegisterTotals();
        }
    }

    function updateRegisterTotals() {
        const fromDate = fromDateInput.value;
        const fromTime = fromTimeInput.value;
        const toDate = toDateInput.value;
        const toTime = toTimeInput.value;
        const nightsValue = calculateNights(fromDate, fromTime, toDate, toTime);
        const nightsInput = document.getElementById('nights');
        nightsInput.value = nightsValue;
        const mPriceValue = parseFloat(manualPrice.value) || 0;
        const otherPayValue = parseFloat(otherPay.value) || 0;
        const discountValue = parseFloat(discount.value) || 0;
        const vatPercentValue = parseFloat(vatPercent.value) || 0;
        const priceNightsValue = mPriceValue * nightsValue;
        const priceNightsInput = document.getElementById('pricenights');
        priceNightsInput.value = priceNightsValue.toFixed(2);
        const subtotalValue = priceNightsValue + otherPayValue;
        subtotal.value = subtotalValue.toFixed(2);
        const newSubtotalValue = Math.max(subtotalValue - discountValue, 0);
        newSubtotal.value = newSubtotalValue.toFixed(2);
        const vatValue = (newSubtotalValue * vatPercentValue) / 100;
        vat.value = vatValue.toFixed(2);
        const amountValue = newSubtotalValue + vatValue;
        amount.value = amountValue.toFixed(2);
        const cashValue = cashAmountRegister.disabled ? 0 : (parseFloat(cashAmountRegister.value) || 0);
        const bankValue = bankAmountRegister.disabled ? 0 : (parseFloat(bankAmountRegister.value) || 0);
        const mobileValue = mobileAmountRegister.disabled ? 0 : (parseFloat(mobileAmountRegister.value) || 0);
        const posValue = posAmountRegister.disabled ? 0 : (parseFloat(posAmountRegister.value) || 0);
        const totalPaymentValue = cashValue + bankValue + mobileValue + posValue;
        totalAmountRegister.value = totalPaymentValue.toFixed(2);
        if (totalPaymentValue > amountValue) {
            const changeValue = totalPaymentValue - amountValue;
            changeRegister.value = changeValue.toFixed(2);
            remainRegister.value = "0.00";
        } else if (amountValue > totalPaymentValue) {
            const remainValue = amountValue - totalPaymentValue;
            remainRegister.value = remainValue.toFixed(2);
            changeRegister.value = "0.00";
        } else {
            changeRegister.value = "0.00";
            remainRegister.value = "0.00";
        }
    }

    if (rtypeSelect) rtypeSelect.addEventListener('change', () => { updateRoomOptions(); updatePriceFields(); });
    if (fromDateInput) fromDateInput.addEventListener('change', () => { updateRoomOptions(); updatePriceFields(); updateRegisterTotals(); });
    if (fromTimeInput) fromTimeInput.addEventListener('change', () => { updateRoomOptions(); updatePriceFields(); updateRegisterTotals(); });
    if (toDateInput) toDateInput.addEventListener('change', () => { updateRoomOptions(); updatePriceFields(); updateRegisterTotals(); });
    if (toTimeInput) toTimeInput.addEventListener('change', () => { updateRoomOptions(); updatePriceFields(); updateRegisterTotals(); });
    if (roomSelect) roomSelect.addEventListener('change', updatePriceFields);
    if (customerSelect) customerSelect.addEventListener('change', updateCustomerDetails);
    if (manualPrice) manualPrice.addEventListener('input', updateRegisterTotals);
    if (otherPay) otherPay.addEventListener('input', updateRegisterTotals);
    if (discount) discount.addEventListener('input', updateRegisterTotals);
    if (vatPercent) vatPercent.addEventListener('input', updateRegisterTotals);
    if (cashAmountRegister) cashAmountRegister.addEventListener('input', updateRegisterTotals);
    if (bankAmountRegister) bankAmountRegister.addEventListener('input', updateRegisterTotals);
    if (mobileAmountRegister) mobileAmountRegister.addEventListener('input', updateRegisterTotals);
    if (posAmountRegister) posAmountRegister.addEventListener('input', updateRegisterTotals);
    if (cashAccountRegister) cashAccountRegister.addEventListener('change', () => toggleAmountInputRegister(cashAccountRegister, cashAmountRegister));
    if (bankAccountRegister) bankAccountRegister.addEventListener('change', () => toggleAmountInputRegister(bankAccountRegister, bankAmountRegister));
    if (mobileAccountRegister) mobileAccountRegister.addEventListener('change', () => toggleAmountInputRegister(mobileAccountRegister, mobileAmountRegister));
    if (posAccountRegister) posAccountRegister.addEventListener('change', () => toggleAmountInputRegister(posAccountRegister, posAmountRegister));
    updateRegisterTotals();

    // --- JavaScript for "Add Payment" (addpay) Section ---

    // Function to parse amount from formatted string (shared)
    function parseAmount(amountStr) {
        if (!amountStr) return 0;
        return parseFloat(amountStr.toString().replace(/,/g, '')) || 0;
    }

    // Function to initialize a single addpay form
    function initializeAddpayForm(form) {
        // Get elements within this specific form
        const addPayInput = form.querySelector('.addPay');
        const amountTotalInput = form.querySelector('.amountTotal');
        const leftSpan = form.querySelector('.left');
        const cashAmountInput = form.querySelector('.cashamount');
        const bankAmountInput = form.querySelector('.bankamount');
        const mobileAmountInput = form.querySelector('.mobileamount');
        const posAmountInput = form.querySelector('.posamount');
        const paidTotalInput = form.querySelector('.paidTotal');
        const changeLeftInput = form.querySelector('.changeLeft');
        const remainLeftInput = form.querySelector('.remainLeft');
        const cashAccountSelect = form.querySelector('.cashaccount');
        const bankAccountSelect = form.querySelector('.bankaccount');
        const mobileAccountSelect = form.querySelector('.mobileaccount');
        const posAccountSelect = form.querySelector('.posaccount');

        // Ensure all required elements exist
        if (!addPayInput || !amountTotalInput || !leftSpan || !paidTotalInput) {
            console.log("Missing required elements in an addpay form:", form);
            return;
        }

        // Function to toggle amount input based on account selection
        function toggleAmountInput(selectElement, amountInput) {
            const hasValue = !!selectElement.value;
            amountInput.disabled = !hasValue;
            if (!hasValue) {
                amountInput.value = "";
            }
            console.log(`Toggling ${amountInput.className} in form: disabled=${amountInput.disabled}, selectValue=${selectElement.value}`);
            updateTotals();
        }

        // Function to update the amount field (amount left + add payment)
        function updateAmount() {
            const leftAmount = parseAmount(leftSpan.textContent);
            const addPayment = parseAmount(addPayInput.value);
            const totalAmount = leftAmount + addPayment;
            amountTotalInput.value = totalAmount.toFixed(2);
            updateTotals();
        }

        // Function to update payment totals, change, and remaining balance
        function updateTotals() {
            const cashAmount = cashAmountInput.disabled ? 0 : parseAmount(cashAmountInput.value);
            const bankAmount = bankAmountInput.disabled ? 0 : parseAmount(bankAmountInput.value);
            const mobileAmount = mobileAmountInput.disabled ? 0 : parseAmount(mobileAmountInput.value);
            const posAmount = posAmountInput.disabled ? 0 : parseAmount(posAmountInput.value);

            const totalPayments = cashAmount + bankAmount + mobileAmount + posAmount;
            paidTotalInput.value = totalPayments.toFixed(2);

            const amountRequired = parseAmount(amountTotalInput.value);

            if (totalPayments > amountRequired) {
                changeLeftInput.value = (totalPayments - amountRequired).toFixed(2);
                remainLeftInput.value = "0.00";
            } else {
                remainLeftInput.value = (amountRequired - totalPayments).toFixed(2);
                changeLeftInput.value = "0.00";
            }

            console.log("Add Payment Totals for form:", {
                formId: form.querySelector('input[name="id"]').value,
                cash: cashAmount,
                bank: bankAmount,
                mobile: mobileAmount,
                pos: posAmount,
                total: totalPayments,
                amountRequired: amountRequired
            });
        }

        // Set up event listeners for this form
        addPayInput.addEventListener('input', updateAmount);
        cashAmountInput.addEventListener('input', updateTotals);
        bankAmountInput.addEventListener('input', updateTotals);
        mobileAmountInput.addEventListener('input', updateTotals);
        posAmountInput.addEventListener('input', updateTotals);

        cashAccountSelect.addEventListener('change', () => toggleAmountInput(cashAccountSelect, cashAmountInput));
        bankAccountSelect.addEventListener('change', () => toggleAmountInput(bankAccountSelect, bankAmountInput));
        mobileAccountSelect.addEventListener('change', () => toggleAmountInput(mobileAccountSelect, mobileAmountInput));
        posAccountSelect.addEventListener('change', () => toggleAmountInput(posAccountSelect, posAmountInput));

        // Initialize calculations
        updateAmount();
        updateTotals();
    }

    // Find all addpay forms and initialize them
    const addpayForms = document.querySelectorAll('.addpay .edit-sub-form');
    if (addpayForms.length > 0) {
        addpayForms.forEach(form => {
            console.log("Initializing addpay form for booking ID:", form.querySelector('input[name="id"]').value);
            initializeAddpayForm(form);
        });
    } else {
        console.log("No addpay forms found on this page.");
    }
});
    </script>

</body>
</html>

<!--
table: bookings            
columns: id, 
         code, 
         dates, 
         timee, 
         fromdate, 
         fromtime, 
         checkindate, 
         checkintime,
         checkoutdate,
         checkouttime,
         cancdate,
         canctime,
         todate,
         totime,
         rooms_id,
         ogprice,
         mprice,
         nights,
         adults,
         children,
         babies,
         note,
         customer_idno,
         discount,
         amount,
         paid,
         refund,
         vat,
         vatpercent,
         company_id,
         user_id



table: house_keeping
columns: id,
         code,
         dates,
         timee,
         rooms_id,
         hktype_id,
         fromdate,
         fromtime,
         todate,
         totime,
         note,
         company_id,
         user_id
-->