<?php

$sql = "SELECT *
        FROM user
        WHERE id = '$user'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$code = $row['code'];
$name = $row['name'];
$note = $row['note'];

$passcode = $row['passcode'];

$phone = $row['phone'];
$email = $row['email'];
