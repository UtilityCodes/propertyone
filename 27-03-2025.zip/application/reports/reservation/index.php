<?php

include '../../../config.php';

session_start();


date_default_timezone_set('Africa/Dar_es_Salaam');

$currentDate = date('Y-m-d');
$currentTime = date('H:i:s');

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Reservation Report';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Reports';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    Reservation Report
                </a>
                <!-- <a href="#" data-page="1">
                    Cancelled Reservation Report
                </a> -->

            </div>
            <div class="inline-page-body">
                <!--Reservation Report-->
                <div class="page active">

                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Reservation Report</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form" id="reportForm">
    <div class="form-section">
        <div class="sec">
            <div class="input-label">
                <label for="fromdate">FROM:</label>
                <div class="date-time">
                    <input type="date" class="date" name="fromdate" id="fromdate" required>
                </div>
            </div>
            <div class="input-label">
                <label for="todate">TO:</label>
                <div class="date-time">
                    <input type="date" class="date" name="todate" id="todate" value="<?php echo $currentDate ?>" required>
                </div>
            </div>
        </div>
    </div>
    <div class="form-submit">
        <button type="button" class="cancel" onclick="this.closest('.report-form').reset();">
            <div class="icon">
                <i class="fa fa-times" aria-hidden="true"></i>
            </div>
            <span>CANCEL</span>
        </button>
        <button type="submit" class="confirm">
            <div class="icon">
                <i class="fa fa-check" aria-hidden="true"></i>
            </div>
            <span>CONFIRM</span>
        </button>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const reportForm = document.getElementById('reportForm');

    reportForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch('generate_payment_report.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.blob();
        })
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `Payment_Report_${new Date().toISOString().slice(0,10)}.pdf`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
        })
        .catch(error => console.error('Error generating PDF:', error));
    });
});
</script>
                        </div>
                    </div>

                </div>

                <!--Cancelled Reservation Report-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Cancelled Reservation Report</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form">
                                <div class="form-section">
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">FROM:</label><br>
                                            <input type="date">
                                        </div>
                                        
                                        <div class="input-label">
                                            <label for="">TO:</label><br>
                                            <input type="date">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-submit">
                                    <button class="cancel">
                                        <div class="icon">
                                            <i class="fa fa-times" aria-hidden="true"></i>
                                        </div>
                                        <span>CANCEL</span>
                                    </button>
                                    <button class="confirm">
                                        <div class="icon">
                                            <i class="fa fa-check" aria-hidden="true"></i>
                                        </div>
                                        <span>CONFIRM</span>
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>


    <?php
        include '../../../assets/components/root/js.php';
    ?>

</body>
</html>