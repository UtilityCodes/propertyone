<?php

session_start();

require_once '../../../config.php';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    // Get and sanitize form data
    $room_id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $code = isset($_POST['code']) ? trim($_POST['code']) : '';
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $price = isset($_POST['uprice']) ? floatval($_POST['uprice']) : 0;
    $description = isset($_POST['note']) ? trim($_POST['note']) : '';
    
    // Validate input
    $errors = [];
    
    if ($room_id <= 0) {
        $errors[] = "Invalid room ID";
    }
    
    if (empty($code)) {
        $errors[] = "Room code cannot be empty";
    }
    
    if (empty($name)) {
        $errors[] = "Room name cannot be empty";
    }
    
    if ($price <= 0) {
        $errors[] = "Price must be greater than zero";
    }
    
    // If there are no errors, update the database
    if (empty($errors)) {
        try {
            // Prepare the SQL statement
            $sql = "UPDATE rooms SET code = ?, name = ?, note = ?, uprice = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            
            
            // Bind parameters and execute
            $stmt->bind_param("sssds", $code, $name, $description, $price, $room_id);
            
            if ($stmt->execute()) {
                // Set success message
                $_SESSION['success_message'] = "Room updated successfully!";
            } else {
                // Set error message
                $_SESSION['error_message'] = "Error updating room: " . $stmt->error;
            }
            
            // Close statement
            $stmt->close();
        } catch (Exception $e) {
            $_SESSION['error_message'] = "Database error: " . $e->getMessage();
        }
    } else {
        // Set error messages
        $_SESSION['error_message'] = implode("<br>", $errors);
    }
    
    // Redirect back to the room listing page
    header("Location: index.php"); // Adjust to your actual page
    exit;
} else {
    // If form wasn't submitted properly, redirect
    $_SESSION['error_message'] = "Invalid form submission";
    header("Location: index.php"); // Adjust to your actual page
    exit;
}
