<?php
session_start();
require_once '../../../config.php';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    // Get and validate the ID
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;

    $errors = [];
    if ($id <= 0) {
        $errors[] = "Invalid housekeeping ID";
    }

    // If no errors, delete from the database
    if (empty($errors)) {
        try {
            // Prepare the SQL statement
            $sql = "DELETE FROM house_keeping WHERE id = ?";
            $stmt = $conn->prepare($sql);

            if ($stmt === false) {
                $_SESSION['error_message'] = "Prepare failed: " . $conn->error;
                header("Location: index.php"); // Adjust to your listing page
                exit;
            }

            // Bind parameter
            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $_SESSION['success_message'] = "Housekeeping record deleted successfully!";
                } else {
                    $_SESSION['error_message'] = "No housekeeping record found with ID: $id";
                }
            } else {
                $_SESSION['error_message'] = "Error deleting record: " . $stmt->error;
            }

            $stmt->close();
        } catch (Exception $e) {
            $_SESSION['error_message'] = "Database error: " . $e->getMessage();
        }
    } else {
        $_SESSION['error_message'] = implode("<br>", $errors);
    }

    // Redirect back to the listing page
    header("Location: index.php"); // Adjust to your listing page
    exit;
} else {
    // Invalid access
    $_SESSION['error_message'] = "Invalid form submission";
    header("Location: index.php"); // Adjust to your listing page
    exit;
}
?>