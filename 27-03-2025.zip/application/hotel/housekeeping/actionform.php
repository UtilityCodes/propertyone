<?php

include '../../../config.php';

session_start();

$company = $_SESSION['company_id'];

function generateCode(){
    $timestamp = time();

    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);

    $code = 'hk' . '-'  . $timestamp . '-' . $randomNumber;

    return $code;
}

if(isset($_POST['submit'])){
    $code = $_POST['code'];
    $dates = $_POST['date'];
    $timee = $_POST['time'];

    $rooms = $_POST['room'];
    $hktype = $_POST['hktype'];

    $fromdate = $_POST['fromdate'];
    $fromtime = $_POST['fromtime'];

    $todate = $_POST['todate'];
    $totime = $_POST['totime'];

    $note = $_POST['note'];
    $company = $_SESSION['company_id'];
    $user = $_SESSION['user_id'];

    date_default_timezone_set('Africa/Dar_es_Salaam');

    if($code == null){
        $code = generateCode();   
    }

    if($dates == null){
        $dates = date('Y-m-d');  
    }

    if($timee == null){
        $timee = date("H:i:s"); 
    }

    if($note == null){
        $note = 'No Note';   
    }

    $sql = "INSERT INTO house_keeping (code, dates, timee, rooms_id, hktype_id, fromdate, fromtime, todate, totime, note, company_id, user_id) 
                 VALUES ('$code', '$dates','$timee', '$rooms', '$hktype', '$fromdate', '$fromtime', '$todate', '$totime', '$note', '$company', '$user')";

    if ($conn->query($sql) === TRUE) {
        header("location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}