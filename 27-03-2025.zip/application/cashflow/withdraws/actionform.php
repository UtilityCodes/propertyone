<?php

include '../../../config.php';

session_start();

$company = $_SESSION['company_id'];

function generateCode(){
    $timestamp = time();

    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);

    $code = 'wd' . '-'  . $timestamp . '-' . $randomNumber;

    return $code;
}

function generatePayCode(){
    $timestamp = time();

    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);

    $paycode = 'py' . '-'  . $timestamp . '-' . $randomNumber;

    return $paycode;
}

$activityQuery = "SELECT id, name
               FROM activity
               WHERE name = 'WITHDRAWS'";
$activityResult = $conn->query($activityQuery);
$activities = $activityResult->fetch_assoc();

$paytypeQuery = "SELECT id, name
               FROM paytype
               WHERE name = 'DIRECT'";
$paytypeResult = $conn->query($paytypeQuery);
$paytypes = $paytypeResult->fetch_assoc();

$paydirectQuery = "SELECT id, name
               FROM paydirect
               WHERE name = 'SENT'";
$paydirectResult = $conn->query($paydirectQuery);
$paydirects = $paydirectResult->fetch_assoc();

$paycatQuery = "SELECT id, name
               FROM paycat
               WHERE name = 'Withdraws'";
$paycatResult = $conn->query($paycatQuery);
$paycats = $paycatResult->fetch_assoc();

if (isset($_POST["submit"])){  
    $dates = $_POST['date'];
    $timee = $_POST['time'];

    $code = $_POST['code'];
    $paycode = generatePayCode();

    $note = $_POST['note'];
    $accounts = $_POST['account'];

    $amount = $_POST['amount'];

    $activity = $activities['id'];


    $company = $_SESSION['company_id'];
    $user = $_SESSION['user_id'];

    $paytype = $paytypes['id'];
    $paydirect = $paydirects['id'];
    $paycat = $paycats['id'];


    date_default_timezone_set('Africa/Dar_es_Salaam');

    if($code == null){
        $code = generateCode();   
    }

    if($dates == null){
        $dates = date('Y-m-d');  
    }

    if($timee == null){
        $timee = date("H:i:s"); 
    }

    if($note == null){
        $note = 'No Note';   
    }

    $sql = "INSERT INTO cashflow (code, accounts_id, amount, note, user_id, activity_id, company_id, dates, timee) 
                    VALUES ('$code', '$accounts', '$amount', '$note', '$user', '$activity', '$company', '$dates', '$timee')";
    $result = $conn->query($sql);

    if ($result === TRUE) {

        $accountSql = "SELECT balance, sent
                        FROM accounts
                        WHERE id = '$accounts'";
        $accountResult = $conn->query($accountSql);

        if ($accountResult->num_rows > 0){
            $account = $accountResult->fetch_assoc();
            $oldBalance = $account['balance'];
            $oldSent = $account['sent'];
            $newBalance = $oldBalance - $amount;
            $newSent = $oldSent + $amount;

            $newAccountSql = "UPDATE accounts 
                              SET balance = '$newBalance',
                                  sent = '$newSent'
                              WHERE id = '$accounts'";
            $newAccountResult = $conn->query($newAccountSql);
        }

        $paymentSql = "INSERT INTO payments (code, dates, timee, accounts_id, act_code, amount, activity_id, company_id, user_id, note, paydirect_id, paytype_id, paycat_id)
                        VALUES ('$paycode','$dates','$timee', '$accounts','$code','$amount','$activity','$company','$user','$note','$paydirect','$paytype','$paycat')";
        $paymentResult = $conn->query($paymentSql);


        header("location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

}

$conn->close();
