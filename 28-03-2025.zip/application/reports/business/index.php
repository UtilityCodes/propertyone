<?php

include '../../../config.php';

session_start();


date_default_timezone_set('Africa/Dar_es_Salaam');

$currentDate = date('Y-m-d');
$currentTime = date('H:i:s');

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Business Report';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Reports';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    Business Report
                </a>
                <!-- <a href="#" data-page="1">
                    Other
                </a> -->

            </div>
            <div class="inline-page-body">
                <!--Business Report-->
                <div class="page active">

                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Business Report</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form" id="reportForm">
    <div class="form-section">
        <div class="sec">
            <div class="input-label">
                <label for="fromdate">FROM:</label><br>
                <input type="date" name="fromdate" id="fromdate" required>
            </div>
            <div class="input-label">
                <label for="todate">TO:</label><br>
                <input type="date" name="todate" id="todate" value="<?php echo $currentDate ?>" required>
            </div>
        </div>
    </div>
    <div class="form-submit">
        <button type="button" class="cancel" onclick="this.closest('.report-form').reset();">
            <div class="icon">
                <i class="fa fa-times" aria-hidden="true"></i>
            </div>
            <span>CANCEL</span>
        </button>
        <button type="submit" class="confirm">
            <div class="icon">
                <i class="fa fa-check" aria-hidden="true"></i>
            </div>
            <span>CONFIRM</span>
        </button>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const reportForm = document.getElementById('reportForm');

    reportForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch('generate_business_report.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.blob();
        })
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `Business_Report_${new Date().toISOString().slice(0,10)}.pdf`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
        })
        .catch(error => console.error('Error generating PDF:', error));
    });
});
</script>
                        </div>
                    </div>

                </div>

                <!--Expense Type Report-->
                <div class="page"></div>


            </div>
        </div>
    </div>


    <?php
        include '../../../assets/components/root/js.php';
    ?>

</body>
</html>