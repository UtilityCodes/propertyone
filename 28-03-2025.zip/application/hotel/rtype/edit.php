<?php
session_start();
require_once '../../../config.php';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    // Get and sanitize form data
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $code = isset($_POST['code']) ? trim($_POST['code']) : '';
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
    $note = isset($_POST['note']) ? trim($_POST['note']) : '';

    // Validate input
    $errors = [];
    if ($id <= 0) {
        $errors[] = "Invalid room type ID";
    }
    if (empty($code)) {
        $errors[] = "Room code cannot be empty";
    }
    if (empty($name)) {
        $errors[] = "Room name cannot be empty";
    }
    if ($price <= 0) {
        $errors[] = "Price must be greater than zero";
    }

    // If no errors, update the database
    if (empty($errors)) {
        try {
            // Prepare the SQL statement
            $sql = "UPDATE rtype SET code = ?, name = ?, price = ?, note = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);

            if ($stmt === false) {
                $_SESSION['error_message'] = "Prepare failed: " . $conn->error;
                header("Location: index.php"); // Adjust to your listing page
                exit;
            }

            // Bind parameters
            $stmt->bind_param("ssdsi", $code, $name, $price, $note, $id);

            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $_SESSION['success_message'] = "Room type updated successfully!";
                } else {
                    $_SESSION['error_message'] = "No room type found with ID: $id";
                }
            } else {
                $_SESSION['error_message'] = "Error updating room type: " . $stmt->error;
            }

            $stmt->close();
        } catch (Exception $e) {
            $_SESSION['error_message'] = "Database error: " . $e->getMessage();
        }
    } else {
        $_SESSION['error_message'] = implode("<br>", $errors);
    }

    // Redirect back to the listing page
    header("Location: index.php"); // Adjust to your listing page (e.g., where the <div class="pcb-content"> is)
    exit;
} else {
    // Invalid access
    $_SESSION['error_message'] = "Invalid form submission";
    header("Location: index.php"); // Adjust to your listing page
    exit;
}
