<?php
// actionform.php
include '../../../config.php';

session_start();

date_default_timezone_set('Africa/Dar_es_Salaam');

$company = $_SESSION['company_id'];
$user = $_SESSION['user_id'];

function generateCode() {
    $timestamp = time();
    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
    return 'rs-' . $timestamp . '-' . $randomNumber;
}

function generateCusCode() {
    $timestamp = time();
    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
    return 'cu-' . $timestamp . '-' . $randomNumber;
}

function generatePayCode() {
    $timestamp = time();
    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
    return 'py-' . $timestamp . '-' . $randomNumber;
}

// Fetch reference data
$activityQuery = "SELECT id, name FROM activity WHERE name = 'BOOKINGS'";
$activityResult = $conn->query($activityQuery);
$activities = $activityResult->fetch_assoc();

$paytypeQuery = "SELECT id, name FROM paytype WHERE name = 'DIRECT'";
$paytypeResult = $conn->query($paytypeQuery);
$paytypes = $paytypeResult->fetch_assoc();

$paydirectQuery = "SELECT id, name FROM paydirect WHERE name = 'RECEIVED'";
$paydirectResult = $conn->query($paydirectQuery);
$paydirects = $paydirectResult->fetch_assoc();

$paycatQuery = "SELECT id, name FROM paycat WHERE name = 'Direct Payments'";
$paycatResult = $conn->query($paycatQuery);
$paycats = $paycatResult->fetch_assoc();

$booktypeQuery = "SELECT id, name FROM booktype WHERE name = 'In-House'";
$booktypeResult = $conn->query($booktypeQuery);
$booktypes = $booktypeResult->fetch_assoc();

if (isset($_POST["submit"])) {
    $code = generateCode();
    $paycode = generatePayCode();
    $cuscode = generateCusCode();

    $dates = date('Y-m-d');
    $timee = date("H:i:s");

    // Booking data
    $fromdate = $_POST['fromdate'];
    $fromtime = $_POST['fromtime'];
    $todate = $_POST['todate'];
    $totime = $_POST['totime'];
    $rooms = $_POST['room'];
    $ogprice = $_POST['ogprice'];
    $mprice = $_POST['mprice'];
    $nights = $_POST['nights'] ?? 0;
    $adults = $_POST['adults'] ?? 1;
    $children = $_POST['children'] ?? 0;
    $babies = $_POST['babies'] ?? 0;
    $amount = $_POST['amount'] ?? 0;
    $paid = $_POST['paid'] ?? 0;
    $vatpercent = $_POST['vatpercent'] ?? 0;
    $vat = $_POST['vat'] ?? 0;
    $discount = $_POST['discount'] ?? 0;
    $note = $_POST['note'] ?? 'No Note';

    // Check if "checkedin" checkbox is checked
    $checkedin = isset($_POST['checkedin']) && $_POST['checkedin'] === 'on';
    $checkindate = $checkedin ? $fromdate : null; // Set to fromdate if checked, null otherwise
    $checkintime = $checkedin ? $fromtime : null; // Set to fromtime if checked, null otherwise

    // Customer data
    $idno = $_POST['idno'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $name = "$fname $lname";
    $language = $_POST['language'] ?? '';
    $idtype = $_POST['idtype'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? 'No Email';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $country = $_POST['country'] ?? '';

    // Payment accounts
    $cashaccount = $_POST['cashaccount'] ?? '';
    $bankaccount = $_POST['bankaccount'] ?? '';
    $mobileaccount = $_POST['mobileaccount'] ?? '';
    $posaccount = $_POST['posaccount'] ?? '';

    $booktype = $booktypes['id'];
    $activity = $activities['id'];
    $paytype = $paytypes['id'];
    $paydirect = $paydirects['id'];
    $paycat = $paycats['id'];

    if ($company && $user && $booktype && $adults !== null && $rooms) {
        // Insert Booking with added fields including checkindate and checkintime
        $bookingSql = "INSERT INTO bookings 
                        (code, 
                         dates, 
                         timee, 
                         fromdate, 
                         fromtime, 
                         todate, 
                         totime, 
                         rooms_id, 
                         ogprice, 
                         mprice, 
                         nights, 
                         adults, 
                         children, 
                         babies, 
                         note, 
                         customer_idno, 
                         discount, 
                         vatpercent, 
                         vat, 
                         amount, 
                         paid, 
                         booktype_id, 
                         company_id, 
                         user_id, 
                         checkindate, 
                         checkintime) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($bookingSql);
        $stmt->bind_param("ssssssssddiiiiisssddiissss", 
            $code, 
            $dates, 
            $timee, 
            $fromdate, 
            $fromtime, 
            $todate, 
            $totime, 
            $rooms, 
            $ogprice, 
            $mprice, 
            $nights, 
            $adults, 
            $children, 
            $babies, 
            $note, 
            $idno, 
            $discount, 
            $vatpercent, 
            $vat, 
            $amount, 
            $paid, 
            $booktype, 
            $company, 
            $user, 
            $checkindate, // Added
            $checkintime  // Added
        );
        
        if ($stmt->execute()) {
            $bookingId = $conn->insert_id;

            // Customer Logic (unchanged)
            $checkSql = "SELECT id FROM customer WHERE idno = ?";
            $checkStmt = $conn->prepare($checkSql);
            $checkStmt->bind_param("s", $idno);
            $checkStmt->execute();
            $result = $checkStmt->get_result();

            if ($result->num_rows > 0) {
                $updateSql = "UPDATE customer SET fname = ?, lname = ?, name = ?, languages_id = ?, idtype_id = ?, phone = ?, email = ?, city = ?, state = ?, country = ? WHERE idno = ?";
                $updateStmt = $conn->prepare($updateSql);
                $updateStmt->bind_param("sssssssssss", $fname, $lname, $name, $language, $idtype, $phone, $email, $city, $state, $country, $idno);
                $updateStmt->execute();
                $updateStmt->close();
            } else {
                $insertSql = "INSERT INTO customer (code, dates, timee, fname, lname, name, languages_id, idtype_id, idno, phone, email, city, state, country, note, company_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $insertStmt = $conn->prepare($insertSql);
                $insertStmt->bind_param("ssssssssssssssss", $cuscode, $dates, $timee, $fname, $lname, $name, $language, $idtype, $idno, $phone, $email, $city, $state, $country, $note, $company);
                $insertStmt->execute();
                $insertStmt->close();
            }
            $checkStmt->close();

            // Payment Processing (unchanged)
            $paymentDetails = [];

            if (!empty($_POST['cashamount']) && $cashaccount) {
                $cashSql = "SELECT balance, received FROM accounts WHERE id = ?";
                $cashStmt = $conn->prepare($cashSql);
                $cashStmt->bind_param("s", $cashaccount);
                $cashStmt->execute();
                $cashResult = $cashStmt->get_result();
                if ($cashResult->num_rows > 0) {
                    $cash = $cashResult->fetch_assoc();
                    $newBalance = $cash['balance'] + (float)$_POST['cashamount'];
                    $newReceived = $cash['received'] + (float)$_POST['cashamount'];
                    $updateSql = "UPDATE accounts SET balance = ?, received = ? WHERE id = ?";
                    $updateStmt = $conn->prepare($updateSql);
                    $updateStmt->bind_param("dds", $newBalance, $newReceived, $cashaccount);
                    $updateStmt->execute();
                    $updateStmt->close();
                    $paymentDetails[] = ['accounts_id' => $cashaccount, 'amount' => $_POST['cashamount']];
                }
                $cashStmt->close();
            }

            if (!empty($_POST['mobileamount']) && $mobileaccount) {
                $mobileSql = "SELECT balance, received FROM accounts WHERE id = ?";
                $mobileStmt = $conn->prepare($mobileSql);
                $mobileStmt->bind_param("s", $mobileaccount);
                $mobileStmt->execute();
                $mobileResult = $mobileStmt->get_result();
                if ($mobileResult->num_rows > 0) {
                    $mobile = $mobileResult->fetch_assoc();
                    $newBalance = $mobile['balance'] + (float)$_POST['mobileamount'];
                    $newReceived = $mobile['received'] + (float)$_POST['mobileamount'];
                    $updateSql = "UPDATE accounts SET balance = ?, received = ? WHERE id = ?";
                    $updateStmt = $conn->prepare($updateSql);
                    $updateStmt->bind_param("dds", $newBalance, $newReceived, $mobileaccount);
                    $updateStmt->execute();
                    $updateStmt->close();
                    $paymentDetails[] = ['accounts_id' => $mobileaccount, 'amount' => $_POST['mobileamount']];
                }
                $mobileStmt->close();
            }

            if (!empty($_POST['bankamount']) && $bankaccount) {
                $bankSql = "SELECT balance, received FROM accounts WHERE id = ?";
                $bankStmt = $conn->prepare($bankSql);
                $bankStmt->bind_param("s", $bankaccount);
                $bankStmt->execute();
                $bankResult = $bankStmt->get_result();
                if ($bankResult->num_rows > 0) {
                    $bank = $bankResult->fetch_assoc();
                    $newBalance = $bank['balance'] + (float)$_POST['bankamount'];
                    $newReceived = $bank['received'] + (float)$_POST['bankamount'];
                    $updateSql = "UPDATE accounts SET balance = ?, received = ? WHERE id = ?";
                    $updateStmt = $conn->prepare($updateSql);
                    $updateStmt->bind_param("dds", $newBalance, $newReceived, $bankaccount);
                    $updateStmt->execute();
                    $updateStmt->close();
                    $paymentDetails[] = ['accounts_id' => $bankaccount, 'amount' => $_POST['bankamount']];
                }
                $bankStmt->close();
            }

            if (!empty($_POST['posamount']) && $posaccount) {
                $posSql = "SELECT balance, received FROM accounts WHERE id = ?";
                $posStmt = $conn->prepare($posSql);
                $posStmt->bind_param("s", $posaccount);
                $posStmt->execute();
                $posResult = $posStmt->get_result();
                if ($posResult->num_rows > 0) {
                    $pos = $posResult->fetch_assoc();
                    $newBalance = $pos['balance'] + (float)$_POST['posamount'];
                    $newReceived = $pos['received'] + (float)$_POST['posamount'];
                    $updateSql = "UPDATE accounts SET balance = ?, received = ? WHERE id = ?";
                    $updateStmt = $conn->prepare($updateSql);
                    $updateStmt->bind_param("dds", $newBalance, $newReceived, $posaccount);
                    $updateStmt->execute();
                    $updateStmt->close();
                    $paymentDetails[] = ['accounts_id' => $posaccount, 'amount' => $_POST['posamount']];
                }
                $posStmt->close();
            }

            foreach ($paymentDetails as $payment) {
                $paymentSql = "INSERT INTO payments 
                                (code, 
                                 dates, 
                                 timee, 
                                 act_code, 
                                 accounts_id, 
                                 amount, 
                                 activity_id, 
                                 company_id, 
                                 user_id, note, 
                                 paydirect_id, 
                                 paytype_id, 
                                 paycat_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $paymentStmt = $conn->prepare($paymentSql);
                $paymentStmt->bind_param("ssssssdssssss", $paycode, $dates, $timee, $code, $payment['accounts_id'], $payment['amount'], $activity, $company, $user, $note, $paydirect, $paytype, $paycat);
                $paymentStmt->execute();
                $paymentStmt->close();
            }

            header("Location: index.php");
            exit();
        } else {
            echo "Error inserting booking: " . $conn->error;
        }
        $stmt->close();
    } else {
        echo "Required fields are missing.";
    }
}

$conn->close();