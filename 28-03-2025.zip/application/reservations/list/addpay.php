<?php

include '../../../config.php';

session_start();

date_default_timezone_set('Africa/Dar_es_Salaam');

$company = $_SESSION['company_id'];
$user = $_SESSION['user_id'];

// Fetch reference data (unchanged)
$activityQuery = "SELECT id, name FROM activity WHERE name = 'BOOKINGS'";
$activityResult = $conn->query($activityQuery);
$activities = $activityResult->fetch_assoc();

$paytypeQuery = "SELECT id, name FROM paytype WHERE name = 'CREDIT'";
$paytypeResult = $conn->query($paytypeQuery);
$paytypes = $paytypeResult->fetch_assoc();

$paydirectQuery = "SELECT id, name FROM paydirect WHERE name = 'RECEIVED'";
$paydirectResult = $conn->query($paydirectQuery);
$paydirects = $paydirectResult->fetch_assoc();

$paycatQuery = "SELECT id, name FROM paycat WHERE name = 'Direct Payments'";
$paycatResult = $conn->query($paycatQuery);
$paycats = $paycatResult->fetch_assoc();

if (isset($_POST["id"]) && isset($_POST["addpay"])) {
    $bookingId = $_POST["id"];
    $paid = floatval($_POST["paid"]);
    $amount = floatval($_POST["amount"]);
    $addPay = floatval($_POST["addpayment"]);

    // Get current date and time
    $dates = date('Y-m-d');
    $timee = date("H:i:s");

    // Generate a random payment code
    $paycode = 'PAY' . date('YmdHis') . rand(100, 999);

    // Get booking code and current values
    $bookingQuery = "SELECT code, paid, amount FROM bookings WHERE id = ?";
    $bookingStmt = $conn->prepare($bookingQuery);
    $bookingStmt->bind_param("i", $bookingId);
    $bookingStmt->execute();
    $bookingResult = $bookingStmt->get_result();
    $bookingData = $bookingResult->fetch_assoc();
    $code = $bookingData['code'];
    $currentPaid = floatval($bookingData['paid']);
    $currentAmount = floatval($bookingData['amount']);
    $bookingStmt->close();

    // Calculate new values
    $newPaid = $currentPaid + $paid;
    $newAmount = $currentAmount + $addPay;

    // Update booking with new paid and amount values
    $updateBookingSql = "UPDATE bookings SET paid = ?, amount = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateBookingSql);
    $updateStmt->bind_param("ddi", $newPaid, $newAmount, $bookingId);
    
    if ($updateStmt->execute()) {
        $success = true;
        $activity = $activities['id'];
        $paytype = $paytypes['id'];
        $paydirect = $paydirects['id'];
        $paycat = $paycats['id'];
        $note = "Payment for booking " . $code;

        // Payment account processing (unchanged)
        $paymentAccounts = [
            ['field' => 'cashamount', 'account' => 'cashaccount'],
            ['field' => 'bankamount', 'account' => 'bankaccount'],
            ['field' => 'mobileamount', 'account' => 'mobileaccount'],
            ['field' => 'posamount', 'account' => 'posaccount']
        ];

        foreach ($paymentAccounts as $paymentType) {
            $amountField = $paymentType['field'];
            $accountField = $paymentType['account'];
            
            if (!empty($_POST[$amountField]) && !empty($_POST[$accountField])) {
                $accountId = $_POST[$accountField];
                $payAmount = floatval($_POST[$amountField]);
                
                // Update account balance
                $accountSql = "SELECT balance, received FROM accounts WHERE id = ?";
                $accountStmt = $conn->prepare($accountSql);
                $accountStmt->bind_param("s", $accountId);
                $accountStmt->execute();
                $accountResult = $accountStmt->get_result();
                
                if ($accountResult->num_rows > 0) {
                    $account = $accountResult->fetch_assoc();
                    $newBalance = $account['balance'] + $payAmount;
                    $newReceived = $account['received'] + $payAmount;
                    
                    $updateAccountSql = "UPDATE accounts SET balance = ?, received = ? WHERE id = ?";
                    $updateAccountStmt = $conn->prepare($updateAccountSql);
                    $updateAccountStmt->bind_param("dds", $newBalance, $newReceived, $accountId);
                    $updateAccountStmt->execute();
                    $updateAccountStmt->close();
                    
                    // Insert payment record
                    $paymentSql = "INSERT INTO payments 
                        (code, dates, timee, act_code, accounts_id, amount, 
                         activity_id, company_id, user_id, note, 
                         paydirect_id, paytype_id, paycat_id) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    
                    $paymentStmt = $conn->prepare($paymentSql);
                    $paymentStmt->bind_param(
                        "sssssdsssssss", 
                        $paycode, $dates, $timee, $code, $accountId, $payAmount,
                        $activity, $company, $user, $note, 
                        $paydirect, $paytype, $paycat
                    );
                    
                    $paymentStmt->execute();
                    $paymentStmt->close();
                }
                
                $accountStmt->close();
            }
        }

        // Redirect back to bookings page
        header("Location: index.php?success=payment_added");
        exit();
    } else {
        echo "Error updating booking: " . $conn->error;
    }
    
    $updateStmt->close();
} else {
    echo "Required fields are missing.";
}

