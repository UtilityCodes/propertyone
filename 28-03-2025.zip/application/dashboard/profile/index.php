<?php

include '../../../config.php';

session_start();

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];
$user = $_SESSION['user_id'];

include 'profile.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Profile Details';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Profile';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    Profile
                </a>
                <!-- <a href="#" data-page="1">
                    Settings
                </a> -->

            </div>
            <div class="inline-page-body">
                <!--Profile-->
                <div class="page active">

                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>User Profile Details:</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form">
                                <div class="form-section">
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Code:</label><br>
                                            <input type="text" value="<?php echo $code ?>" disabled>
                                        </div>
                                        <div class="input-label">
                                            <label for="">Name:</label><br>
                                            <input type="text" value="<?php echo $name ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Passcode:</label><br>
                                            <input type="text" value="<?php echo $passcode ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Phone:</label><br>
                                            <input type="text" value="<?php echo $phone ?>" disabled>
                                        </div>
                                        <div class="input-label">
                                            <label for="">Email:</label><br>
                                            <input type="text" value="<?php echo $email ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Description:</label><br>
                                            <textarea name="note"disabled><?php echo $note ?></textarea>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>

                </div>

                <!--Settings-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>Settings:</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form">
                                <div class="form-section">
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Code:</label><br>
                                            <input type="text" value="Us-4236789">
                                        </div>
                                        <div class="input-label">
                                            <label for="">Name:</label><br>
                                            <input type="text" value="Allan Kabila">
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Passcode:</label><br>
                                            <input type="text" value="1234">
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Phone:</label><br>
                                            <input type="text" value="0765432189">
                                        </div>
                                        <div class="input-label">
                                            <label for="">Email:</label><br>
                                            <input type="text" value="allan@gmail.com">
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Description:</label><br>
                                            <textarea name="" id="">This is the beginning</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-submit">
                                    <button class="cancel">
                                        <div class="icon">
                                            <i class="fa fa-times" aria-hidden="true"></i>
                                        </div>
                                        <span>CANCEL</span>
                                    </button>
                                    <button class="confirm">
                                        <div class="icon">
                                            <i class="fa fa-check" aria-hidden="true"></i>
                                        </div>
                                        <span>CONFIRM</span>
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>


    <?php
        include '../../../assets/components/root/js.php';
    ?>
</body>
</html>