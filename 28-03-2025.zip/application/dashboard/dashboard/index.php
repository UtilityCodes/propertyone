<?php
// index.php for dashboard
include '../../../config.php';
session_start();

date_default_timezone_set('Africa/Dar_es_Salaam');

if (!isset($_SESSION['company_id']) || !isset($_SESSION['roles'])) {
    header("Location: login.php");
    exit();
}

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

include 'dashcards.php';
include 'roomstatus.php';
include 'bookings.php';
include 'guests.php';
include 'arrdep.php';
include 'paymentsgraph.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Dashboard';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php include '../../../assets/components/navi/navi.php'; ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Dashboard';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>
        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">Today</a>
                <a href="#" data-page="1">Yesterday</a>
                <a href="#" data-page="2">Past Week</a>
                <a href="#" data-page="3">Past Month</a>
            </div>
            <div class="inline-page-body">
                <!-- Today -->
                <div class="page active">
                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Arrivals</div>
                                        <div class="item-figure"><?php echo $arrivals; ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Departure</div>
                                        <div class="item-figure"><?php echo $departures; ?></div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">Direct Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($directPayment); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Credit Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($creditPayment); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Total Revenue</div>
                                        <div class="item-figure"><?php echo formatNumber($totalRevenue); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure"><?php echo formatNumber($totalCost); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Reservation Payments</div>
                                        <div class="item-figure"><?php echo formatNumber($reservationPayments); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Deposits</div>
                                        <div class="item-figure"><?php echo formatNumber($deposits); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <!-- <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure"><?php echo formatNumber($reservationRefunds); ?></div>
                                    </div> -->
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure"><?php echo formatNumber($withdraws); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure"><?php echo formatNumber($expenses); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php include 'dashbody.php'; ?>
                    </div>
                </div>

                <!-- Yesterday -->
                <div class="page">
                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Arrivals</div>
                                        <div class="item-figure"><?php echo $yesterday_arrivals; ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Departure</div>
                                        <div class="item-figure"><?php echo $yesterday_departures; ?></div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">Direct Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_directPayment); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Credit Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_creditPayment); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Total Revenue</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_totalRevenue); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_totalCost); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Reservation Payments</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_reservationPayments); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Deposits</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_deposits); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <!-- <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_reservationRefunds); ?></div>
                                    </div> -->
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_withdraws); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure"><?php echo formatNumber($yesterday_expenses); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Past Week -->
                <div class="page">
                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Arrivals</div>
                                        <div class="item-figure"><?php echo $week_arrivals; ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Departure</div>
                                        <div class="item-figure"><?php echo $week_departures; ?></div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">Direct Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($week_directPayment); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Credit Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($week_creditPayment); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Total Revenue</div>
                                        <div class="item-figure"><?php echo formatNumber($week_totalRevenue); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure"><?php echo formatNumber($week_totalCost); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Reservation Payments</div>
                                        <div class="item-figure"><?php echo formatNumber($week_reservationPayments); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Deposits</div>
                                        <div class="item-figure"><?php echo formatNumber($week_deposits); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <!-- <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure"><?php echo formatNumber($week_reservationRefunds); ?></div>
                                    </div> -->
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure"><?php echo formatNumber($week_withdraws); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure"><?php echo formatNumber($week_expenses); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Past Month -->
                <div class="page">
                    <div class="page-content-body">
                        <div class="dashcards">
                            <div class="left">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Arrivals</div>
                                        <div class="item-figure"><?php echo $month_arrivals; ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Departure</div>
                                        <div class="item-figure"><?php echo $month_departures; ?></div>
                                    </div>
                                </div>
                                <div class="flex middle">
                                    <div class="item">
                                        <div class="item-name">Direct Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($month_directPayment); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Credit Payment</div>
                                        <div class="item-figure"><?php echo formatNumber($month_creditPayment); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <div class="item">
                                        <div class="item-name">Total Revenue</div>
                                        <div class="item-figure"><?php echo formatNumber($month_totalRevenue); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Total Cost</div>
                                        <div class="item-figure"><?php echo formatNumber($month_totalCost); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="flex up">
                                    <div class="item">
                                        <div class="item-name">Reservation Payments</div>
                                        <div class="item-figure"><?php echo formatNumber($month_reservationPayments); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Deposits</div>
                                        <div class="item-figure"><?php echo formatNumber($month_deposits); ?></div>
                                    </div>
                                </div>
                                <div class="flex down">
                                    <!-- <div class="item">
                                        <div class="item-name">Reservation Refunds</div>
                                        <div class="item-figure"><?php echo formatNumber($month_reservationRefunds); ?></div>
                                    </div> -->
                                    <div class="item">
                                        <div class="item-name">Withdraws</div>
                                        <div class="item-figure"><?php echo formatNumber($month_withdraws); ?></div>
                                    </div>
                                    <div class="item">
                                        <div class="item-name">Expenses</div>
                                        <div class="item-figure"><?php echo formatNumber($month_expenses); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
        include '../../../assets/components/root/js.php';
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        console.log('DOM fully loaded');
        console.log('Room types element:', document.getElementById('room-types'));
        console.log('Room buttons element:', document.getElementById('room-buttons'));
        console.log('Schedule display element:', document.getElementById('schedule-display'));

        initializeCharts();
        initializeRoomCalendar();

        function initializeCharts() {
    // Get last 7 days with formatted dates
    function getLast7Days() {
        const days = [];
        const options = { day: '2-digit', month: 'short', year: 'numeric' };
        for (let i = 6; i >= 0; i--) {
            let date = new Date();
            date.setDate(date.getDate() - i);
            days.push(date.toLocaleDateString('en-GB', options));
        }
        return days;
    }

    // Line Chart: Bookings Per Day
    const ctx1 = document.getElementById('bookingChart').getContext('2d');
    const gradient = ctx1.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, 'rgba(75, 192, 192, 0.4)');
    gradient.addColorStop(1, 'rgba(75, 192, 192, 0)');

    new Chart(ctx1, {
        type: 'line',
        data: {
            labels: <?php echo $datesJson; ?>, // Use PHP-generated dates
            datasets: [{
                label: 'Bookings Per Day',
                data: <?php echo $countsJson; ?>, // Use PHP-generated booking counts
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: gradient,
                borderWidth: 2,
                fill: true,
                pointRadius: 5,
                pointBackgroundColor: 'rgba(75, 192, 192, 1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: { color: '#333', font: { size: 14 } }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleFont: { size: 14 },
                    bodyFont: { size: 12 }
                }
            },
            scales: {
                x: { 
                    title: { display: true, text: 'Date' },
                    ticks: { color: '#333', maxTicksLimit: 10 }, 
                    grid: { display: false } 
                },
                y: { 
                    title: { display: true, text: 'Number of Bookings' },
                    ticks: { color: '#333', stepSize: 1 }, 
                    grid: { color: 'rgba(200, 200, 200, 0.3)' },
                    beginAtZero: true
                }
            }
        }
    });

// Half Doughnut Chart: Occupancy Status
const ctx2 = document.getElementById('occupancyChart').getContext('2d');

// Ensure data is numeric and non-negative
const vacantRooms = Math.max(0, parseInt(<?php echo json_encode($vacantRooms); ?>) || 0);
const occupiedRooms = Math.max(0, parseInt(<?php echo json_encode($occupiedRooms); ?>) || 0);
const notReadyRooms = Math.max(0, parseInt(<?php echo json_encode($notReadyRooms); ?>) || 0);
const occupancyData = [vacantRooms, occupiedRooms, notReadyRooms];
const totalRooms = occupancyData.reduce((a, b) => a + b, 0);
const occupancyLabels = ['Vacant', 'Occupied', 'Not Ready'];
const occupancyColors = ['#36A2EB', '#FF6384', '#FFCE56']; // Removed semicolon

new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: occupancyLabels,
        datasets: [{
            data: occupancyData,
            backgroundColor: occupancyColors,
            borderWidth: 2,
            hoverOffset: 10,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '70%',
        rotation: -90,
        circumference: 180,
        plugins: {
            legend: { display: false },
            tooltip: {
                backgroundColor: 'rgba(0, 0, 0, 0.8)',
                titleFont: { size: 14 },
                bodyFont: { size: 12 }
            },
            datalabels: {
                color: '#fff',
                font: { weight: 'bold', size: 14 },
                formatter: (value) => totalRooms > 0 ? `${Math.round((value / totalRooms) * 100)}%` : '0%'
            }
        }
    },
    plugins: [{
        id: 'shadowEffect',
        beforeDraw: (chart) => {
            const ctx = chart.ctx;
            ctx.save();
            ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
            ctx.shadowBlur = 15;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 5;
        },
        afterDraw: (chart) => chart.ctx.restore()
    }]
});

// For debugging: Log the values to the console
console.log('Occupancy Data:', occupancyData);
console.log('Total Rooms:', totalRooms);

    // Triple Bar Chart: Payment Summary
    const ctx3 = document.getElementById('paymentChart').getContext('2d');
    const barColors = ['rgba(54, 162, 235, 0.7)', 'rgba(75, 192, 192, 0.7)', 'rgba(255, 99, 132, 0.7)'];
    const labels = <?php echo $datesJson; ?>;

    new Chart(ctx3, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Reservation Amounts',
                    data: <?php echo $reservationJson; ?>,
                    backgroundColor: barColors[0],
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Direct Payments',
                    data: <?php echo $directJson; ?>,
                    backgroundColor: barColors[1],
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Credit Payments',
                    data: <?php echo $creditJson; ?>,
                    backgroundColor: barColors[2],
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: { color: '#333', font: { size: 14 } }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleFont: { size: 14 },
                    bodyFont: { size: 12 },
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                x: {
                    title: { display: true, text: 'Date' },
                    ticks: { color: '#333', maxTicksLimit: 10 },
                    grid: { display: false }
                },
                y: {
                    title: { display: true, text: 'Amount' },
                    ticks: { color: '#333' },
                    grid: { color: 'rgba(200, 200, 200, 0.3)' },
                    beginAtZero: true
                }
            }
        }
    });
}

// Call the function when the page loads
document.addEventListener('DOMContentLoaded', initializeCharts);

        function initializeRoomCalendar() {
            console.log('Initializing room calendar...');
            
            // Load room types
            fetch('./roomcalendar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=get_room_types'
            })
            .then(response => {
                console.log('Room types fetch status:', response.status);
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(roomTypes => {
                console.log('Room types received:', roomTypes);
                if (roomTypes.error) {
                    console.error('Server error:', roomTypes.error);
                    return;
                }
                const container = document.getElementById('room-types');
                if (!container) {
                    console.error('Room types container not found');
                    return;
                }
                container.innerHTML = '';
                if (roomTypes.length === 0) {
                    container.innerHTML = '<p>No room types available</p>';
                } else {
                    roomTypes.forEach(type => {
                        const btn = document.createElement('button');
                        btn.className = 'rtype-btn';
                        btn.dataset.rtypeId = type.id;
                        btn.textContent = type.name;
                        btn.addEventListener('click', loadRooms);
                        container.appendChild(btn);
                    });
                }

                // Load default room after room types are populated
                loadDefaultRoom();
            })
            .catch(error => console.error('Fetch error for room types:', error));
        }

        function loadRooms(event) {
            const rtypeId = event.target.dataset.rtypeId;
            console.log('Loading rooms for rtype_id:', rtypeId);
            fetch('./roomcalendar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=get_rooms&rtype_id=${rtypeId}`
            })
            .then(response => {
                console.log('Rooms fetch status:', response.status);
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(rooms => {
                console.log('Rooms received:', rooms);
                if (rooms.error) {
                    console.error('Server error:', rooms.error);
                    return;
                }
                const container = document.getElementById('room-buttons');
                if (!container) {
                    console.error('Room buttons container not found');
                    return;
                }
                container.innerHTML = '';
                if (rooms.length === 0) {
                    container.innerHTML = '<p>No rooms available</p>';
                } else {
                    rooms.forEach(room => {
                        const btn = document.createElement('button');
                        btn.className = 'room-btn';
                        btn.dataset.roomId = room.id;
                        btn.textContent = room.name;
                        btn.addEventListener('click', loadSchedule);
                        container.appendChild(btn);
                    });
                }
                document.getElementById('schedule-display').innerHTML = '';
            })
            .catch(error => console.error('Fetch error for rooms:', error));
        }

        function loadSchedule(event) {
            const roomId = event.target.dataset.roomId;
            console.log('Loading schedule for room_id:', roomId);
            fetch('./roomcalendar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=get_schedule&room_id=${roomId}`
            })
            .then(response => {
                console.log('Schedule fetch status:', response.status);
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(schedule => {
                console.log('Schedule received:', schedule);
                if (schedule.error) {
                    console.error('Server error:', schedule.error);
                    return;
                }
                const container = document.getElementById('schedule-display');
                if (!container) {
                    console.error('Schedule display container not found');
                    return;
                }
                container.innerHTML = '';
                schedule.forEach(day => {
                    const div = document.createElement('div');
                    div.className = 'user-box ' + (day.available ? 'available-box' : 'customer-box');
                    div.innerHTML = `
                        <div class="date-day">
                            <div class="flex">
                                <div class="date">${day.date}</div>
                                <div class="day">${day.day}</div>
                            </div>
                        </div>
                        <div class="customer-available">
                            <div class="flex">
                                <div class="${day.available ? 'available' : 'customer'}">
                                    ${day.available ? 'Available for Booking' : day.customer}
                                </div>
                                <div class="icon"></div>
                            </div>
                        </div>
                    `;
                    container.appendChild(div);
                });
            })
            .catch(error => console.error('Fetch error for schedule:', error));
        }

        function loadDefaultRoom() {
            console.log('Fetching default room...');
            fetch('./roomcalendar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=get_default_room'
            })
            .then(response => {
                console.log('Default room fetch status:', response.status);
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(defaultRoom => {
                console.log('Default room received:', defaultRoom);
                if (defaultRoom.error) {
                    console.log('No default room found:', defaultRoom.error);
                    return; // Don’t proceed if no default room
                }

                // Simulate clicking the room type button for the default room’s rtype_id
                const rtypeBtn = document.querySelector(`.rtype-btn[data-rtype-id="${defaultRoom.rtype_id}"]`);
                if (rtypeBtn) {
                    console.log('Simulating click on rtype_id:', defaultRoom.rtype_id);
                    rtypeBtn.click(); // Load rooms for this type

                    // Wait briefly for rooms to load, then load the default room’s schedule
                    setTimeout(() => {
                        const roomBtn = document.querySelector(`.room-btn[data-room-id="${defaultRoom.id}"]`);
                        if (roomBtn) {
                            console.log('Simulating click on default room_id:', defaultRoom.id);
                            roomBtn.style.backgroundColor = '#ffff99'; // Highlight default room
                            roomBtn.click(); // Load schedule
                        } else {
                            console.error('Default room button not found after loading rooms');
                        }
                    }, 100); // Small delay to ensure rooms are rendered
                } else {
                    console.error('Room type button not found for rtype_id:', defaultRoom.rtype_id);
                }
            })
            .catch(error => console.error('Fetch error for default room:', error));
        }
    });
    </script>
    <?php
    // Close the database connection after all operations
    $conn->close();
    ?>
</body>
</html>



