<?php
header('Content-Type: application/json');
include '../../../config.php';
session_start();
date_default_timezone_set('Africa/Dar_es_Salaam');

if (!isset($_SESSION['company_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$company_id = $_SESSION['company_id'];
error_log("Company ID: $company_id");

function isDateBooked($date, $room_id, $conn) {
    $query = "SELECT b.*, c.name 
             FROM bookings b 
             LEFT JOIN customer c ON b.customer_idno = c.idno
             WHERE b.rooms_id = ? 
             AND b.company_id = ?
             AND ? BETWEEN 
                 DATE_SUB(b.fromdate, INTERVAL 1 DAY) AND 
                 DATE_ADD(b.todate, INTERVAL 1 DAY)
             AND (
                 (b.fromdate = ? AND b.fromtime <= '10:00:00') OR
                 (b.todate = ? AND b.totime >= '10:00:00') OR
                 (? BETWEEN b.fromdate AND b.todate)
             )";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iissss", $room_id, $GLOBALS['company_id'], $date, $date, $date, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

$action = $_POST['action'] ?? '';
error_log("POST data in roomcalendar.php: " . print_r($_POST, true));

switch ($action) {
    case 'get_room_types':
        $query = "SELECT id, name FROM rtype WHERE company_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $company_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $room_types = $result->fetch_all(MYSQLI_ASSOC);
        error_log("Room types fetched: " . print_r($room_types, true));
        echo json_encode($room_types);
        break;

    case 'get_rooms':
        $rtype_id = $_POST['rtype_id'] ?? null;
        if ($rtype_id) {
            $query = "SELECT id, name FROM rooms WHERE rtype_id = ? AND company_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ii", $rtype_id, $company_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $rooms = $result->fetch_all(MYSQLI_ASSOC);
            error_log("Rooms fetched for rtype_id $rtype_id: " . print_r($rooms, true));
            echo json_encode($rooms);
        } else {
            echo json_encode(['error' => 'Missing rtype_id']);
        }
        break;

    case 'get_schedule':
        $room_id = $_POST['room_id'] ?? null;
        if ($room_id) {
            $schedule = [];
            $current_date = new DateTime();
            for ($i = 0; $i < 7; $i++) {
                $date_str = $current_date->format('Y-m-d');
                $booking = isDateBooked($date_str, $room_id, $conn);
                $schedule[] = [
                    'date' => $current_date->format('d'),
                    'day' => $current_date->format('D'),
                    'customer' => $booking && $booking['name'] ? $booking['name'] : null,
                    'available' => !$booking || !$booking['name']
                ];
                $current_date->modify('+1 day');
            }
            error_log("Schedule fetched for room_id $room_id: " . print_r($schedule, true));
            echo json_encode($schedule);
        } else {
            echo json_encode(['error' => 'Missing room_id']);
        }
        break;

    case 'get_default_room':
        $today = '2025-03-21'; // Use date('Y-m-d') for dynamic current date
        $query = "SELECT r.id, r.name, r.rtype_id 
                  FROM rooms r 
                  INNER JOIN bookings b ON r.id = b.rooms_id 
                  WHERE b.company_id = ? 
                  AND b.fromdate = ? 
                  AND ? BETWEEN b.fromdate AND b.todate 
                  ORDER BY b.id DESC 
                  LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iss", $company_id, $today, $today);
        $stmt->execute();
        $result = $stmt->get_result();
        $default_room = $result->fetch_assoc();
        error_log("Default room fetched: " . print_r($default_room, true));
        if ($default_room) {
            echo json_encode($default_room);
        } else {
            echo json_encode(['error' => 'No suitable room found']);
        }
        break;

    default:
        echo json_encode(['error' => 'Invalid or missing action', 'received_action' => $action]);
}

exit();
