<?php
include 'config.php';
session_start();

$login_failed = false; // Flag for failed login

if (isset($_POST["submit"])) {
    $company = $_POST['company'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT
               us.*,
               rl.id as roles_id,
               rl.name as roles,
               c.id as company_id,
               c.name as company,
               c.region as region,
               c.city as city,
               c.country as country
            FROM user us
            INNER JOIN roles rl ON us.roles_id = rl.id
            INNER JOIN company c ON us.company_id = c.id
            WHERE us.name = ? AND us.passcode = ? AND c.name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $password, $company);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Set session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['company_id'] = $user['company_id'];
        $_SESSION['company'] = $user['company'];
        $_SESSION['region'] = $user['region'];
        $_SESSION['city'] = $user['city'];
        $_SESSION['country'] = $user['country'];
        $_SESSION['roles'] = $user['roles'];

        switch ($_SESSION['roles']) {
            case 'Admin':
                header("Location: application/dashboard/dashboard/index.php");
                exit();
            case 'Manager':
                header("Location: application/reservations/list/index.php");
                exit();
            case 'Staff':
                header("Location: application/reservations/guest/index.php");
                exit();
            default:
                break;
        }
    } else {
        $login_failed = true; // Set flag for failed login
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page - PropertyOne</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            background-image: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('/api/placeholder/1920/1080');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            height: 100vh;
            align-items: center;
            margin: 0;
        }

        .login-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
        }

        .logo {
            margin-bottom: 30px;
        }

        .logo-text {
            font-size: 24px;
            font-weight: 700;
            color: #222;
        }

        .logo-highlight {
            color: #444;
        }

        .login-container .message {
            display: none;
            color: #d9534f;
            font-size: 14px;
            margin-bottom: 20px;
            text-align: center;
            background-color: rgba(217, 83, 79, 0.1);
            padding: 10px;
            border-radius: 5px;
            border-left: 4px solid #d9534f;
        }

        .login-container .message.visible {
            display: block;
        }

        h2 {
            margin-bottom: 25px;
            color: #222;
            font-weight: 600;
        }

        .input-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .input-group label {
            display: block;
            font-weight: 500;
            margin-bottom: 8px;
            color: #444;
            font-size: 14px;
        }

        .input-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 15px;
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        .input-group input:focus {
            border-color: #666;
            box-shadow: 0 0 0 2px rgba(102, 102, 102, 0.2);
            outline: none;
        }

        .password-wrapper {
            display: flex;
            align-items: center;
            position: relative;
        }

        .password-wrapper input {
            padding-right: 45px;
        }

        .password-wrapper button {
            position: absolute;
            right: 15px;
            border: none;
            background: none;
            cursor: pointer;
            font-size: 16px;
            color: #777;
            transition: color 0.3s;
        }

        .password-wrapper button:hover {
            color: #333;
        }

        .login-btn {
            width: 100%;
            padding: 14px;
            background-color: #222;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            margin-top: 10px;
        }

        .login-btn:hover {
            background-color: #444;
        }

        .login-btn:active {
            transform: translateY(2px);
        }

        .back-to-home {
            display: inline-block;
            margin-top: 25px;
            color: #666;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s;
        }

        .back-to-home:hover {
            color: #222;
            text-decoration: underline;
        }

        .forgot-password {
            display: block;
            text-align: right;
            margin-top: 5px;
            font-size: 13px;
            color: #666;
            text-decoration: none;
        }

        .forgot-password:hover {
            color: #222;
            text-decoration: underline;
        }
    </style>

</head>
<body>
    <div class="login-container">
        <div class="logo">
            <div class="logo-text">Property<span class="logo-highlight">One</span></div>
        </div>
        <h2>Sign In to Your Account</h2>
        <div class="message">Invalid credentials. Please try again.</div>
        <form action="" method="post">
            <div class="input-group">
                <label for="company">Company</label>
                <input type="text" id="company" name="company" placeholder="Enter your company name" required>
            </div>
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="Enter your username" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <div class="password-wrapper">
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                    <button type="button" id="togglePassword" aria-label="Toggle password visibility">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                    </button>
                </div>
                <a href="#" class="forgot-password">Forgot password?</a>
            </div>
            <button type="submit" class="login-btn" name="submit">Login</button>
        </form>
        <a href="index.php" class="back-to-home">← Back to Home</a>
    </div>

    <script>
        document.getElementById("togglePassword").addEventListener("click", function() {
            let passwordInput = document.getElementById("password");
            let icon = this.querySelector('svg');
            
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                icon.innerHTML = `
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                    <line x1="1" y1="1" x2="23" y2="23"></line>
                `;
            } else {
                passwordInput.type = "password";
                icon.innerHTML = `
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                    <circle cx="12" cy="12" r="3"></circle>
                `;
            }
        });

        <?php if ($login_failed): ?>
            document.querySelector('.login-container .message').classList.add('visible');
        <?php endif; ?>

    </script>
</body>
</html>