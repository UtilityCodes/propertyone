<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php
           echo $title;
        ?>
    </title>
    <link rel="stylesheet" href="../../../assets/css/style.css">

    <!--mobile-->
    <link rel="stylesheet" href="../../../assets/css/mobile/surfaceduo.css">
    <link rel="stylesheet" href="../../../assets/css/mobile/asusfold.css">
    <link rel="stylesheet" href="../../../assets/css/mobile/ipadpro.css">
    <link rel="stylesheet" href="../../../assets/css/mobile/nesthubmax.css">

    <!--mobileai-->
    <link rel="stylesheet" href="../../../assets/css/mobileai/ipad-air.css">
    <link rel="stylesheet" href="../../../assets/css/mobileai/nest-hub.css">

    
    <link 
        rel="stylesheet" 
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" 
        integrity="sha512-SfTiTlX6kk+qitfevl/7LibUOeJWlt9rbyDn92a1DqWOw9vWG2MFoays0sgObmWazO5BQPiFucnnEAjpAB+/Sw==" 
        crossorigin="anonymous" 
        referrerpolicy="no-referrer" 
    />