// search-boxes.js
document.addEventListener('DOMContentLoaded', function() {
    // Get all pages
    const pages = document.querySelectorAll('.page');

    pages.forEach(page => {
        // Find the search input and boxes within this page
        const searchInput = page.querySelector('.search-box input');
        const boxes = page.querySelectorAll('.pcb-boxes');

        if (!searchInput || boxes.length === 0) return; // Skip if no search or boxes

        // Add input event listener for real-time filtering
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.trim().toLowerCase();

            boxes.forEach(box => {
                // Get all text content within the box for searching
                const textContent = box.textContent.toLowerCase();

                // Show or hide based on search match
                if (searchTerm === '' || textContent.includes(searchTerm)) {
                    box.style.display = ''; // Show (reset to default display)
                } else {
                    box.style.display = 'none'; // Hide
                }
            });
        });
    });
});