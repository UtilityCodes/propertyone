<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property One - Hotel Reservation Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        header {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
        }

        .logo {
            display: flex;
            align-items: center;
        }

        .logo-text {
            font-size: 24px;
            font-weight: 700;
            color: #222;
        }

        .logo-highlight {
            color: #444;
        }

        nav ul {
            display: flex;
            list-style: none;
        }

        nav ul li {
            margin-left: 30px;
        }

        nav ul li a {
            text-decoration: none;
            color: #222;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav ul li a:hover {
            color: #777;
        }

        .login-btn {
            background-color: #222;
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 5px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .login-btn:hover {
            background-color: #444;
        }

        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('/api/placeholder/1200/600') center/cover no-repeat;
            height: 100vh;
            display: flex;
            align-items: center;
            color: white;
            margin-top: 80px;
        }

        .hero-content {
            max-width: 600px;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            line-height: 1.2;
        }

        .hero p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            opacity: 0.9;
        }

        .cta-btn {
            background-color: white;
            color: #222;
            border: none;
            padding: 15px 35px;
            border-radius: 5px;
            font-weight: 600;
            font-size: 1.1rem;
            cursor: pointer;
            transition: all 0.3s;
        }

        .cta-btn:hover {
            background-color: #f0f0f0;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .features {
            padding: 80px 0;
        }

        .section-heading {
            text-align: center;
            margin-bottom: 60px;
        }

        .section-heading h2 {
            font-size: 2.5rem;
            color: #222;
            margin-bottom: 15px;
        }

        .section-heading p {
            font-size: 1.1rem;
            color: #777;
            max-width: 700px;
            margin: 0 auto;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .feature-card {
            background-color: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }

        .feature-icon {
            font-size: 2.5rem;
            color: #444;
            margin-bottom: 20px;
        }

        .feature-card h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: #222;
        }

        .feature-card p {
            color: #777;
        }

        footer {
            background-color: #222;
            color: white;
            padding: 60px 0 30px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }

        .footer-col h3 {
            font-size: 1.2rem;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-col h3::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 30px;
            height: 3px;
            background-color: #777;
        }

        .footer-col ul {
            list-style: none;
        }

        .footer-col ul li {
            margin-bottom: 10px;
        }

        .footer-col ul li a {
            text-decoration: none;
            color: #ccc;
            transition: color 0.3s;
        }

        .footer-col ul li a:hover {
            color: white;
        }

        .footer-bottom {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                text-align: center;
            }

            nav ul {
                margin-top: 20px;
                flex-direction: column;
                align-items: center;
            }

            nav ul li {
                margin: 10px 0;
            }

            .hero {
                text-align: center;
                padding: 0 20px;
            }

            .hero-content {
                margin: 0 auto;
            }

            .hero h1 {
                font-size: 2.2rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <div class="logo-text">Property<span class="logo-highlight">One</span></div>
                </div>
                <nav>
                    <ul>
                        <li><a href="#features">Features</a></li>
                        <li><a href="#about">About Us</a></li>
                        <li><a href="#contact">Contact</a></li>
                        <li><a href="login.php"><button class="login-btn">LOGIN</button></a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Streamline Your Hotel Management</h1>
                <p>PropertyOne provides a comprehensive hotel reservation management system, designed to optimize bookings, enhance guest experiences, and maximize your property's performance.</p>
                <a href="login.php">
                    <button class="cta-btn">Get Started</button>
                </a>
            </div>
        </div>
    </section>

    <section class="features" id="features">
        <div class="container">
            <div class="section-heading">
                <h2>Powerful Features</h2>
                <p>Discover why hotels across Dar es Salaam trust PropertyOne to manage their reservations</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">📊</div>
                    <h3>Real-time Dashboard</h3>
                    <p>Get a complete overview of your occupancy rates, reservations, guest information, and financial performance in one central location.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📱</div>
                    <h3>Mobile Accessibility</h3>
                    <p>Manage your hotel on the go with our responsive design that works perfectly on any device.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">💰</div>
                    <h3>Streamlined Bookings</h3>
                    <p>Process reservations quickly, manage room availability, and handle payments securely all within one system.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🔧</div>
                    <h3>Maintenance Management</h3>
                    <p>Track room status, schedule maintenance, and ensure every room is guest-ready at all times.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📝</div>
                    <h3>Guest Management</h3>
                    <p>Store guest profiles, preferences, and booking history to provide personalized service and build loyalty.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📈</div>
                    <h3>Financial Reporting</h3>
                    <p>Generate detailed financial reports to track revenue, expenses, and profitability across your property.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="features" id="about">
        <div class="container">
            <div class="section-heading">
                <h2>About PropertyOne</h2>
                <p>Your trusted partner in hotel management technology</p>
            </div>
            <div class="feature-card" style="max-width: 800px; margin: 0 auto;">
                <p style="font-size: 1.1rem; line-height: 1.8;">
                    PropertyOne is a leading provider of hotel reservation management solutions based in Dar es Salaam, Tanzania. We understand the unique challenges faced by hoteliers in the region and have developed a system specifically tailored to meet these needs. Our team combines hospitality expertise with cutting-edge technology to deliver a platform that simplifies operations, enhances guest experiences, and maximizes profitability.
                </p>
                <p style="font-size: 1.1rem; line-height: 1.8; margin-top: 20px;">
                    Since our founding, we've partnered with hotels of all sizes across East Africa to transform their reservation management processes. Our dedicated team provides ongoing support and training to ensure you get the most out of your PropertyOne system.
                </p>
            </div>
        </div>
    </section>

    <footer id="contact">
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h3>PropertyOne</h3>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Our Services</a></li>
                        <li><a href="#">Pricing</a></li>
                        <li><a href="#">Careers</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h3>Resources</h3>
                    <ul>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Knowledge Base</a></li>
                        <li><a href="#">Tutorials</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h3>Legal</h3>
                    <ul>
                        <li><a href="#">Terms of Service</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Data Security</a></li>
                        <li><a href="#">Compliance</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h3>Contact Us</h3>
                    <ul>
                        <li><a href="mailto:info@propertyone.com">info@propertyone.com</a></li>
                        <li><a href="tel:+255123456789">+255 757 630 119</a></li>
                        <li>123 Samora Avenue<br>Dar es Salaam, Tanzania</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 PropertyOne. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const target = document.querySelector(targetId);
                const headerOffset = 100;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            });
        });

        // Header scroll effect
        window.addEventListener('scroll', function() {
            const header = document.querySelector('header');
            if (window.scrollY > 50) {
                header.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.1)';
            } else {
                header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
            }
        });
    </script>
</body>
</html>