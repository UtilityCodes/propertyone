<?php
ob_start();
require('../../../fpdf/fpdf.php');
include '../../../config.php';
session_start();

ob_clean();

if (!isset($_SESSION['company_id'])) {
    header('Content-Type: text/plain');
    die('Unauthorized');
}

$company_id = $_SESSION['company_id'];
$fromdate = $_POST['fromdate'] ?? '';
$todate = $_POST['todate'] ?? '';
$room_id = $_POST['room'] ?? '';

if (!$fromdate || !$todate || !$room_id) {
    header('Content-Type: text/plain');
    die('Missing required parameters');
}

// Validate dates
$start = new DateTime($fromdate);
$end = new DateTime($todate);
if ($start > $end) {
    header('Content-Type: text/plain');
    die('From date must be before To date');
}

// Fetch room name
$query = "SELECT name FROM rooms WHERE id = ? AND company_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $room_id, $company_id);
$stmt->execute();
$result = $stmt->get_result();
$room = $result->fetch_assoc();
$room_name = $room['name'] ?? 'Unknown Room';
$stmt->close();

// Format dates for header
$fromdate_formatted = $start->format('d F Y');
$todate_formatted = $end->format('d F Y');

// Custom PDF class
class PDF extends FPDF {
    function Header() {
        $this->SetMargins(15, 15, 15);
        $this->SetFont('Arial', 'B', 14);
        $this->SetTextColor(0, 51, 102);
        $this->Cell(0, 10, "Room Occupancy and Payment Report", 0, 1, 'C');
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 8, "For Room: $GLOBALS[room_name]  |  From $GLOBALS[fromdate_formatted] To $GLOBALS[todate_formatted]", 0, 1, 'C');
        $this->SetFont('Arial', 'I', 9);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 6, 'Generated on: ' . date('d F Y H:i'), 0, 1, 'C');
        $this->Ln(10);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . ' of {nb}', 0, 0, 'C');
    }

    function FancyTable($header, $data, $total) {
        $this->SetFont('Arial', 'B', 11);
        $this->SetFillColor(0, 51, 102);
        $this->SetTextColor(255, 255, 255);
        $this->SetDrawColor(0, 51, 102);
        $w = array(40, 60, 60);
        for ($i = 0; $i < count($header); $i++) {
            $this->Cell($w[$i], 8, $header[$i], 1, 0, 'C', true);
        }
        $this->Ln();

        $this->SetFont('Arial', '', 10);
        $this->SetFillColor(245, 245, 245);
        $fill = false;
        foreach ($data as $row) {
            $this->SetTextColor(0, 0, 0);
            $this->Cell($w[0], 7, $row['date'], 1, 0, 'L', $fill);
            if ($row['occupation'] === 'YES') {
                $this->SetTextColor(0, 128, 0);
            } else {
                $this->SetTextColor(255, 0, 0);
            }
            $this->Cell($w[1], 7, $row['occupation'], 1, 0, 'C', $fill);
            $this->SetTextColor(0, 0, 0);
            $this->Cell($w[2], 7, number_format($row['payments'], 2), 1, 0, 'R', $fill);
            $this->Ln();
            $fill = !$fill;
        }

        $this->SetFont('Arial', 'B', 11);
        $this->SetFillColor(200, 200, 200);
        $this->Cell($w[0] + $w[1], 8, 'Total Payments:', 1, 0, 'R', true);
        $this->Cell($w[2], 8, number_format($total, 2), 1, 0, 'R', true);
    }
}

// Fetch bookings with checkindate in range
$query = "SELECT checkindate, checkoutdate 
          FROM bookings 
          WHERE rooms_id = ? 
          AND company_id = ? 
          AND checkindate BETWEEN ? AND ? 
          AND checkintime >= '10:00:00'";
$stmt = $conn->prepare($query);
if (!$stmt) {
    header('Content-Type: text/plain');
    die('SQL Prepare failed: ' . $conn->error);
}
$stmt->bind_param("iiss", $room_id, $company_id, $fromdate, $todate);
$stmt->execute();
$result = $stmt->get_result();
$bookings = [];
while ($row = $result->fetch_assoc()) {
    $bookings[] = [
        'checkindate' => new DateTime($row['checkindate']),
        'checkoutdate' => new DateTime($row['checkoutdate'])
    ];
}
$stmt->close();

// Generate data for date range
$data = [];
$total_payments = 0;
$end->modify('+1 day');
$interval = new DateInterval('P1D');
$daterange = new DatePeriod($start, $interval, $end);

foreach ($daterange as $date) {
    $date_str = $date->format('Y-m-d');

    // Check if date is within any booking's checkindate to checkoutdate
    $occupied = 'NO';
    foreach ($bookings as $booking) {
        if ($date >= $booking['checkindate'] && $date <= $booking['checkoutdate']) {
            $occupied = 'YES';
            break;
        }
    }

    // Fetch payments
    $query = "SELECT SUM(p.amount) as payment_sum 
              FROM payments p 
              INNER JOIN bookings b ON b.code = p.act_code 
              WHERE b.rooms_id = ? 
              AND b.company_id = ? 
              AND p.dates = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        header('Content-Type: text/plain');
        die('SQL Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("iis", $room_id, $company_id, $date_str);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $payments = floatval($row['payment_sum'] ?? 0);
    $total_payments += $payments;
    $stmt->close();

    $data[] = [
        'date' => $date_str,
        'occupation' => $occupied,
        'payments' => $payments
    ];
}

// Reverse the data array for descending order
$data = array_reverse($data);

$conn->close();

// Generate PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$header = ['Date', 'Occupation Status', 'Payments for Room'];
$pdf->FancyTable($header, $data, $total_payments);

// Set headers
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="Room_Report_' . $room_name . '_' . $fromdate . '_to_' . $todate . '.pdf"');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Output PDF
$pdf->Output('D', 'Room_Report_' . $room_name . '_' . $fromdate . '_to_' . $todate . '.pdf');
exit();
