<?php

include '../../../config.php';

session_start();

date_default_timezone_set('Africa/Dar_es_Salaam');

$currentDate = date('Y-m-d');
$currentTime = date('H:i:s');

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

$rtypeQuery = "SELECT rt.*
               FROM rtype rt
               WHERE rt.company_id = '$company'
               ORDER BY rt.id";
$rtypeResult = $conn->query($rtypeQuery);
$rtypes = $rtypeResult->fetch_all(MYSQLI_ASSOC);

$roomQuery = "SELECT rm.*
              FROM rooms rm
              INNER JOIN rtype rt ON rm.rtype_id = rt.id
              WHERE rm.company_id = '$company'
              ORDER BY rm.id";
$roomResult = $conn->query($roomQuery);
$rooms = $roomResult->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
       $title = 'Room Report';
       include '../../../assets/components/head/head.php'; 
    ?>
</head>
<body>
    <div class="navi">
        <?php
            include '../../../assets/components/navi/navi.php';
        ?>
    </div>
    <div class="content-body">
        <div class="content-header">
            <?php
               $header = 'Reports';
               include '../../../assets/components/head/header.php'; 
            ?>
        </div>

        <div class="main-content">
            <div class="inline-page-header">
                <a href="#" class="active" data-page="0">
                    Occupation Report
                </a>
                <!-- <a href="#" data-page="1">
                    HouseKeeping Report
                </a> -->

            </div>
            <div class="inline-page-body">
                <!--Occupation Report-->
                <div class="page active">

                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2> Occupation Report</h2>
                            </div>
                            <hr>
                            <div class="pcb-reports-form">
                            <form action="" class="report-form" id="reportForm">
    <div class="form-section">
        <div class="sec">
            <div class="input-label">
                <label for="fromdate">FROM:</label>
                <div class="date-time">
                    <input type="date" class="date" name="fromdate" id="fromdate" required>
                </div>
            </div>
            <div class="input-label">
                <label for="todate">TO:</label>
                <div class="date-time">
                    <input type="date" class="date" name="todate" id="todate" value="<?php echo $currentDate ?>" required>
                </div>
            </div>
        </div>
        <div class="sec">
            <div class="input-label">
                <label for="rtype">Room Type:<span>*</span></label><br>
                <select name="rtype" id="rtype" required>
                    <option value="" selected disabled>--Select Room Type--</option>
                    <?php
                        foreach ($rtypes as $rtype) {
                            echo "<option value='{$rtype['id']}'>{$rtype['name']}</option>";
                        }
                    ?>
                </select>
            </div>
            <div class="input-label">
                <label for="room">Room:<span>*</span></label><br>
                <select name="room" id="room" required>
                    <option value="" selected disabled>--Select Room--</option>
                    <!-- Room options will be populated by JavaScript -->
                </select>
            </div>
        </div>
    </div>
    <div class="form-submit">
        <button type="button" class="cancel" onclick="this.closest('.report-form').reset();">
            <div class="icon">
                <i class="fa fa-times" aria-hidden="true"></i>
            </div>
            <span>CANCEL</span>
        </button>
        <button type="submit" class="confirm">
            <div class="icon">
                <i class="fa fa-check" aria-hidden="true"></i>
            </div>
            <span>CONFIRM</span>
        </button>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const rtypeSelect = document.getElementById('rtype');
    const roomSelect = document.getElementById('room');
    const reportForm = document.getElementById('reportForm');

    // Fetch rooms based on selected room type
    rtypeSelect.addEventListener('change', function() {
        const rtypeId = this.value;
        if (rtypeId) {
            fetch('get_rooms.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `rtype_id=${rtypeId}`
            })
            .then(response => response.json())
            .then(rooms => {
                roomSelect.innerHTML = '<option value="" selected disabled>--Select Room--</option>';
                rooms.forEach(room => {
                    const option = document.createElement('option');
                    option.value = room.id;
                    option.textContent = room.name;
                    roomSelect.appendChild(option);
                });
            })
            .catch(error => console.error('Error fetching rooms:', error));
        }
    });

    // Handle form submission
    reportForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch('generate_report.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.blob();
        })
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `Room_Report_${new Date().toISOString().slice(0,10)}.pdf`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
        })
        .catch(error => console.error('Error generating PDF:', error));
    });
});
</script>
                        </div>
                        </div>
                    </div>

                </div>

                <!--HouseKeeping Report-->
                <div class="page">
                    <div class="page-content-body">
                        <div class="pcb-reports">
                            <div class="pcb-reports-heading">
                                <h2>HouseKeeping Report</h2>
                            </div>
                            <hr>
                            <form action="" class="report-form">
                                <div class="form-section">
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">FROM:</label><br>
                                            <input type="date">
                                        </div>
                                        
                                        <div class="input-label">
                                            <label for="">TO:</label><br>
                                            <input type="date">
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Room Type:</label><br>
                                            <select name="" id="">
                                                <option value="" selected disabled>--Select Room Type--</option>
                                                <option value="">PRESIDENTIAL</option>
                                                <option value="">EXECUTIVE</option>
                                                <option value="">DOUBLE BEDROOM</option>
                                                <option value="">GUEST</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="sec">
                                        <div class="input-label">
                                            <label for="">Room:</label><br>
                                            <select name="" id="">
                                                <option value="" selected disabled>--Select Room--</option>
                                                <option value="">E-21</option>
                                                <option value="">P-23</option>
                                                <option value="">G-34</option>
                                                <option value="">DB-98</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-submit">
                                    <button class="cancel">
                                        <div class="icon">
                                            <i class="fa fa-times" aria-hidden="true"></i>
                                        </div>
                                        <span>CANCEL</span>
                                    </button>
                                    <button class="confirm">
                                        <div class="icon">
                                            <i class="fa fa-check" aria-hidden="true"></i>
                                        </div>
                                        <span>CONFIRM</span>
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>



    <?php
        include '../../../assets/components/root/js.php';
    ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Store all rooms data
            const allRooms = <?php echo json_encode($rooms); ?>;
            
            // Get the dropdown elements
            const rtypeSelect = document.querySelector('select[name="rtype"]');
            const roomSelect = document.querySelector('select[name="room"]');
            
            // Initially disable the room dropdown
            roomSelect.disabled = true;
            
            // Add event listener to room type dropdown
            rtypeSelect.addEventListener('change', function() {
                // Get the selected room type id
                const selectedRtypeId = this.value;
                
                // Clear current room options except the first one
                while (roomSelect.options.length > 1) {
                    roomSelect.remove(1);
                }
                
                // If a valid room type is selected
                if (selectedRtypeId) {
                    // Filter rooms by the selected room type
                    const filteredRooms = allRooms.filter(room => room.rtype_id === selectedRtypeId);
                    
                    // Add filtered rooms to the dropdown
                    filteredRooms.forEach(room => {
                        const option = document.createElement('option');
                        option.value = room.id;
                        option.textContent = room.name;
                        roomSelect.appendChild(option);
                    });
                    
                    // Enable the room dropdown
                    roomSelect.disabled = false;
                } else {
                    // If no room type is selected, keep room dropdown disabled
                    roomSelect.disabled = true;
                }
            });
        });
    </script>

</body>
</html>