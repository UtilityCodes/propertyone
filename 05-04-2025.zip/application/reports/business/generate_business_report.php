<?php
ob_start();
require('../../../fpdf/fpdf.php');
include '../../../config.php';
session_start();

ob_clean();

if (!isset($_SESSION['company_id'])) {
    header('Content-Type: text/plain');
    die('Unauthorized');
}

$company_id = $_SESSION['company_id'];
$fromdate = $_POST['fromdate'] ?? '';
$todate = $_POST['todate'] ?? '';

if (!$fromdate || !$todate) {
    header('Content-Type: text/plain');
    die('Missing required parameters');
}

// Validate dates
$start = new DateTime($fromdate);
$end = new DateTime($todate);
if ($start > $end) {
    header('Content-Type: text/plain');
    die('From date must be before To date');
}

// Format dates for header
$fromdate_formatted = $start->format('d F Y');
$todate_formatted = $end->format('d F Y');

// Fetch data
// Direct Payments
$query = "SELECT SUM(p.amount) as direct_sum 
          FROM payments p 
          INNER JOIN paytype pt ON p.paytype_id = pt.id 
          INNER JOIN paydirect pd ON p.paydirect_id = pd.id
          WHERE p.company_id = ? 
          AND p.dates BETWEEN ? AND ? 
          AND pt.name = 'DIRECT'
          AND pd.name = 'RECEIVED'";
$stmt = $conn->prepare($query);
$stmt->bind_param("iss", $company_id, $fromdate, $todate);
$stmt->execute();
$result = $stmt->get_result();
$direct_payments = floatval($result->fetch_assoc()['direct_sum'] ?? 0);
$stmt->close();

// Credit Payments
$query = "SELECT SUM(p.amount) as credit_sum 
          FROM payments p 
          INNER JOIN paytype pt ON p.paytype_id = pt.id 
          WHERE p.company_id = ? 
          AND p.dates BETWEEN ? AND ? 
          AND pt.name = 'CREDIT'";
$stmt = $conn->prepare($query);
$stmt->bind_param("iss", $company_id, $fromdate, $todate);
$stmt->execute();
$result = $stmt->get_result();
$credit_payments = floatval($result->fetch_assoc()['credit_sum'] ?? 0);
$stmt->close();

// Deposits
$query = "SELECT SUM(p.amount) as deposit_sum 
          FROM payments p 
          INNER JOIN activity a ON p.activity_id = a.id 
          WHERE p.company_id = ? 
          AND p.dates BETWEEN ? AND ? 
          AND a.name = 'DEPOSITS'";
$stmt = $conn->prepare($query);
$stmt->bind_param("iss", $company_id, $fromdate, $todate);
$stmt->execute();
$result = $stmt->get_result();
$deposits = floatval($result->fetch_assoc()['deposit_sum'] ?? 0);
$stmt->close();

// Expenses
$query = "SELECT SUM(p.amount) as expense_sum 
          FROM payments p 
          INNER JOIN activity a ON p.activity_id = a.id 
          WHERE p.company_id = ? 
          AND p.dates BETWEEN ? AND ? 
          AND a.name = 'EXPENSES'";
$stmt = $conn->prepare($query);
$stmt->bind_param("iss", $company_id, $fromdate, $todate);
$stmt->execute();
$result = $stmt->get_result();
$expenses = floatval($result->fetch_assoc()['expense_sum'] ?? 0);
$stmt->close();

// Withdraws
$query = "SELECT SUM(p.amount) as withdraw_sum 
          FROM payments p 
          INNER JOIN activity a ON p.activity_id = a.id 
          WHERE p.company_id = ? 
          AND p.dates BETWEEN ? AND ? 
          AND a.name = 'WITHDRAWS'";
$stmt = $conn->prepare($query);
$stmt->bind_param("iss", $company_id, $fromdate, $todate);
$stmt->execute();
$result = $stmt->get_result();
$withdraws = floatval($result->fetch_assoc()['withdraw_sum'] ?? 0);
$stmt->close();

// Calculate totals and difference
$left_total = $direct_payments + $credit_payments + $deposits;
$right_total = $expenses + $withdraws;
$difference = abs($left_total - $right_total);
$difference_side = $left_total > $right_total ? 'left' : 'right';

$conn->close();

// Custom PDF class
class PDF extends FPDF {
    function Header() {
        $this->SetMargins(15, 15, 15);
        $this->SetFont('Arial', 'B', 16);
        $this->SetTextColor(0, 51, 102);
        $this->Cell(0, 12, "Business Financial Report", 0, 1, 'C');
        $this->SetFont('Arial', '', 12);
        $this->SetTextColor(0, 0, 0);
        $this->Cell(0, 8, "Period: $GLOBALS[fromdate_formatted] to $GLOBALS[todate_formatted]", 0, 1, 'C');
        $this->SetFont('Arial', 'I', 9);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 6, 'Generated on: ' . date('d F Y H:i'), 0, 1, 'C');
        $this->Ln(10);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . ' of {nb}', 0, 0, 'C');
    }

    function BusinessReport($left_data, $right_data, $left_total, $right_total, $difference, $difference_side) {
        $left_x = 15;  // Left column start
        $right_x = 105; // Right column start
        $width_label = 60; // Width for labels
        $width_value = 20; // Width for values
        $line_height = 7;

        // Section Headers
        $this->SetFont('Arial', 'B', 14);
        $this->SetTextColor(0, 51, 102);
        $this->SetX($left_x);
        $this->Cell(80, 10, 'Income', 0, 0, 'L');
        $this->SetX($right_x);
        $this->Cell(80, 10, 'Expenditures', 0, 1, 'L');
        
        // Draw section borders
        $this->SetDrawColor(0, 51, 102);
        $this->SetLineWidth(0.5);
        $this->Line($left_x, $this->GetY(), $left_x + 80, $this->GetY());
        $this->Line($right_x, $this->GetY(), $right_x + 80, $this->GetY());
        $this->Ln(2);

        // Left Side - Income
        $this->SetFont('Arial', '', 11);
        $this->SetTextColor(0, 0, 0);
        $start_y = $this->GetY();

        $this->SetXY($left_x, $start_y);
        $this->Cell($width_label, $line_height, 'Direct Payments:', 0, 0, 'L');
        $this->Cell($width_value, $line_height, number_format($left_data['direct_payments'], 2), 0, 1, 'R');

        $this->SetXY($left_x, $this->GetY());
        $this->Cell($width_label, $line_height, 'Credit Payments:', 0, 0, 'L');
        $this->Cell($width_value, $line_height, number_format($left_data['credit_payments'], 2), 0, 1, 'R');

        $this->SetXY($left_x, $this->GetY());
        $this->Cell($width_label, $line_height, 'Deposits:', 0, 0, 'L');
        $this->Cell($width_value, $line_height, number_format($left_data['deposits'], 2), 0, 1, 'R');

        // Right Side - Expenditures
        $this->SetY($start_y); // Reset Y to align with left
        $this->SetX($right_x);
        $this->Cell($width_label, $line_height, 'Expenses:', 0, 0, 'L');
        $this->Cell($width_value, $line_height, number_format($right_data['expenses'], 2), 0, 1, 'R');

        $this->SetX($right_x);
        $this->Cell($width_label, $line_height, 'Withdrawals:', 0, 0, 'L');
        $this->Cell($width_value, $line_height, number_format($right_data['withdraws'], 2), 0, 1, 'R');

        // Draw bottom borders for sections
        $max_y = max($this->GetY(), $start_y + 3 * $line_height);
        $this->Line($left_x, $max_y, $left_x + 80, $max_y);
        $this->Line($right_x, $max_y, $right_x + 80, $max_y);

        // Totals
        $this->Ln(10);
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor(0, 51, 102);
        $this->SetX($left_x);
        $this->Cell($width_label, $line_height, 'Total Income:', 0, 0, 'L');
        $this->Cell($width_value, $line_height, number_format($left_total, 2), 0, 1, 'R');

        $this->SetX($right_x);
        $this->Cell($width_label, $line_height, 'Total Expenditures:', 0, 0, 'L');
        $this->Cell($width_value, $line_height, number_format($right_total, 2), 0, 1, 'R');

        // Difference
        $this->Ln(10);
        $this->SetFont('Arial', 'B', 12);
        if ($difference_side === 'left') {
            $this->SetTextColor(0, 128, 0); // Green
            $this->SetX($left_x);
            $this->Cell($width_label, $line_height, 'Net Gain:', 0, 0, 'L');
            $this->Cell($width_value, $line_height, number_format($difference, 2), 0, 1, 'R');
        } else {
            $this->SetTextColor(255, 0, 0); // Red
            $this->SetX($right_x);
            $this->Cell($width_label, $line_height, 'Net Loss:', 0, 0, 'L');
            $this->Cell($width_value, $line_height, number_format($difference, 2), 0, 1, 'R');
        }
    }
}

// Generate PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

$left_data = [
    'direct_payments' => $direct_payments,
    'credit_payments' => $credit_payments,
    'deposits' => $deposits
];
$right_data = [
    'expenses' => $expenses,
    'withdraws' => $withdraws
];

$pdf->BusinessReport($left_data, $right_data, $left_total, $right_total, $difference, $difference_side);

// Set headers
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="Business_Report_' . $fromdate . '_to_' . $todate . '.pdf"');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Output PDF
$pdf->Output('D', 'Business_Report_' . $fromdate . '_to_' . $todate . '.pdf');
exit();
