<?php

include '../../../config.php';

session_start();

$company = $_SESSION['company_id'];

function generateCode(){
    $timestamp = time();

    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);

    $code = 'et' . '-'  . $timestamp . '-' . $randomNumber;

    return $code;
}

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $code = $_POST['code'];
    $dates = $_POST['date'];
    $timee = $_POST['time'];
    $note = $_POST['note'];
    $company = $_SESSION['company_id'];

    date_default_timezone_set('Africa/Dar_es_Salaam');

    if($code == null){
        $code = generateCode();   
    }

    if($dates == null){
        $dates = date('Y-m-d');  
    }

    if($timee == null){
        $timee = date("H:i:s"); 
    }

    if($note == null){
        $note = 'No Note';   
    }

    $sql = "INSERT INTO etype (code, name, note, company_id, dates, timee) 
                     VALUES ('$code', '$name','$note', '$company', '$dates', '$timee')";

    if ($conn->query($sql) === TRUE) {
        header("location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }


}