<?php

include '../../../config.php';

session_start();

date_default_timezone_set('Africa/Dar_es_Salaam');


if (isset($_POST['id']) || isset($_GET['id'])) {
    $bookingId = isset($_POST['id']) ? $_POST['id'] : $_GET['id'];
    
    // First get the booking code
    $bookingQuery = "SELECT code FROM bookings WHERE id = ?";
    $bookingStmt = $conn->prepare($bookingQuery);
    $bookingStmt->bind_param("i", $bookingId);
    $bookingStmt->execute();
    $bookingResult = $bookingStmt->get_result();
    
    if ($bookingResult->num_rows > 0) {
        $booking = $bookingResult->fetch_assoc();
        $bookingCode = $booking['code'];
        
        // Now get all payments for this booking code
        $paymentsQuery = "SELECT 
                            p.code as paycode,
                            p.dates as paydate,
                            p.timee as paytime,
                            p.amount as payamount,
                            a.name as accountname,
                            a.number as accountnumber,
                            pt.name as method,
                            u.name as user,
                            p.note
                        FROM payments p
                        JOIN accounts a ON p.accounts_id = a.id
                        JOIN paytype pt ON p.paytype_id = pt.id
                        JOIN user u ON p.user_id = u.id
                        WHERE p.act_code = ?
                        ORDER BY p.dates DESC, p.timee DESC";
        
        $paymentsStmt = $conn->prepare($paymentsQuery);
        $paymentsStmt->bind_param("s", $bookingCode);
        $paymentsStmt->execute();
        $paymentsResult = $paymentsStmt->get_result();
        
        if ($paymentsResult->num_rows > 0) {
            // Display payments in the table
            ?>
            <div class="viewtable">
                <table>
                    <thead>
                        <tr>
                            <th>Time</th>
                            <th>Payment Code</th>
                            <th>Amount</th>
                            <th>Account Details</th>
                            <th>User</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($payment = $paymentsResult->fetch_assoc()) { ?>
                            <tr>
                                <td>
                                    <p><?php echo date('d M Y', strtotime($payment['paydate'])); ?></p>
                                    <p><?php echo date('g:i A', strtotime($payment['paytime'])); ?></p>
                                </td>
                                <td><?php echo $payment['paycode']; ?></td>
                                <td><?php echo number_format($payment['payamount'], 2); ?></td>
                                <td>
                                    <p><?php echo $payment['method']; ?></p>
                                    <p><?php echo $payment['accountname']; ?></p>
                                    <p><?php echo $payment['accountnumber']; ?></p>
                                </td>
                                <td><?php echo $payment['user']; ?></td>
                                <td><?php echo $payment['note']; ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
            <?php
        } else {
            echo "<p>No payment records found for this booking.</p>";
        }
        
        $paymentsStmt->close();
    } else {
        echo "<p>Booking not found.</p>";
    }
    
    $bookingStmt->close();
} else {
    echo "<p>Booking ID is required.</p>";
}
?>