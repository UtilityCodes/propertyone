<?php

include '../../../config.php';

session_start();

function generateCode(){
    $timestamp = time();

    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);

    $code = 'ac' . '-'  . $timestamp . '-' . $randomNumber;

    return $code;
}

if (isset($_POST["submit"])){  
    $dates = $_POST['date'];
    $timee = $_POST['time'];
    $code = $_POST['code'];
    $note = $_POST['note'];
    $method = $_POST['method'];
    $name = $_POST['ac-name'];
    $number = $_POST['ac-no'];
    $balance = $_POST['balance'];
    $company = $_SESSION['company_id'];

    date_default_timezone_set('Africa/Dar_es_Salaam');

    if($code == null){
        $code = generateCode();   
    }

    if($dates == null){
        $dates = date('Y-m-d');  
    }

    if($timee == null){
        $timee = date("H:i:s"); 
    }

    if($note == null){
        $note = 'No Note';   
    }

    $sql = "INSERT INTO accounts (code, name, number, methods_id, ibalance, balance, note, company_id, dates, timee) 
                         VALUES ('$code', '$name', '$number', '$method', '$balance', '$balance', '$note', '$company', '$dates', '$timee')";

    if ($conn->query($sql) === TRUE) {
        header("location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

}

$conn->close();
