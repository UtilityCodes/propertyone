

<div class="dashbody sec-1">
    <div class="left">
        <div class="graph booking">
            <div class="heading">
                <div class="title">Booking</div>
                <div class="more"><a href="../../reservations/list">More</a></div>
            </div>
            <div class="thegraph">
                <canvas id="bookingChart"></canvas>
            </div>
        </div>
        <div class="guest-btns">
            <div class="flex">
                <?php foreach ($guests as $guest): ?>
                    <button><?php echo htmlspecialchars($guest); ?></button>
                <?php endforeach; ?>
                <?php if (empty($guests)): ?>
                    <p>No current guests.</p>
                <?php endif; ?>
            </div>
            <div class="flex-more">
                <a href="../../reservations/guest">See More Guests</a>
            </div>
        </div>
    </div>
    <div class="right">
        <div class="graph occupancy">
            <div class="heading">
                <div class="title">Occupancy Graph:</div>
                <div class="more">
                    <a href="../../hotel/rooms">More</a>
                </div>
            </div>
            <div class="thegraph">
                <canvas id="occupancyChart"></canvas>
            </div>
            <div class="descr">
                <div class="item">
                    <div class="item-details">
                        <div class="colour vacant"></div>
                        <div class="name">Vacant</div>
                    </div>
                    <div class="item-capacity">
                        <span><?php echo $vacantRooms; ?></span>
                    </div>
                </div>
                <div class="item">
                    <div class="item-details">
                        <div class="colour occupied"></div>
                        <div class="name">Occupied</div>
                    </div>
                    <div class="item-capacity">
                        <span><?php echo $occupiedRooms; ?></span>
                    </div>
                </div>
                <div class="item">
                    <div class="item-details">
                        <div class="colour not-ready"></div>
                        <div class="name">Not Ready</div>
                    </div>
                    <div class="item-capacity">
                        <span><?php echo $notReadyRooms; ?></span>
                    </div>
                </div>
            </div>
            <div class="more-descr">
                <article>There are <span><?php echo $totalRooms; ?></span> Rooms Currently</article>
            </div>
        </div>
    </div>
</div>
<div class="dashbody sec-2">
    <div class="left">
<div class="up">
    <div class="arr">
        <div class="heading">
            <div class="title">Today's Arrival</div>
            <div class="more"><a href="../../reservations/guest">See More</a></div>
        </div>
        <div class="content">
            <div class="flex">
            <?php for ($i = 0; $i < count($arrivalTimesList); $i++): ?>
                <div class="entry">
                    <div class="time"><?php echo htmlspecialchars($arrivalTimesList[$i]); ?></div>
                    <div class="customer"><?php echo htmlspecialchars($arrivalGuestsList[$i]); ?></div>
                    <div class="room">Room: <span><?php echo htmlspecialchars($arrivalRoomsList[$i]); ?></span></div>
                </div>
            <?php endfor; ?>
            </div>
        </div>
    </div>
    <div class="dep">
        <div class="heading">
            <div class="title">Today's Departure</div>
            <div class="more"><a href="../../reservations/guest">See More</a></div>
        </div>
        <div class="content">
            <div class="flex">
            <?php for ($i = 0; $i < count($departureTimesList); $i++): ?>
                <div class="entry">
                    <div class="time"><?php echo htmlspecialchars($departureTimesList[$i]); ?></div>
                    <div class="customer"><?php echo htmlspecialchars($departureGuestsList[$i]); ?></div>
                    <div class="room">Room: <span><?php echo htmlspecialchars($departureRoomsList[$i]); ?></span></div>
                </div>
            <?php endfor; ?>
            </div>
        </div>
    </div>
</div>
        <div class="down">
            <div class="graph payment">
                <div class="heading">
                    <div class="title">Payments</div>
                    <div class="more"><a href="../../payments/all">See More</a></div>
                </div>
                <div class="thegraph">
                    <canvas id="paymentChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="right">
        <div class="calendar room">
            <div class="heading">
                <div class="title">Room Calendar</div>
                <div class="more"><a href="../../reservations/calendar">Go To Calendar</a></div>
            </div>
            <div class="content">
                <div class="rt">
                    <div class="flex" id="room-types"></div>
                </div>
                <div class="rms">
                    <div class="flex" id="room-buttons"></div>
                </div>
                <div class="sched">
                    <div class="flex" id="schedule-display">

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>