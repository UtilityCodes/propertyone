<?php
// paymentsgraph.php

date_default_timezone_set('Africa/Dar_es_Salaam'); // Your timezone

// Company ID from session
$companyId = $_SESSION['company_id'];

// Define the period (last 7 days)
$startDate = date('Y-m-d', strtotime('-6 days')); // 7 days including today
$endDate = date('Y-m-d');

// Query for Reservation Amounts (from bookings)
$query = "
    SELECT bookings.dates, SUM(bookings.amount) as reservation_amount
    FROM bookings
    WHERE bookings.company_id = ?
    AND bookings.dates BETWEEN ? AND ?
    GROUP BY bookings.dates
    ORDER BY bookings.dates ASC";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $companyId, $startDate, $endDate);
$stmt->execute();
$result = $stmt->get_result();
$reservationData = [];
while ($row = $result->fetch_assoc()) {
    $reservationData[$row['dates']] = (float)$row['reservation_amount'];
}

// Query for Direct Payments
$query = "
    SELECT payments.dates, SUM(payments.amount) as direct_amount
    FROM payments
    INNER JOIN paytype ON payments.paytype_id = paytype.id
    INNER JOIN paycat ON payments.paycat_id = paycat.id
    WHERE payments.company_id = ?
    AND paytype.name = 'DIRECT'
    AND paycat.name = 'Direct Payments'
    AND payments.dates BETWEEN ? AND ?
    GROUP BY payments.dates
    ORDER BY payments.dates ASC";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $companyId, $startDate, $endDate);
$stmt->execute();
$result = $stmt->get_result();
$directData = [];
while ($row = $result->fetch_assoc()) {
    $directData[$row['dates']] = (float)$row['direct_amount'];
}

// Query for Credit Payments
$query = "
    SELECT payments.dates, SUM(payments.amount) as credit_amount
    FROM payments
    INNER JOIN paytype ON payments.paytype_id = paytype.id
    WHERE payments.company_id = ?
    AND paytype.name = 'CREDIT'
    AND payments.dates BETWEEN ? AND ?
    GROUP BY payments.dates
    ORDER BY payments.dates ASC";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $companyId, $startDate, $endDate);
$stmt->execute();
$result = $stmt->get_result();
$creditData = [];
while ($row = $result->fetch_assoc()) {
    $creditData[$row['dates']] = (float)$row['credit_amount'];
}

// Generate full date range and align data
$allDates = [];
$reservationAmounts = [];
$directAmounts = [];
$creditAmounts = [];
$currentDate = $startDate;
while ($currentDate <= $endDate) {
    $allDates[] = $currentDate;
    $reservationAmounts[] = isset($reservationData[$currentDate]) ? $reservationData[$currentDate] : 0;
    $directAmounts[] = isset($directData[$currentDate]) ? $directData[$currentDate] : 0;
    $creditAmounts[] = isset($creditData[$currentDate]) ? $creditData[$currentDate] : 0;
    $currentDate = date('Y-m-d', strtotime($currentDate . ' +1 day'));
}

// Convert to JSON for JavaScript
$datesJson = json_encode($allDates);
$reservationJson = json_encode($reservationAmounts);
$directJson = json_encode($directAmounts);
$creditJson = json_encode($creditAmounts);

// No $conn->close() here; let index.php handle it
?>