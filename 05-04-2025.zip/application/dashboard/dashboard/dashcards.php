<?php
// dashcards.php

date_default_timezone_set('Africa/Dar_es_Salaam');
// Company ID from session
$companyId = $_SESSION['company_id'];

// Define date ranges
$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));
$weekStart = date('Y-m-d', strtotime('-6 days')); // Past 7 days including today
$monthStart = date('Y-m-d', strtotime('-29 days')); // Past 30 days including today

// Function to fetch data for a given date range
function fetchDashboardData($conn, $companyId, $startDate, $endDate = null) {
    $endDate = $endDate ?? $startDate; // If no end date, assume single day
    
    // Initialize variables
    $data = [
        'arrivals' => 0,
        'departures' => 0,
        'directPayment' => 0,
        'creditPayment' => 0,
        'totalRevenue' => 0,
        'totalCost' => 0,
        'reservationPayments' => 0,
        'deposits' => 0,
        'withdraws' => 0,
        'expenses' => 0,
        'reservationRefunds' => 0
    ];

    // Determine if it's a single day or range for arrivals/departures
    $dateCondition = ($startDate === $endDate) ? "fromdate = ?" : "fromdate BETWEEN ? AND ?";
    
    // 1. Arrivals
    $query = "SELECT COUNT(*) as arrivals FROM bookings WHERE $dateCondition AND company_id = ?";
    $stmt = $conn->prepare($query);
    if ($startDate === $endDate) {
        $stmt->bind_param("ss", $startDate, $companyId);
    } else {
        $stmt->bind_param("sss", $startDate, $endDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data['arrivals'] = $row['arrivals'];
    }

    // 2. Departures
    $query = "SELECT COUNT(*) as departures FROM bookings WHERE " . 
             (($startDate === $endDate) ? "todate = ?" : "todate BETWEEN ? AND ?") . 
             " AND company_id = ?";
    $stmt = $conn->prepare($query);
    if ($startDate === $endDate) {
        $stmt->bind_param("ss", $startDate, $companyId);
    } else {
        $stmt->bind_param("sss", $startDate, $endDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data['departures'] = $row['departures'];
    }

    // For payments, adjust queries for date range if applicable
    $paymentDateCondition = ($startDate === $endDate) ? "dates = ?" : "dates BETWEEN ? AND ?";

    // 3. Direct Payment
    $query = "SELECT SUM(payments.amount) as direct_payment 
              FROM payments 
              INNER JOIN paytype ON payments.paytype_id = paytype.id 
              INNER JOIN paycat ON payments.paycat_id = paycat.id
              WHERE $paymentDateCondition AND paytype.name = 'DIRECT' AND paycat.name = 'Direct Payments' AND payments.company_id = ?";
    $stmt = $conn->prepare($query);
    if ($startDate === $endDate) {
        $stmt->bind_param("ss", $startDate, $companyId);
    } else {
        $stmt->bind_param("sss", $startDate, $endDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data['directPayment'] = $row['direct_payment'] ?? 0;
    }

    // 4. Credit Payment
    $query = "SELECT SUM(payments.amount) as credit_payment 
              FROM payments 
              INNER JOIN paytype ON payments.paytype_id = paytype.id 
              WHERE $paymentDateCondition AND paytype.name = 'CREDIT' AND payments.company_id = ?";
    $stmt = $conn->prepare($query);
    if ($startDate === $endDate) {
        $stmt->bind_param("ss", $startDate, $companyId);
    } else {
        $stmt->bind_param("sss", $startDate, $endDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data['creditPayment'] = $row['credit_payment'] ?? 0;
    }

    // 5. Total Revenue
    $query = "SELECT SUM(payments.amount) as total_revenue 
              FROM payments 
              INNER JOIN paydirect ON payments.paydirect_id = paydirect.id 
              WHERE $paymentDateCondition AND paydirect.name = 'RECEIVED' AND payments.company_id = ?";
    $stmt = $conn->prepare($query);
    if ($startDate === $endDate) {
        $stmt->bind_param("ss", $startDate, $companyId);
    } else {
        $stmt->bind_param("sss", $startDate, $endDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data['totalRevenue'] = $row['total_revenue'] ?? 0;
    }

    // 6. Total Cost
    $query = "SELECT SUM(payments.amount) as total_cost 
              FROM payments 
              INNER JOIN paydirect ON payments.paydirect_id = paydirect.id 
              WHERE $paymentDateCondition AND paydirect.name = 'SENT' AND payments.company_id = ?";
    $stmt = $conn->prepare($query);
    if ($startDate === $endDate) {
        $stmt->bind_param("ss", $startDate, $companyId);
    } else {
        $stmt->bind_param("sss", $startDate, $endDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data['totalCost'] = $row['total_cost'] ?? 0;
    }

    // 7. Reservation Payments
    $query = "SELECT SUM(payments.amount) as reservation_payments 
              FROM payments 
              INNER JOIN paydirect ON payments.paydirect_id = paydirect.id 
              INNER JOIN activity ON payments.activity_id = activity.id 
              WHERE $paymentDateCondition AND paydirect.name = 'RECEIVED' AND activity.name = 'BOOKINGS' AND payments.company_id = ?";
    $stmt = $conn->prepare($query);
    if ($startDate === $endDate) {
        $stmt->bind_param("ss", $startDate, $companyId);
    } else {
        $stmt->bind_param("sss", $startDate, $endDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data['reservationPayments'] = $row['reservation_payments'] ?? 0;
    }

    // 8. Deposits
    $query = "SELECT SUM(payments.amount) as deposits 
              FROM payments 
              INNER JOIN activity ON payments.activity_id = activity.id 
              WHERE $paymentDateCondition AND activity.name = 'DEPOSITS' AND payments.company_id = ?";
    $stmt = $conn->prepare($query);
    if ($startDate === $endDate) {
        $stmt->bind_param("ss", $startDate, $companyId);
    } else {
        $stmt->bind_param("sss", $startDate, $endDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data['deposits'] = $row['deposits'] ?? 0;
    }

    // 9. Withdraws
    $query = "SELECT SUM(payments.amount) as withdraws 
              FROM payments 
              INNER JOIN activity ON payments.activity_id = activity.id 
              WHERE $paymentDateCondition AND activity.name = 'WITHDRAWS' AND payments.company_id = ?";
    $stmt = $conn->prepare($query);
    if ($startDate === $endDate) {
        $stmt->bind_param("ss", $startDate, $companyId);
    } else {
        $stmt->bind_param("sss", $startDate, $endDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data['withdraws'] = $row['withdraws'] ?? 0;
    }

    // 10. Expenses
    $query = "SELECT SUM(payments.amount) as expenses 
              FROM payments 
              INNER JOIN activity ON payments.activity_id = activity.id 
              WHERE $paymentDateCondition AND activity.name = 'EXPENSES' AND payments.company_id = ?";
    $stmt = $conn->prepare($query);
    if ($startDate === $endDate) {
        $stmt->bind_param("ss", $startDate, $companyId);
    } else {
        $stmt->bind_param("sss", $startDate, $endDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data['expenses'] = $row['expenses'] ?? 0;
    }

    // 11. Reservation Refunds
    $query = "SELECT SUM(payments.amount) as reservation_refunds 
              FROM payments 
              INNER JOIN paycat ON payments.paycat_id = paycat.id 
              WHERE $paymentDateCondition AND paycat.name = 'Refunds' AND payments.company_id = ?";
    $stmt = $conn->prepare($query);
    if ($startDate === $endDate) {
        $stmt->bind_param("ss", $startDate, $companyId);
    } else {
        $stmt->bind_param("sss", $startDate, $endDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data['reservationRefunds'] = $row['reservation_refunds'] ?? 0;
    }

    return $data;
}

// Fetch data for each period
$todayData = fetchDashboardData($conn, $companyId, $today);
$yesterdayData = fetchDashboardData($conn, $companyId, $yesterday);
$weekData = fetchDashboardData($conn, $companyId, $weekStart, $today);
$monthData = fetchDashboardData($conn, $companyId, $monthStart, $today);

// Extract variables for Today
extract($todayData, EXTR_PREFIX_SAME, "today");

// Extract variables for Yesterday
extract($yesterdayData, EXTR_PREFIX_SAME, "yesterday");

// Extract variables for Past Week
extract($weekData, EXTR_PREFIX_SAME, "week");

// Extract variables for Past Month
extract($monthData, EXTR_PREFIX_SAME, "month");


// Format numbers with commas
function formatNumber($num) {
    return number_format($num, 0, '.', ',');
}
