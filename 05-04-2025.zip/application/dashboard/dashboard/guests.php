<?php
// guests.php

date_default_timezone_set('Africa/Dar_es_Salaam'); // Your timezone

// Company ID from session
$companyId = $_SESSION['company_id'];

// Query to get current guests
$query = "
    SELECT 
        bk.*,
        rt.name as rtype,
        rm.name as room,
        cu.name as guest,
        cu.phone as phone,
        cu.email as email,
        cu.code as guestcode,
        us.name as user
    FROM bookings bk
    INNER JOIN rooms rm ON bk.rooms_id = rm.id
    INNER JOIN rtype rt ON rm.rtype_id = rt.id
    INNER JOIN customer cu ON bk.customer_idno = cu.idno
    INNER JOIN user us ON bk.user_id = us.id
    WHERE bk.company_id = ?
      AND bk.checkindate IS NOT NULL
      AND bk.checkoutdate IS NULL
    ORDER BY bk.checkindate DESC, bk.checkintime DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $companyId);
$stmt->execute();
$result = $stmt->get_result();

// Initialize array for guest names
$guests = [];
while ($row = $result->fetch_assoc()) {
    $guests[] = $row['guest'];
}

// No $conn->close() here; let index.php handle it
