<?php
// roomstatus.php

date_default_timezone_set('Africa/Dar_es_Salaam');
$companyId = $_SESSION['company_id'];
$currentDateTime = date('Y-m-d H:i:s');

// Total rooms
$query = "SELECT COUNT(*) as total_rooms FROM rooms WHERE company_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $companyId);
$stmt->execute();
$result = $stmt->get_result();
$totalRooms = $result->fetch_assoc()['total_rooms'] ?? 0;

// Occupied rooms: Current time between checkindate/time and (checkoutdate/time if exists, else todate/time)
$query = "
    SELECT COUNT(DISTINCT r.id) as occupied
    FROM rooms r
    INNER JOIN bookings b ON r.id = b.rooms_id
    WHERE r.company_id = ?
    AND b.checkindate IS NOT NULL
    AND ? BETWEEN 
        CONCAT(b.checkindate, ' ', b.checkintime)
        AND COALESCE(
            CASE 
                WHEN b.checkoutdate IS NOT NULL THEN CONCAT(b.checkoutdate, ' ', b.checkouttime)
                ELSE CONCAT(b.todate, ' ', b.totime)
            END,
            '9999-12-31 23:59:59'
        )";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $companyId, $currentDateTime);
$stmt->execute();
$result = $stmt->get_result();
$occupiedRooms = $result->fetch_assoc()['occupied'] ?? 0;

// Not Ready rooms: Currently under housekeeping OR dirty (no housekeeping since last checkout)
$query = "
    SELECT COUNT(DISTINCT r.id) as not_ready
    FROM rooms r
    LEFT JOIN (
        SELECT rooms_id, 
               COALESCE(
                   CASE 
                       WHEN checkoutdate IS NOT NULL THEN CONCAT(checkoutdate, ' ', checkouttime)
                       ELSE CONCAT(todate, ' ', totime)
                   END,
                   '1970-01-01 00:00:00'
               ) as last_booking_end
        FROM bookings b1
        WHERE checkindate IS NOT NULL
        AND CONCAT(
            COALESCE(checkoutdate, todate), ' ', 
            COALESCE(checkouttime, totime)
        ) = (
            SELECT CONCAT(
                COALESCE(checkoutdate, todate), ' ', 
                COALESCE(checkouttime, totime)
            )
            FROM bookings b2 
            WHERE b2.rooms_id = b1.rooms_id 
            AND b2.checkindate IS NOT NULL
            ORDER BY 
                COALESCE(checkoutdate, todate) DESC, 
                COALESCE(checkouttime, totime) DESC 
            LIMIT 1
        )
    ) b ON r.id = b.rooms_id
    LEFT JOIN (
        SELECT rooms_id, 
               COALESCE(CONCAT(todate, ' ', totime), '1970-01-01 00:00:00') as last_hk_time
        FROM house_keeping
        WHERE (todate, totime) = (
            SELECT todate, totime 
            FROM house_keeping hk2 
            WHERE hk2.rooms_id = house_keeping.rooms_id 
            ORDER BY todate DESC, totime DESC 
            LIMIT 1
        )
    ) hk ON r.id = hk.rooms_id
    LEFT JOIN house_keeping hkc ON r.id = hkc.rooms_id 
        AND ? BETWEEN 
            COALESCE(CONCAT(hkc.fromdate, ' ', hkc.fromtime), '1970-01-01 00:00:00')
            AND COALESCE(CONCAT(hkc.todate, ' ', hkc.totime), '9999-12-31 23:59:59')
    WHERE r.company_id = ?
    AND (
        -- Currently under housekeeping
        hkc.rooms_id IS NOT NULL
        OR (
            -- Dirty: Last booking ended and no housekeeping since, and not currently occupied
            b.last_booking_end IS NOT NULL 
            AND (hk.last_hk_time IS NULL OR hk.last_hk_time < b.last_booking_end)
            AND NOT EXISTS (
                SELECT 1 
                FROM bookings b2 
                WHERE b2.rooms_id = r.id 
                AND b2.checkindate IS NOT NULL
                AND ? BETWEEN 
                    CONCAT(b2.checkindate, ' ', b2.checkintime)
                    AND COALESCE(
                        CASE 
                            WHEN b2.checkoutdate IS NOT NULL THEN CONCAT(b2.checkoutdate, ' ', b2.checkouttime)
                            ELSE CONCAT(b2.todate, ' ', b2.totime)
                        END,
                        '9999-12-31 23:59:59'
                    )
            )
        )
    )";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $currentDateTime, $companyId, $currentDateTime);
$stmt->execute();
$result = $stmt->get_result();
$notReadyRooms = $result->fetch_assoc()['not_ready'] ?? 0;

// Vacant rooms: Neither occupied nor not ready
$vacantRooms = $totalRooms - $occupiedRooms - $notReadyRooms;

// Ensure no negative values
$vacantRooms = max($vacantRooms, 0);
$occupiedRooms = max($occupiedRooms, 0);
$notReadyRooms = max($notReadyRooms, 0);

// Optional: Verify total matches (for debugging)
// echo "Total: $totalRooms, Vacant: $vacantRooms, Occupied: $occupiedRooms, Not Ready: $notReadyRooms";
?>