<?php
// cancel.php
include '../../../config.php';

session_start();

date_default_timezone_set('Africa/Dar_es_Salaam');

$company = $_SESSION['company_id'];
$user = $_SESSION['user_id'];

if (isset($_POST["cancel"]) && isset($_POST["id"])) {
    $bookingId = $_POST["id"];
    $cancelDate = $_POST["cancdate"];
    $cancelTime = $_POST["canctime"];

    // Prepare the update statement
    $updateSql = "UPDATE bookings 
                 SET cancdate = ?, 
                     canctime = ?
                 WHERE id = ? 
                 AND company_id = ?";

    $stmt = $conn->prepare($updateSql);
    $stmt->bind_param("ssis", $cancelDate, $cancelTime, $bookingId, $company);

    if ($stmt->execute()) {
        // Success - redirect back to the main page
        header("Location: index.php?success=cancelled");
        exit();
    } else {
        // Error handling
        echo "Error cancelling booking: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "Required fields are missing.";
}

$conn->close();