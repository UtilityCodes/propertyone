<?php
// checkout.php
include '../../../config.php';

session_start();

date_default_timezone_set('Africa/Dar_es_Salaam');

$company = $_SESSION['company_id'];
$user = $_SESSION['user_id'];

if (isset($_POST["checkout"]) && isset($_POST["id"])) {
    $bookingId = $_POST["id"];
    $checkoutDate = $_POST["checkoutdate"];
    $checkoutTime = $_POST["checkouttime"];

    // Prepare the update statement
    $updateSql = "UPDATE bookings 
                 SET checkoutdate = ?, 
                     checkouttime = ?
                 WHERE id = ? 
                 AND company_id = ?";

    $stmt = $conn->prepare($updateSql);
    $stmt->bind_param("ssis", $checkoutDate, $checkoutTime, $bookingId, $company);

    if ($stmt->execute()) {
        // Success - redirect back to the main page
        header("Location: index.php?success=checked_out");
        exit();
    } else {
        // Error handling
        echo "Error updating booking: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "Required fields are missing.";
}

$conn->close();