<?php
header('Content-Type: application/json');
include '../../../config.php';
session_start();

if (!isset($_SESSION['company_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$company_id = $_SESSION['company_id'];
$rtype_id = $_POST['rtype_id'] ?? null;

if ($rtype_id) {
    $query = "SELECT id, name FROM rooms WHERE rtype_id = ? AND company_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $rtype_id, $company_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $rooms = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($rooms);
} else {
    echo json_encode(['error' => 'Missing rtype_id']);
}

$conn->close();
exit();
