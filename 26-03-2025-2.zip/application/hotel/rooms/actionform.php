<?php

include '../../../config.php';
session_start();

date_default_timezone_set('Africa/Dar_es_Salaam');

$company = $_SESSION['company_id'];
$userroles = $_SESSION['roles'];

function generateCode(){
    $timestamp = time();

    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);

    $code = 'rm' . '-'  . $timestamp . '-' . $randomNumber;

    return $code;
}

if (isset($_POST["submit"])){
    $dates = date('Y-m-d'); 
    $timee = date("H:i:s"); 
    $name = $_POST['name'];
    $code = $_POST['code'];
    $rtype = $_POST['rtype'];
    $note = $_POST['note'];
    $uprice = $_POST['uprice'];
    $company = $_SESSION['company_id'];


    if($note == null){
        $note = 'No Note';   
    }

    if($code == null){
        $code = generateCode();    
    }

    $sql = "INSERT INTO rooms
                    (code, 
                     name,
                     rtype_id,
                     uprice,  
                     note, 
                     company_id, 
                     dates, 
                     timee)  
                VALUES 
            ('$code', 
             '$name', 
             '$rtype', 
             '$uprice', 
             '$note', 
             '$company', 
             '$dates', 
             '$timee')";

    if ($conn->query($sql) === TRUE) {
        header("location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }



}

$conn->close();