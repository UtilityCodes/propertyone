<?php
// bookings.php

date_default_timezone_set('Africa/Dar_es_Salaam'); // Your timezone

// Company ID from session
$companyId = $_SESSION['company_id'];

// Define the period (last 7 days)
$startDate = date('Y-m-d', strtotime('-6 days')); // 7 days including today
$endDate = date('Y-m-d');

// Query to get booking counts per date
$query = "
    SELECT bookings.dates, COUNT(bookings.id) as booking_count
    FROM bookings
    WHERE bookings.company_id = ?
    AND bookings.dates BETWEEN ? AND ?
    GROUP BY bookings.dates
    ORDER BY bookings.dates ASC";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $companyId, $startDate, $endDate);
$stmt->execute();
$result = $stmt->get_result();

// Initialize arrays for Chart.js
$dates = [];
$bookingCounts = [];

// Fill arrays with data
while ($row = $result->fetch_assoc()) {
    $dates[] = $row['dates'];
    $bookingCounts[] = (int)$row['booking_count'];
}

// If no bookings exist for some dates in the range, fill in zeros
$allDates = [];
$allCounts = [];
$currentDate = $startDate;
while ($currentDate <= $endDate) {
    $allDates[] = $currentDate;
    $index = array_search($currentDate, $dates);
    $allCounts[] = ($index !== false) ? $bookingCounts[$index] : 0;
    $currentDate = date('Y-m-d', strtotime($currentDate . ' +1 day'));
}

// Convert to JSON for JavaScript
$datesJson = json_encode($allDates);
$countsJson = json_encode($allCounts);

// No $conn->close() here; let index.php handle it
?>