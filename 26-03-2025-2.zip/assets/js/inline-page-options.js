
document.addEventListener('DOMContentLoaded', function() {
// Select all the anchor links
const moreDetailsLink = document.querySelector('.moreDetails');
const addPaymentLink = document.querySelector('.addPayment');
const viewPaymentLink = document.querySelector('.viewPayment');
const balanceViewLink = document.querySelector('.balanceView');
const checkinLink = document.querySelector('.checkinNow');
const checkoutLink = document.querySelector('.checkoutNow');
const cancelLink = document.querySelector('.cancelNow');

// Select all the sub-section body options
const moreSection = document.querySelector('.more');
const addPaySection = document.querySelector('.addpay');
const viewPaySection = document.querySelector('.viewpay');
const balanceSection = document.querySelector('.balance');
const checkinSection = document.querySelector('.checkin');
const checkoutSection = document.querySelector('.checkout');
const cancelSection = document.querySelector('.cancel');

// Function to hide all sub-sections
function hideAllSubSections() {
[moreSection, addPaySection, viewPaySection, balanceSection, checkinSection, checkoutSection, cancelSection].forEach(section => {
    if (section) {
        section.style.display = 'none';
    }
});
}

// Function to toggle a specific sub-section
function toggleSubSection(targetSection) {
hideAllSubSections();

if (targetSection) {
    targetSection.style.display = targetSection.style.display === 'block' ? 'none' : 'block';
}
}

// Add click event listeners to each anchor
if (moreDetailsLink) {
moreDetailsLink.addEventListener('click', function(e) {
    e.preventDefault();
    toggleSubSection(moreSection);
});
}

if (addPaymentLink) {
addPaymentLink.addEventListener('click', function(e) {
    e.preventDefault();
    toggleSubSection(addPaySection);
});
}

if (viewPaymentLink) {
viewPaymentLink.addEventListener('click', function(e) {
    e.preventDefault();
    toggleSubSection(viewPaySection);
});
}

if (balanceViewLink) {
balanceViewLink.addEventListener('click', function(e) {
    e.preventDefault();
    toggleSubSection(balanceSection);
});
}

if (checkinLink) {
    checkinLink.addEventListener('click', function(e) {
        e.preventDefault();
        toggleSubSection(checkinSection);
    });
}

if (checkoutLink) {
    checkoutLink.addEventListener('click', function(e) {
        e.preventDefault();
        toggleSubSection(checkoutSection);
    });
}

if (cancelLink) {
    cancelLink.addEventListener('click', function(e) {
        e.preventDefault();
        toggleSubSection(cancelSection);
    });
}




// Optional: Add click event to cancel buttons to hide their respective sections
const cancelButtons = document.querySelectorAll('.submits button[type="button"]');
cancelButtons.forEach(button => {
button.addEventListener('click', function() {
    const parentSection = this.closest('.ss-body-option');
    if (parentSection) {
        parentSection.style.display = 'none';
    }
});
});
});
